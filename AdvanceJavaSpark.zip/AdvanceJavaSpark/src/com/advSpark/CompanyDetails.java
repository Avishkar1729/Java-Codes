package com.advSpark;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CompanyDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
		ServletContext sc = getServletContext();
		
		out.println("<h1>Hello CD</h1>");
		
		 String clgName = sc.getInitParameter("clg");
		 String prince = sc.getInitParameter("principle");
		 
		 System.out.println("Inside Company Details");
		 
		 System.out.println("college name : "+ clgName);
		 System.out.println("Principle Name : " + prince);
		
		 
		 ServletConfig cg = getServletConfig();
		 
		 String deptName = cg.getInitParameter("dept");
		 String hod = cg.getInitParameter("hod");
		 
		 System.out.println("Inside Company Details");
		 
		 System.out.println("Dept name : "+ deptName);
		 System.out.println("HOD Name : " + hod);
		
	}


}
