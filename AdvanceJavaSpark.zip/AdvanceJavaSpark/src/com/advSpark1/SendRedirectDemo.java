package com.advSpark1;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SendRedirectDemo extends HttpServlet {
	
	public void Service(HttpServletRequest req, HttpServletResponse res) {
		
		int n1 = Integer.parseInt(req.getParameter("num1"));
		int n2 = Integer.parseInt(req.getParameter("num2"));

		int sum = n1 + n2;
		
//		res.sendRedirect("sendredi?sum="+sum);
		
	}

}
