package com.Ass8;

public class Shape_03_Circle extends Shape_01 {
	int r=10;
	float pi=3.14f;
	void area() {
		float area = pi * r * r ;
		System.out.println("Area of Circle : " + area);
	}

	public static void main(String[] args) {

		Shape_03_Circle obj = new Shape_03_Circle();
		obj.area();
		
	}

}
