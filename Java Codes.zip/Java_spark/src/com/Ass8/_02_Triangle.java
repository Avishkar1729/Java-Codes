package com.Ass8;

public class _02_Triangle extends _02_Circle {
	
	int a=10,b=20,c=30;
	
	void calculatePerimeter() {
		int sum = a+b+c;
		System.out.println("Perimeter of triangle : " + sum);
	}

}
