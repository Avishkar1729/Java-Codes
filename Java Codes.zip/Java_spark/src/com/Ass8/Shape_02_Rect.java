package com.Ass8;

public class Shape_02_Rect extends Shape_01 {
	int l=10,b=20;
	void area() {
		float area = l * b ;
		System.out.println("Area of rectangle : " + area);
	}

	public static void main(String[] args) {

		Shape_02_Rect obj = new Shape_02_Rect();
		obj.area();
		
	}

}
