package com.Ass8;

public class _01_Tiger extends _01_Animal {
	
	public void sound() {
		System.out.println("tiger roar");
	}

}
