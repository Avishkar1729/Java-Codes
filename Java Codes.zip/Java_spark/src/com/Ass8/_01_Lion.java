package com.Ass8;

public class _01_Lion extends _01_Animal {
	
	public void sound() {
		System.out.println("lion roar");
	}

}
