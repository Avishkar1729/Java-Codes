package com.Ass8;

public class _04_Deer extends _04_Animal {
	
	void eat() {
		System.out.println("Deer eat");
	}
	
	void sleep() {
		System.out.println("Deer Sleep");
	}

}
