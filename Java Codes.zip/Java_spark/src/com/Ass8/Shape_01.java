package com.Ass8;

public abstract class Shape_01 {

	abstract void area();
	
}
