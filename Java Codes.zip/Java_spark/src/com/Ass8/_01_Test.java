package com.Ass8;

public class _01_Test {

	public static void main(String[] args) {

		_01_Lion li = new _01_Lion();
		li.sound();
		
		_01_Tiger ti = new _01_Tiger();
		ti.sound();
		
	}

}
