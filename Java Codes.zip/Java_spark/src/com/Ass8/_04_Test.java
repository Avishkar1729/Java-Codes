package com.Ass8;

public class _04_Test {

	public static void main(String[] args) {

		_04_Tiger ti = new _04_Tiger();
		ti.eat();
		ti.sleep();
		
		_04_Lion li = new _04_Lion();
		li.eat();
		li.sleep();
		
		_04_Deer de = new _04_Deer();
		de.eat();
		de.sleep();
		
		
	}

}
