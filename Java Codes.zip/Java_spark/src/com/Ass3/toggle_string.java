package com.Ass3;

import java.util.Scanner;

public class toggle_string {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Type a string");
		String str = sc.nextLine();
		
		System.out.println(str);
		
		int n = str.length();
		
		
	    char ch[] = str.toCharArray();

		
		for(int i=0;i<n;i++) { 
			if(Character.isUpperCase(ch[i])) {
				 ch[i] = Character.toLowerCase(ch[i]);

			}
			else {
				 ch[i] = Character.toUpperCase(ch[i]);
			}
		}
		
		System.out.println(ch);
		
	}

}
