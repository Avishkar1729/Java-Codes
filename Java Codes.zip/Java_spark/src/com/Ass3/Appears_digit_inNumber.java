package com.Ass3;

import java.util.Scanner;

public class Appears_digit_inNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num = sc.nextInt();
		
		System.out.println("Enter the digit to check count");
		int digit = sc.nextInt();
		
		int count = 0; 
		int rem=0;
		
		while(num>0) {
			rem = num%10;
			if(rem==digit) {
				count+=1;
			}
			num = num/10;
		}
		
		System.out.println("Digit " + digit + " appears " + count + " times.");
		
	}

}
