package com.Ass3;

public class String_immutable {

	public static void main(String[] args) {

		
        String s1 = "JAVA";
        
        String s2 = "JAVA";
 
        System.out.println(s1 == s2);         //Output : true
        
        System.out.println(s1.equals(s2));
        
        
        
        String s3 =new String("APP");
        
        String s4 = new String("APP");
        
        System.out.println(s3 == s4);         //Output : false
        
        System.out.println(s3.equals(s4));
        
// 
//        s1 = s1 + "J2EE";
// 
//        System.out.println(s1 == s2);         //Output : false
		
		
//        String s1 = new String("JAVA");
//        
//        System.out.println(s1);         //Output : JAVA
// 
//        s1.concat("J2EE");
// 
//        System.out.println(s1);         //Output : JAVA
        
	}

}
