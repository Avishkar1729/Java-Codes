package com.Ass3;

import java.util.Scanner;

public class fibonacci_series_nth {
	
	void fib(int n1,int n2,int sum,int num,int i) {
		if(i<num) {
			System.out.print(sum + " ");
			n1=n2;
			n2=sum;
			sum=n1+n2;
			i++;
			fib(n1,n2,sum,num,i);
		}
	}

	public static void main(String[] args) {

		fibonacci_series_nth obj = new fibonacci_series_nth();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("How many prints the number?");
		int num = sc.nextInt();
		
		int n1=0,n2=1,sum=0,i =0;
		
		obj.fib(n1, n2, sum, num, i);
	}

}
