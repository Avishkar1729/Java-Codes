package com.Spark;

import java.util.Scanner;

public class single_level_inheritance_01 {
	
		Scanner sc = new Scanner(System.in);
		
		int a,b;
		int add = 0;
		
		void getData() {
			System.out.println("Enter the two numbers");
			a = sc.nextInt();
			b = sc.nextInt();
		}
		
		void addition() {
			add = a + b;
			System.out.println("Addition is : " + add);
		}
		
		

}
