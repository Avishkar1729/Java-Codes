package com.Spark;

abstract public class Bank3 extends Bank2 {
	
	Bank3 (String a, String b, float c, String d) {
		super(a,b,c,d);
	}
	
	void show() {
		System.out.println("Inside show");
	}

}
