package com.Spark;

public class Aggregation_02 {
	float stuMarks;
	Aggregation_01 addr;
	
	Aggregation_02(float stuMarks, Aggregation_01 addr) {
		this.stuMarks = stuMarks;
		this.addr = addr;
	}
	
	void display() {
		System.out.println("Student Id : " + addr.stuId);
		System.out.println("Student Name : " + addr.stuName);
		System.out.println("Student Aadhar : " + addr.stuAadhar);
		System.out.println("Student Marks : " + stuMarks);
		
	}

	public static void main(String[] args) {

		Aggregation_01 aobj = new Aggregation_01(101,"Avi","12345678");
		Aggregation_01 bobj = new Aggregation_01(102,"Ram","87654321");

		
		Aggregation_02 obj1 = new Aggregation_02(56.5f, aobj);
		obj1.display();
		System.out.println("***************************************");
		
		Aggregation_02 obj2 = new Aggregation_02(45.5f, bobj);
		obj2.display();
		System.out.println("***************************************");

		
	}

}
