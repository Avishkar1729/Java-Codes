package com.Spark;

public class java_update_03 implements java_update_01,java_update_02 {
	
	public void fun1() {
		System.out.println("abstract method fun1");
	}
	public void gun1() {
		System.out.println("abstract method gun1");
	}

	public static void main(String[] args) {

		java_update_03 demo = new java_update_03();
		
		demo.fun1();
		demo.fun2();
		demo.fun3();
		java_update_01.fun3();
//		demo.fun4(); // cannot access private method
		demo.call();
		demo.gun1();
		
		
	}

}
