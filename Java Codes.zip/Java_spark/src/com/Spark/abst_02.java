package com.Spark;

public class abst_02 extends abst_01 {
	
	int b = 20;
	
	abst_02() {
		// constructor has default super() that calls parent constructor
		System.out.println("Inside default constructor abst_02");
	}
	
	void abc () {
		System.out.println("Inside new");
	}

	void display() {
		System.out.println("Inside show");
	}

}
