package com.Spark;

abstract public class Bank1 {
	
	String accNo;
	String accName;
	float accBal;
	String accPin;
	
	Bank1 (String a, String b, float c, String d) {
		accNo = a;
		accName = b;
		accBal = c;
		accPin = d;
	}
	
	void rohit() {
		System.out.println("I am Rohit");
	}
	
	abstract void display();
	abstract void show();
	abstract void thala();
	

}
