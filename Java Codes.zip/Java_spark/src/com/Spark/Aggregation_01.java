package com.Spark;

public class Aggregation_01 {
	
	int stuId;
	String stuName;
	String stuAadhar;
	
	Aggregation_01(	int stuId,String stuName,String stuAadhar) {
		this.stuId = stuId;
		this.stuName = stuName;
		this.stuAadhar = stuAadhar;
	}

}
