package com.Spark;

public interface java_update_02 {
	
	void gun1();
	
	default void fun3() {
		System.out.println("default method fun 3 in second interface");
	}

}
