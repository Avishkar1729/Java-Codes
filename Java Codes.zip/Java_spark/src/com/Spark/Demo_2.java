package com.Spark;

public class Demo_2 {
	
	int a;
	int b;
	
	String name = "Demo";
	
	Demo_2() {
		System.out.println("I am Default Demo Constructor");
	}
	
	Demo_2(int x, int y) {
		System.out.println("I am Parameterized Demo Constructor");
		a=x;
		b=y;
	}
	
	void show () {
		System.out.println("a : " + a);
		System.out.println("b : " + b);

	}
}
