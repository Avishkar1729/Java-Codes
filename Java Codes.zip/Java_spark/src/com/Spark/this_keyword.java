package com.Spark;

//this always points to the current object
//differentiate between local and global 

public class this_keyword {
	
	int eId;
	String eName;
	float eSal;
	
	this_keyword() {
		System.out.println("Inside Default Constructor");
	}
	
	this_keyword(int eId, String eName, float eSal) {
		System.out.println("Inside Parameterised Constructor");
		
		this.eId = eId;
		this.eName = eName;
		this.eSal = eSal;
	}
	
	void display () {
		System.out.println("eId : " + eId);
		System.out.println("eName : " + eName);
		System.out.println("eSal : " + eSal);

	}
	
	public static void main(String[] args) {
		
		this_keyword tk = new this_keyword();
		tk.display();
		
		this_keyword tk1 = new this_keyword(101,"Avi",50000);
		tk1.display();
		
	}

}
