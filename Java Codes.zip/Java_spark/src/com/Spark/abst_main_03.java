package com.Spark;

public class abst_main_03 {

	public static void main(String[] args) {
		
		abst_02 obj = new abst_02();
		System.out.println("a :" + obj.a);
		System.out.println("b :" + obj.b);
		
		obj.abc();
		obj.display();

		

		
	}

}
