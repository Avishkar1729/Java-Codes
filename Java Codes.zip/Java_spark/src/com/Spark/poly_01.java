package com.Spark;

public class poly_01 {
	
	void display()
	{
		System.out.println("Inside display");
	}
	
	public static void gun()
	{
		System.out.println("Inside gun");
	}
	
	public void main() {
		
		System.out.println("Inside main");
	}
	
	public static void main(int a, int b) {
		
		System.out.println("Inside main with two int parameter");
	}
	
	public static void main(String args) {
		
		System.out.println("Inside main wiht string para");
	}

	public static void main(String[] ajay) {
	
		System.out.println("Inside main with string ajay");
		poly_01 obj = new poly_01();
		obj.display();
		poly_01.gun();
		obj.gun();
		
		poly_01.main("rohit");
		obj.main(10, 20);
		poly_01.main(100, 220);
		
	}
	
	public static void main(String args, int a) {
		
		System.out.println("Inside main args and a");
	}
	
	public static void main(String str, String str2) {
		
		System.out.println("Inside main str and str2");
	}

}