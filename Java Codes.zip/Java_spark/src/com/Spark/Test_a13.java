package com.Spark;

public class Test_a13 implements Test_a11,Test_a12 {
	
	public void display() {
		System.out.println("Inside display");
	}
	
	public void rk() {
		System.out.println("Inside rk");
	}
	
	public void vk() {
		System.out.println("Inside vk");
	}

	public static void main(String[] args) {

		Test_a13 obj = new Test_a13();
		obj.display();
		obj.rk();
		obj.vk();
		
	}

}
