package com.Spark;

public class final_keyw {         // when we make a class we cannot extends
	
	final void addition (int a, int b) {       // when we make method final it cannot be override
		System.out.println(a+b);    
	}
	
	void addition(int a, int b, int c) {
		System.out.println(a+b+c);
	}
	
	void display() {
		System.out.println("Hello I am in final keyw");
	}

}
