package com.Spark;

public class Hierarchical_01 {
	
	int stuRollNo;
	String stuName;
	String stuAadhar;
	float stuMarks;
	
	Hierarchical_01(int stuRollNo,String stuName,String stuAadhar,float stuMarks) {
//		this.stuRollNo;
//		this.stuName;
//		this.stuAadhar;
//		this.stuMarks;
	}
	
	

}
