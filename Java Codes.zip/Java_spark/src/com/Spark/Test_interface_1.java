package com.Spark;

public interface Test_interface_1 {
	
	int a = 10; // public static final int a =10;
	void display(); // public abstract void display();
	void show();

}
