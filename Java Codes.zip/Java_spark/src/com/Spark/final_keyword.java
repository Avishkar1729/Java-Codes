package com.Spark;


public class final_keyword extends final_keyw {
	
//	void addition (int a, int b) {
//		super.addition(50, 60);
//		System.out.println(a+b);
//	}
	
	void addition(int a, int b, int c) {
		System.out.println(a+b+c);
	}
	
	void display() {
		super.display();
		System.out.println("Hello I am in final keyword");
	}
	
	public static void main(String[] args) {
		
		final_keyword obj = new final_keyword();
		
		obj.addition(10, 20);
		obj.display();
		
		
		
//		final int a = 10;
//		System.out.println("A : " + a);
//		
//		//a++;    //value of a cannot change because of final keyword
//		System.out.println("A : " + a);

	}

}
