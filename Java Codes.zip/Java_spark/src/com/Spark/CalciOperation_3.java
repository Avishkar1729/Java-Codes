package com.Spark;

public class CalciOperation_3 {
	int add(int x, int y) {
		return x + y;
	}
	
	int sub(int x, int y) {
		return x - y;
	}
	
	int mul(int x, int y) {
		return x * y;
	}
	
	int div(int x, int y) {
		return x / y;
	}

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		CalciOperation_3 cal = new CalciOperation_3();
		System.out.println("Addition is : " + cal.add(a,b));
		System.out.println("Subtraction is : " + cal.sub(a,b));
		System.out.println("Multipication is : " + cal.mul(a,b));
		System.out.println("Division is : " + cal.div(a,b));

		
	}

}
