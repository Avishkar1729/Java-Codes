package com.Spark;

public class single_level_inheritance_02 extends single_level_inheritance_01 {
	
	void armstrong() {
		int temp = add;
		int rem=0,sum=0;
		
		while(add != 0) {
			rem = add % 10;
			sum = sum + (rem*rem*rem);
			add = add / 10;
		}
		
		if(temp == sum) {
			System.out.println("Armstrong Number");
		}
		
		else {
			System.out.println("Not arm strong number");
		}
		
	}

	public static void main(String[] args) {
		
		single_level_inheritance_02 obj = new single_level_inheritance_02();
		
		obj.getData();
		obj.addition();
		obj.armstrong();
	}

}
