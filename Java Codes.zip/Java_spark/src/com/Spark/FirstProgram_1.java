package com.Spark;

public class FirstProgram_1 {

	public static void main(String[] args) {
		// String[] args => Array
		// void => return type
		// static => It is keyword that runs main method using class name as file name 
		System.out.println("Hello Welcome to First Program");
	}

}
