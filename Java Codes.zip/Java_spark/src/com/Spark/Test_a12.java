package com.Spark;

public interface Test_a12 {
	
	void display();
	void vk();

}
