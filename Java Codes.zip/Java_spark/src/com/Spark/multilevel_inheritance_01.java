package com.Spark;
import java.util.Scanner;

public class multilevel_inheritance_01 {
	
	Scanner sc = new Scanner(System.in);
	
	final float pi = 3.14f;
	float r;
	
	
	

}
