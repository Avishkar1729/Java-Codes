package com.Spark;

public class multilevel_inheritance_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
