package com.Assignment;

import java.util.Scanner;

public class CharConversion {

	public static void main(String[] args) {

Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the character : ");
		char ch = sc.next().charAt(0);
		
		int c = ch;
		
	
		if(ch>='A' && ch<='Z') {   
			c = c + 32;
			char ch1 = (char) c;
			System.out.println(ch1);
		}
		
		else if(ch>='a' && ch<='z') {  
			c = c - 32;
			char ch2 = (char) c;
			System.out.println(ch2);
		}
		
		else {
			System.out.println("Please enter other character");
		}
		
		
		
	}

}
