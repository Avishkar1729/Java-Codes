package com.Assignment;

import java.util.Scanner;

public class Problem2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of intervals :");
		int interval = sc.nextInt();		
		
		System.out.println("Enter the first interval : ");
		int n = sc.nextInt();
		int m = sc.nextInt();
		
		int a=1;
		boolean bool = false;
		
		while(a<interval) {
			System.out.println("Enter the next interval : ");
			int x = sc.nextInt();
			int y = sc.nextInt();
			
			for(int i=n;i<m;i++) {
				for(int j=x;j<y;j++) {
					if(i==j) {
						bool = true;
						break;
					}
					
				}
			}
			
			if(bool==true) {
				System.out.println("[" + n + "," + y + "]");
				m = y;
			}
			else {
				System.out.println("[" + x + "," + y + "]");
				n = x;
				m = y;
			}
			a++;
		}
		
	}

}
