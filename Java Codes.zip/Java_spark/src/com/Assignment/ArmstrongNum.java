package com.Assignment;

import java.util.Scanner;

public class ArmstrongNum {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num = sc.nextInt();
		
		int temp = num;
		int rem = 0;
		int count = 0;
		int sum = 0;
		
		while(num>0) {
			num = num / 10;
			count++;
		}
		
		num = temp;
		
		while(num >0) {
			rem = num % 10;
			int x=1;
			for(int i=0;i<count;i++) {
				x = x * rem;
			}
			sum = sum + x;
			num = num/10;
		}
		
		
		if(sum==temp) {
			System.out.println("ArmStrong number");
		}
		
		else {
			System.out.println("Not Armstrong");
		}
		
	}

}
