package com.Assignment;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of an array : ");
		int size = sc.nextInt();
		
		int arr[] = new int[size];
		int temp;
		int count=0;
		int tempCount=0;
		
		for(int i=0;i<size;i++) {
			System.out.println("Enter the element : ");
			arr[i] = sc.nextInt();
		}
		
		for (int i = 0; i < size; i++) {
			for (int j = i + 1; j < size; j++) {
				if (arr[i] > arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}	
		}
		
		for(int i=0;i<size;i++) {
			count = 0;
			temp = arr[i];
			for(int j=0;j<size;j++) {
				
			    if(temp == arr[j]) {
				count++;
				temp = ++arr[i]; 
			}
			if(count>tempCount) {
				tempCount = count;
			}
			
			}
			
		}
		
		System.out.println(tempCount);
		


	}

}
