package com.Assignment;

import java.util.Scanner;

public class CheckChar {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the character : ");
		char ch = sc.next().charAt(0);
		
		if(Character.isDigit(ch)) {    
			//OR (ch>='0' && ch<='9')
			System.out.println("It is digit");
		}
		
		else if(Character.isUpperCase(ch)) {   
			//OR (ch>='A' && ch<='Z')
			System.out.println("It is upper case letter");
		}
		
		else if(Character.isLowerCase(ch)) {  
			//OR (ch>='a' && ch<='z')
			System.out.println("It is lower case");
		}
		
		else {
			System.out.println("Special symbol");
		}
	}
}
