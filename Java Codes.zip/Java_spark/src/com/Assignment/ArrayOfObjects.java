package com.Assignment;

public class ArrayOfObjects {
	

	public static void main(String[] args) {

		
		
	}

}
