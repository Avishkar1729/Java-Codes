package com.Assignment;
import java.util.Scanner;


public class MulptipicationTableLoop {
	
	void table (int n, int m,int j) {
		if(n<=m) {
			
			if(j<=10) {
				System.out.print(n*j + "\t");
				j++;
				table(n,m,j);
			}
			else {
				System.out.println();
				j=1;
				n++;
				table(n,m,j);
			}
			
		}
		
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the two numbers inbetween you want to print table");
		int n = sc.nextInt();
		int m = sc.nextInt();
		int j=1;
		
		MulptipicationTableLoop obj = new MulptipicationTableLoop();
		
		obj.table(n, m,j);
		
		
		
//		for(int i=n;i<=m;i++) {
//			for(int j=1;j<=10;j++) {
//				System.out.print(i + " X " + j + " = " + i*j + "\t");
//			    }
//			System.out.println();
//		}

		
	}

}
