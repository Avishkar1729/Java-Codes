package com.Assignment;

public class MulTable {

	void mul(int i,int n) {
		if(i <= 10) {
			System.out.println(i*n);
			mul(++i,n);
		}
		
	}
	
	public static void main(String[] args) {
		
		int i = 1, n = 5;;
		
		MulTable obj = new MulTable();
		obj.mul(i,n);
		
//		for(int i=1;i<=10;i++) {
//			System.out.println(a + " X " + i + " = " + i*a);
//		}
//
//	
	}

}
