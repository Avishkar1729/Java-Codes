package com.Assignment;

import java.util.Scanner;

public class SumOfNum {

	public static void main(String[] args) {

		
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		int num = 0;	
		
		do {
			sum = sum + num;
			System.out.println("Enter the number : ");
			num = sc.nextInt();
		}while(num>=0);
		

		
		System.out.println("Sum of positive numbers " + sum);
		
	}

}
