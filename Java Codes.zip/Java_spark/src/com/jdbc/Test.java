package com.jdbc;

import java.sql.*;

public class Test {

	public static void main(String[] args) {

		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");   // driver name/path
			
			DriverManager.getConnection("jdbc:mysql://localhost:3306/Data","root","");  //connection established and get reference
			
			System.out.println("Connection Established!!!");
		}
		
		catch(Exception e) {
			e.printStackTrace();		
			}
		
	}

}
