package com.jdbc;

import java.util.Scanner;

public class JDBC_main {

	public static void main(String[] args) {

		JDBC_operation  obj = new JDBC_operation();
		
		Scanner sc = new Scanner (System.in);

		obj.getConnection();
		
		//*********************************************************
		
//		obj.readAllData();		
		
//		System.out.println("Enter the roll no");
//		int roll = sc.nextInt();
//		
//		obj.readData(roll);
		
		//*********************************************************
		
//		obj.insertData();

//		System.out.println("Enter the Name");
//		String name = sc.nextLine();
//		System.out.println("Enter the roll no");
//		int roll = sc.nextInt();
//		
//		obj.insertData(name,roll);
//
//		System.out.println("***************************************");
//
//		obj.readAllData();
		
		
		
		//*********************************************************		
		
//		obj.createDB();
		
//		obj.createTable();
		
		//*********************************************************

//		obj.getConnection();
		
//		obj.delete();
		
//		System.out.println("Enter roll no");
//		int roll  = sc.nextInt();
//		obj.deleteUser(roll);
		
//		System.out.println("Enter name");
//		String name  = sc.nextLine();
//		obj.deleteUser(name);
		
		//*********************************************************
		
//		obj.update();
		
//		System.out.println("Enter roll No");
//		int roll  = sc.nextInt();
//		
//		System.out.println("Enter name");
//		sc.nextLine();
//		String name  = sc.nextLine();
//		
//		obj.updateUser(roll, name);
		
		
//		obj.alterTable();
		
		
		obj.insertImage();
		

		
	}

}
