package com.Game1;
import java.util.Scanner;
import java.util.Random;


public class NumberGame {


	Random rand = new Random();
	int num = rand.nextInt(100);	
	
	Scanner sc = new Scanner(System.in);
	int n;
	int count = 0;
	
	
	void check() {
		
		System.out.println("Enter the number between 1 to 100");
		n = sc.nextInt();
		
		while(n!=num) {
			
			if(n > num) {
				System.out.println("Enter the smaller no");
				check();
			}
			
			else {
				System.out.println("Enter the greater number");
				check();
			}
			
		}
		
		count ++;
		
	}
	
	void result() {
		System.out.println("You guess the number in " + count + " times.");

	}

}
