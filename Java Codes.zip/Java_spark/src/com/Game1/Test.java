package com.Game1;

public class Test {

	public static void main(String[] args) {


		NumberGame ng = new NumberGame();
		ng.check();
		ng.result();
		
	}

}
