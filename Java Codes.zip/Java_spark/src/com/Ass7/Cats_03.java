package com.Ass7;

abstract public class Cats_03 extends Animals_03{
	
	void cats() {
		System.out.println("Cats Meow");
	}

}
