package com.Ass7;

public class Dogs_03 extends Cats_03 {

	void dogs() {
		System.out.println("Dogs bark");
	}
	
}
