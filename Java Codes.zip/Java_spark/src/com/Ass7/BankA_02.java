package com.Ass7;

public class BankA_02 extends Bank_02 {
	
	int balance = 100;
	
	void getBalance() {
		System.out.println("Balance : " + balance);
	}

}
