package com.Ass7;

public class Child1_01 extends Parent_01 {

	void message() {
		System.out.println("This is first subclass");
	}
	
}
