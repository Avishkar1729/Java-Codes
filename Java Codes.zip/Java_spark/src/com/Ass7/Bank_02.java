package com.Ass7;

public abstract class Bank_02 {
	
	abstract void getBalance();

}
