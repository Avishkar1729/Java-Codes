package com.Ass7;

public abstract class Parent_01 {

	abstract void message();
	
}
