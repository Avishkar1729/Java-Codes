package com.Ass7;

public class Child2_01 extends Parent_01 {

	void message() {
		System.out.println("This is second subclass");
	}
	
}
