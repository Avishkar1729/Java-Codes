package com.Ass7;

public class Bank_Test_02 {

	public static void main(String[] args) {

		BankA_02 aobj = new BankA_02();
		aobj.getBalance();
		
		BankB_02 bobj = new BankB_02();
		bobj.getBalance();
		
		BankC_02 cobj = new BankC_02();
		cobj.getBalance();
		
		
	}

}
