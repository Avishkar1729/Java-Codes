package com.Ass7;

public class BankC_02 extends Bank_02 {
	
	int balance = 200;
	
	void getBalance() {
		System.out.println("Balance : " + balance);
	}

}
