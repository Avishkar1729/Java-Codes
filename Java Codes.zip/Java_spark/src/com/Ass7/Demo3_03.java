package com.Ass7;

public class Demo3_03 {

	public static void main(String[] args) {

		Dogs_03 dog = new Dogs_03();
		dog.dogs();
		
		dog.cats();
	}

}
