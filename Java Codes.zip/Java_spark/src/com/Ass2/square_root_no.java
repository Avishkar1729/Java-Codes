package com.Ass2;

import java.util.Scanner;

public class square_root_no {
	
	public void squareRoot(int num)   
	{  

	float t;  
	float sqrtroot=num/2;
	
	do   
	{  
	t=sqrtroot;  
	System.out.print(t + "\t");
	sqrtroot=(t+(num/t))/2;
	System.out.println(sqrtroot + " \t");
	}   
	while((t-sqrtroot)!= 0);  
	
	System.out.println("The square root of "+ num + " is: " + sqrtroot);  
	}  

	public static void main(String[] args) {

		square_root_no obj = new square_root_no();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num = sc.nextInt();
		
		obj.squareRoot(num);
		
	}

}
