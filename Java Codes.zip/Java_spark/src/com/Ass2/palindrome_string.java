package com.Ass2;
import java.util.Scanner;

public class palindrome_string {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the string");
		String str = sc.nextLine();
		
		String st = str.toLowerCase();
		int n = st.length();
		int count =0;
		
		for(int i=0;i<n/2+1;i++) {
			if(st.charAt(i) == st.charAt(n-1)) {
				n--;
				count += 1;
			}
			else {
				break;
			}
		}
		
		if(count>n/2) {
			System.out.println("String is palindrome");
		}
		
		else {
			System.out.println("String is not palindrome");
		}
	}

}
