package com.Ass2;

import java.util.Scanner;

public class vowel_present {

	public static void main(String[] args) {
		
		System.out.println("Enter the string");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		System.out.println(str);
		
		String st = str.toLowerCase();		
		int n = st.length();
		int count  = 0;

		for(int i=0;i<n;i++) {
			if(st.charAt(i) == 'a' || st.charAt(i) == 'e' || st.charAt(i) == 'i' || st.charAt(i) == 'o' || st.charAt(i) == 'u') {
				System.out.print(st.charAt(i)+ "\t");
				count ++;
			}	
		}
		
		if(count==0) {
			System.out.println("No vowel present");
		}
		
	}

}
