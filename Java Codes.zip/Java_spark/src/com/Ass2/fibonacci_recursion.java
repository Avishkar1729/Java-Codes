package com.Ass2;

public class fibonacci_recursion {
	
	void fib(int n1,int n2,int sum,int num,int i) {
		if(i<num) {
			System.out.print(" " + sum);
			n1=n2;
			n2=sum;
			sum=n1+n2;
			i++;
			fib(n1,n2,sum,num,i);
		}
	}
	
	
	
	public static void main(String args[]) {
			
		fibonacci_recursion obj = new fibonacci_recursion();
		
		int n1=0,n2=1,sum=0,num =10,i =0;
		
		obj.fib(n1, n2, sum, num, i);

		
		
		
//		int n1=0,n2=1,num =10;
//		int sum = 0;
//		
//		for(int i=0;i<num;i++) {
//			 System.out.print(" "+sum);   
//			 n1=n2;    
//			 n2=sum;   
//			 sum=n1+n2;    
//		}
			
		
		
	}

}
