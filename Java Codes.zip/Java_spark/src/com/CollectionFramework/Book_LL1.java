package com.CollectionFramework;

public class Book_LL1 {
	
	int bId;
	String bName, bAuthor, bPublisher;
	int bQuantity;
	
	Book_LL1(int id, String name, String author, String publisher, int quantity) {
		bId = id;
		bName = name;
		bAuthor = author;
		bPublisher = publisher;
		bQuantity = quantity;
	}

}
