package com.CollectionFramework;

import java.util.TreeSet;
import java.util.Iterator;

public class Tree_set1 {

	public static void main(String[] args) {


		TreeSet<Integer> ts = new TreeSet();
		
		ts.add(45);
		ts.add(27);
		ts.add(96);
		ts.add(65);
		ts.add(15);
		ts.add(45);
		
		Iterator t = ts.iterator();
		
		while(t.hasNext()) {
			System.out.println(t.next());
		}
		
		
		
		
	}

}
