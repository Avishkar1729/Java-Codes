package com.CollectionFramework;

public class Book_Dequeue extends Library{
	
	int bId;
	String bName, bAuthor, bPublisher;
	int bQuantity;
	
	Book_Dequeue(int id, String name, String author, String publisher, int quantity, int lid, String lName) {
		super(lid,lName);
		bId = id;
		bName = name;
		bAuthor = author;
		bPublisher = publisher;
		bQuantity = quantity;
	}

	@Override
	public String toString() {
		return "Book_Dequeue [bId=" + bId + ", bName=" + bName + ", bAuthor=" + bAuthor + ", bPublisher=" + bPublisher
				+ ", bQuantity=" + bQuantity + " Library id :" + lId + " Library name : " + lName + "]";
	}
	
	
//	public String toString() {
//		
//		return super.toString()+"\tbook id : "+bId+"\tbook name : "+bName+"\tbook author : "+bAuthor+"\tbook publisher : "+bPublisher+"\tbook quantity : "+bQuantity;
//		
//	}
	

}
