package com.CollectionFramework;

import java.util.Stack;

public class Stack_demo1 {

	public static void main(String[] args) {

		
		Stack<Integer> list = new Stack<Integer>();
		
		list.push(10);
		list.push(20);
		list.push(30);
		list.push(25);
		
//		for(Integer temp : list) {
//			System.out.println(temp);
//		}
		
		System.out.println(list);
		
		System.out.println("poped element " + list.pop());
		System.out.println(list);
		
		System.out.println("peek element " + list.peek());
		
		// searching from peek
		System.out.println("Search " + list.search(10));
		
		
		
	}

}
