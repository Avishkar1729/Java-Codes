package com.CollectionFramework;

import java.util.ArrayList;

public class List_methods {

	public static void main(String[] args) {


		ArrayList<Integer> b1 = new ArrayList<Integer>();
		
		b1.add(45);
		b1.add(60);
		b1.add(35);
		b1.add(15);
		b1.add(96);
		
		System.out.println(b1);
		
		b1.set(2, 37);
		System.out.println("\n After replacing element at index 2 :");
		System.out.println(b1);
		
		System.out.println("\n Getting element : " + b1.get(4));
		
		System.out.println("\n Index of : " + b1.indexOf(60));
		
		b1.sort(null);
		System.out.println("\n Sorted List : " + b1);
		
		
		
	}

}

