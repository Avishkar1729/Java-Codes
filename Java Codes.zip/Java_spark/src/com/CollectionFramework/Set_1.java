package com.CollectionFramework;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Set_1 {

	public static void main(String[] args) {


		Integer a[] = {10,20,18,7,45};
		Integer b[] = {15,10,18,93,1};
		
		Set<Integer> s1 = new HashSet<Integer>();
		s1.addAll(Arrays.asList(a));
		System.out.println("s1 : "+s1);
		
		Set<Integer> s2 = new HashSet<Integer>();
		s2.addAll(Arrays.asList(b));
		System.out.println("s2 : "+s2);
		
		// Union
		/*
		Set<Integer> s3 = new HashSet<Integer>();
		s3.addAll(s1);
		s3.addAll(s2);
		System.out.println("s3 : "+s3);
		*/
		/*
		Set<Integer> s3 = new HashSet<Integer>(s1);
		s3.addAll(s2);
		System.out.println("s3 : "+s3);
		*/
		
		/*
		s1.addAll(s2);
		System.out.println("Union : "+s1);
		*/
		
		/*
		 //intersection
		  
		s1.retainAll(s2);
		System.out.println("Intersection : "+s1);
		*/
		
		//Difference
		
		s1.removeAll(s2);
		System.out.println("Difference : "+s1);
		
		/*
		 s2.removeAll(s1);
			System.out.println("Difference : "+s2);
		 * 
		 */
	}

}
