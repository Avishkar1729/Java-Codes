package com.FruitBox;

public class Admin {

}
