package com.FruitBox;

import java.util.Scanner;

public class Customer {

	Scanner sc = new Scanner(System.in);
	int choice;

	void makeOrder() {

		System.out.println("!!! Hello Customer !!!");
		System.out.println();

		int np=1;
		
		while (np == 1) {
			System.out.println("Can you choose your order : ");
			System.out.println("1.Mango Juice (RS.20)\n" + "2.Pineapple Juice (RS.30)\n" + "3.Orange Juice (RS.30)\n"
					+ "4.Watermelon Juice (RS.30)\n" + "5.Fruite Plate (RS.40)");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Mango Juice order Successfully!");
				break;

			case 2:
				System.out.println("Pineapple Juice order Successfully!");
				break;

			case 3:
				System.out.println("Orange Juice order Successfully!");
				break;

			case 4:
				System.out.println("Watermelon Juice order Successfully!");
				break;

			case 5:
				System.out.println("Fruit Plate order Successfully!");
				break;

			default:
				System.out.println("Can you try again ? ");
			}

			System.out.println("***********************");
			System.out.println("Can you order again ? \n"
					+ "please enter 1 for order \n"
					+ "please enter any key to close");
			np  = sc.nextInt();
		}

	}

}
