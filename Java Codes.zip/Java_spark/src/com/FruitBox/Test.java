package com.FruitBox;

public class Test {

	public static void main(String[] args) {


		Customer obj = new Customer();
		obj.makeOrder();
		
	}

}
