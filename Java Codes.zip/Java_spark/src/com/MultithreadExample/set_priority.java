package com.MultithreadExample;

public class set_priority extends Thread {

	public void run() {
			System.out.println("Inside run : " + currentThread().getName());
		}

	public static void main(String[] args) {

		set_priority obj0 = new set_priority();
		set_priority obj1 = new set_priority();
		set_priority obj2 = new set_priority();
		set_priority obj3 = new set_priority();
		
		obj1.setPriority(MAX_PRIORITY);
//		obj3.setPriority(MIN_PRIORITY);
//		obj0.setPriority(7);

		obj0.setName("Rohit");
		obj1.setName("Virat");
		obj2.setName("Dhoni");
		obj3.setName("Ruturaj");
		
		System.out.println("Priority of obj0 (Rohit): " + obj0.getPriority());
		System.out.println("Priority of obj1 (Virat): " + obj1.getPriority());
		System.out.println("Priority of obj2 (Dhoni): " + obj2.getPriority());
		System.out.println("Priority of obj3 (Ruturaj): " + obj3.getPriority());
		
		obj0.start();
		obj1.start();
		obj2.start();
		obj3.start();

		



	}

}
