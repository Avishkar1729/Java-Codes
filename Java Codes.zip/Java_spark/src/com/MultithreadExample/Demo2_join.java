package com.MultithreadExample;

public class Demo2_join extends Thread {

	public void run() {
		for (int i = 1; i <= 5; i++) {
			System.out.println("i : " + i + "\t Name : " + currentThread().getName());
			
			try {
				sleep(2000);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	}

	public static void main(String[] args) {

		Demo2_join obj0 = new Demo2_join();
		Demo2_join obj1 = new Demo2_join();
		Demo2_join obj2 = new Demo2_join();
//		Demo2_join obj3 = new Demo2_join();


		
		
		obj0.start();
		
		try {
			obj0.join();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		obj1.start();
		obj2.start();
		
		
//		obj3.start();



	}

}
