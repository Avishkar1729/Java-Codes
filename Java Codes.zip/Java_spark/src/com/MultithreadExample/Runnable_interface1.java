package com.MultithreadExample;

public class Runnable_interface1 implements Runnable {
	
	public void run() {
		System.out.println("Inside run");
	}

	public static void main(String[] args) {


		Runnable_interface1 obj1 = new Runnable_interface1();
		
//		obj1.run();  // overriden method
		
		Thread t1 = new Thread(obj1);
		
		t1.start();   // Thread class method
		
		

	}

}
