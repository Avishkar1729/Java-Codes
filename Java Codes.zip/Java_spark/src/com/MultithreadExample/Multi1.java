package com.MultithreadExample;

public class Multi1 extends Thread {
	
	public void run() {
		System.out.println("Inside run");
	}

	public static void main(String[] args) {


		Multi1 obj1 = new Multi1();
		
//		obj1.run();   // override method
		
		obj1.start();   // Thread method
		
				
		
	}

}
