package com.MultithreadExample;

public class Runnable_interface2 implements Runnable {

	public void run() {
		for (int i = 1; i <= 5; i++) {
			System.out.println("i : " + i + "\t Name : " + Thread.currentThread().getName());

			try {
			Thread.sleep(2000);
			}

			catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {

		Runnable_interface2 obj0 = new Runnable_interface2();
		Runnable_interface2 obj1 = new Runnable_interface2();
		Runnable_interface2 obj2 = new Runnable_interface2();
//		Runnable_interface2 obj3 = new Runnable_interface2();

		Thread t1 = new Thread(obj0);
		Thread t2 = new Thread(obj0);
		Thread t3 = new Thread(obj1);
		Thread t4 = new Thread(obj2);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();


	}

}
