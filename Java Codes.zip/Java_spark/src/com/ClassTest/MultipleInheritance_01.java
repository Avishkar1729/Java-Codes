package com.ClassTest;

public interface MultipleInheritance_01 {
	
	void method1();
	void display();
	


}
