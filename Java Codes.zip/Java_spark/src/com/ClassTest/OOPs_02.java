package com.ClassTest;

public class OOPs_02 extends OOPs_01{

	void method2() {
		System.out.println("I am method 2");
	}
	
}
