package com.ClassTest;

public class Exception_Test {

	public static void main(String[] args) {

		try {
			throw new Exception_01("Error in code");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
