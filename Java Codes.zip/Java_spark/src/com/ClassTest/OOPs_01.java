package com.ClassTest;

public class OOPs_01 {
	
	void method1() {
		System.out.println("I am method 1");
	}

}
