package com.ClassTest;

public class OOPs_encapsulation {
	
    private int num;

    public int getData() {
        return num;
    }

    public void setData(int num) {
        this.num = num;
    }


}
