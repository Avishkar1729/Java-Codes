package com.ClassTest;

public class OOPs_poly3 implements OOPs_poly1 {

	public void test() {
		System.out.println("I am in OOPs_poly3");
	}
	
}
