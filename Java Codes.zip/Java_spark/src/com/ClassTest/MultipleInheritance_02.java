package com.ClassTest;

public interface MultipleInheritance_02 { 

	void method2();
	void display();
	
}
