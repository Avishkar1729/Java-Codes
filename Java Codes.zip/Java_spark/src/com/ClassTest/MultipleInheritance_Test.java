package com.ClassTest;

public class MultipleInheritance_Test implements MultipleInheritance_01, MultipleInheritance_02 {
	
	public void method1() {
		System.out.println("I am method 1");
	}
	
	public void method2() {
		System.out.println("I am method 1");
	}
	
	public void display() {
		System.out.println("I am display");
	}
	
	

	public static void main(String[] args) {

		MultipleInheritance_Test obj = new MultipleInheritance_Test();
		
		obj.method1();
		obj.method2();
		obj.display();
		
		
	}

}
