package com.ClassTest;

public class OOPs_abst2 extends OOPs_abst1 {

	void m1() {
		System.out.println("I am in m1");
	}
	
	void m2() {
		System.out.println("I am in m2");
	}
}
