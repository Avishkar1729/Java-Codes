package com.ClassTest;

public class ThreadClass extends Thread{
	
	public void run() {
		for (int i = 1; i <= 5; i++) {
			System.out.println(i + " Name : " + currentThread().getName());
			
			try {
				sleep(2000);
			}

			catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {
		
		ThreadClass t1 = new ThreadClass();
		ThreadClass t2 = new ThreadClass();
		ThreadClass t3 = new ThreadClass();
		ThreadClass t4 = new ThreadClass();

		t1.start();
		t2.start();
		t3.start();
		t4.start();

		

	}

}
