package com.ClassTest;

public abstract class OOPs_abst1 {
	
	abstract void m1();
	abstract void m2();


}
