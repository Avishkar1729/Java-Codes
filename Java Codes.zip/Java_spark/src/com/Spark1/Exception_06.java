package com.Spark1;

public class Exception_06 {

	
	static void cSk()
	{
		System.out.println("Hello yello army");
		
		try
		{
			System.out.println("inside 1st try block");
			
			try
			{
				System.out.println("inside 2st try block");
				
				try
				{
					System.out.println("inside 3st try block");
					String str = null;
					System.out.println(str.length());
					System.out.println( "hello try3");
				}
				catch (NullPointerException ex) 
				{
					System.out.println("catch3");
					ex.printStackTrace();
				}
				
				int a = 10 / 0;
				System.out.println("hello try2");
				
			}
			catch(ArithmeticException ex)
			{
				System.out.println("catch2");
				ex.printStackTrace();
			}
			
			int a = Integer.parseInt("Nisha");
			System.out.println("hello try1");
		}
		catch(Exception ex)
		{
			System.out.println("catch1");
			ex.printStackTrace();
		}
		
		System.out.println("hello jiji");
	}

	public static void main(String[] args) {
		
		cSk();
	}

}