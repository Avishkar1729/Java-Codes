package com.Spark1;

public class Exception_10 {
	
	static void sample() {
		
		try {
			for(int i=0;i<5;i++) {
				System.out.println("Hello");
				if(i==4) {
					throw new ArithmeticException();
				}
				System.out.println("Bye");
			}
		}
		
		catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		
		sample();
		
	}

}
