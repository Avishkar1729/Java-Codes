package com.Spark1;

import java.util.Scanner;

public class Exception_08 {

	static Scanner sc;
	
	static void mI()
	{
		sc = new Scanner(System.in);
		
		System.out.println("Enter your age : ");
		int age = sc.nextInt();
		
		if(age <= 18)
		{
			throw new ArithmeticException("Access denied!!!!!!\nYou must be atleast 18 years old");
		}
		else
		{
			System.out.println("You are eligible to vote for");
		}
	}

	public static void main(String[] args) {
		
		mI();

	}

}