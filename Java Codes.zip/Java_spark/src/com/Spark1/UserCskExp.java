package com.Spark1;

public class UserCskExp extends Exception {
	
	UserCskExp() {
		System.out.println("Default error");
	}

	UserCskExp(String str) {
		super(str);
	}
	
}
