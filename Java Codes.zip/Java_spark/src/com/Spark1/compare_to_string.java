package com.Spark1;

public class compare_to_string {

	public static void main(String[] args) {

		// lexicography
		String s1 = "hello";
		String s2 = "hello";
		String s3 = "kello";
		String s4 = "cello";
		
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s1.compareTo(s4));
		
	}

}
