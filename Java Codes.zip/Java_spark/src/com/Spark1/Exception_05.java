package com.Spark1;

public class Exception_05 {

	static void rCB()
	{
		System.out.println("Inside RCB");
		
		try
		{
			int arr[] = {10,20,30,40};
			
			for(int i = 0; i <= arr.length; i++)
			{
				System.out.print(arr[i]+"\t");
			}
			
			System.out.println("Hello");
			System.out.println("Bye");
			
			int x = 10 / 0;
			System.out.println("x : "+x);
			
			int a = Integer.parseInt("nisha");
			
			System.out.println("Hi hello byy");
		}
		catch(Exception ex)
		{
			//System.out.println(ex);
			ex.printStackTrace();
		}
		
		/*
		catch(ArrayIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
		}
		catch(StringIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
		}
		catch(ArithmeticException ex)
		{
			ex.printStackTrace();
		}
		catch(NullPointerException ex)
		{
			ex.printStackTrace();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		*/
		
		finally
		{
			System.out.println("Inside finally");
		}
		
		
		System.out.println("shital jiji");
	}

	public static void main(String[] args) {
		
		rCB();

	}

}