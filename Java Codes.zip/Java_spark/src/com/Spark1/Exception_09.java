package com.Spark1;

public class Exception_09 {

	
	void thala()
	{
		System.out.println("Thala for reason");
		try
		{
			throw new UserCskExp("5 IPL tropies");
		}
		catch(UserCskExp ex)    // Exception ex
		{
			ex.printStackTrace();
			//System.out.println(ex);
			//System.out.println(ex.getMessage());
		}
	}

	public static void main(String[] args) {
		
		Exception_09 obj = new Exception_09();
		obj.thala();
		
	}

}
