package com.Spark1;

public final class Final_class {
	
	final int age;
	final String name;
	
	Final_class(int a, String na) {
		age = a;
		name = na;
	}

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}
	
//	public void setAge(int age) {
//		this.age = age;
//	}



	public static void main(String [] args) {
		
		Final_class fc = new Final_class(23,"Avi");
		
		System.out.println(fc.getAge());
		System.out.println(fc.getName());
		
//		fc.setAge(10);   // cannot change the value

		
	}
	
}
