package com.Spark1;

import java.util.Scanner;

public class Exception_01 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Hello World");
		
		System.out.println("Enter the first number");
		int a = sc.nextInt();
		
		System.out.println("Enter the second number");
		int b = sc.nextInt();
		
		//Exception 1
		
		try {
			int div = a/b;
		    System.out.println("Div : " + div);
		}
		
		catch (ArithmeticException ae){
			System.out.println(ae);
		}
		
		System.out.println("Bye Bye");

		
		// Exception 2
		
		try {
			String st = null;
		    System.out.println("String length :" + st.length());
		}
		
		catch(NullPointerException np) {
			np.printStackTrace();
		}
		
		System.out.println("Good night");

		
		// Exception 3
		
		try {
			String str = "Hiii";
		    int m = Integer.parseInt(str);
		}
		
		catch(NumberFormatException nf) {
			nf.printStackTrace();
		}
		
		
		System.out.println("Sweet Dreams");
		
		
		
		
	}

}
