package com.Spark1;

public class Wrapper_class {

	public static void main(String[] args) {

		// primitive data type to wrapper class / object
		
		int a =10;
		System.out.println("a : " + a);
		
		Integer x = Integer.valueOf(a);  // before java5
		System.out.println("x : " + x);
		
		Integer y = a;  // after java5  // autoboxi
		System.out.println("y : " + y);
		
		
		
		// wrapper class / object to primitive data type
		
		Integer b = new Integer(20);
		System.out.println("b : " + b);
		
		int n = b.intValue();
		System.out.println("n : " + n);   // before java 5
		
		int m = b;
		System.out.println("m : " + m);   // after java 5 / unboxi

		
	}

}
