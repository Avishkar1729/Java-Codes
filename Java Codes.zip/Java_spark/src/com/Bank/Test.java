package com.Bank;

import java.util.Scanner;
import java.util.Random;

public class Test {

	public static void main(String[] args) {

		Scanner scc = new Scanner(System.in);
		Random ran = new Random();

//		ATM obj = new ATM();
		
		ATM[] atm = new ATM[100];
		

		int n = 1;
		int i =0;

		while (n == 1) {
			System.out.println("***** Welcome To the ATM *****");
			System.out.println("Enter the number that operation you want\n" + "1.Balance Enquiry \n"
					+ "2.Deposite Money \n" + "3.Withdraw Money \n" + "4.Change Pin \n" + "5.Create Account \n" + "6.Display Information \n" + "7.Close \n");
			int ip = scc.nextInt();

			switch (ip) {
			case 1:
//				obj.balanceEnquiry();
//				System.out.println("********************");
				
				System.out.println("Enter your customer ID : ");
				int test1 = scc.nextInt();
				for(int j=0;j<100;j++) {
					if(test1 == atm[j].cId) {
						atm[j].balanceEnquiry();
						System.out.println("*********************");
						break;
					}

				}
				break;

			case 2:
//				obj.deposite();
//				System.out.println("********************");
				
				System.out.println("Enter your customer ID : ");
				int test2 = scc.nextInt();
				for(int j=0;j<100;j++) {
					if(test2 == atm[j].cId) {
						atm[j].deposite();
						System.out.println("*********************");
						break;
					}
				}
				break;

			case 3:
//				obj.withdraw();
//				System.out.println("********************");
				
				System.out.println("Enter your customer ID : ");
				int test3 = scc.nextInt();
				for(int j=0;j<100;j++) {
					if(test3 == atm[j].cId) {
						atm[j].withdraw();
						System.out.println("*********************");
						break;
					}
				}
				
				break;

			case 4:
//				obj.changePin();
//				System.out.println("********************");
				
				System.out.println("Enter your customer ID : ");
				int test4 = scc.nextInt();
				for(int j=0;j<100;j++) {
					if(test4 == atm[j].cId) {
						atm[j].changePin();
						System.out.println("*********************");
						break;
					}
				}
				
				break;

			case 5:
//				System.out.println("Enter your Details : ");
//				obj.createAccount();
//				System.out.println("Your Customer Id : " + obj.cId);
//				System.out.println("Your Customer Id : " + obj.cAccNo);
//				System.out.println("*********************");
				
				System.out.println("Enter your Details : ");
				atm[i] = new ATM();
//				atm[i].createAccount();
//				System.out.println("ID is : " + atm[i].cId);
//				System.out.println("ID is : " + atm[i].cName);
//				System.out.println("ID is : " + atm[i].cAddress);
//				System.out.println("ID is : " + atm[i].cAccNo);

				i++;
				System.out.println("*********************");
				
				break;
				
			case 6:
//				System.out.println("Your Details");
//				obj.display();
//				System.out.println("*********************");
				
				System.out.println("Enter your customer ID : ");
				int test = scc.nextInt();
				for(int j=0;j<100;j++) {
					if(test == atm[j].cId) {
						System.out.println("Your Details");
						atm[j].display();
						System.out.println("*********************");
						break;
					}

				}
			
			case 7:
				break;
				

			default:
				System.out.println("You cannot choose wisely");

			}

			System.out.println(
					"Can you retry again ? \n" + "please enter 1 for retry \n" + "please enter any key to close");
			n = scc.nextInt();

		}
		System.out.println("***** Thank you! Visit Again *****");

	}

}
