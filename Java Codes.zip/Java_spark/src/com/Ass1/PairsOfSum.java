package com.Ass1;

import java.util.Scanner;

public class PairsOfSum {

	public static void main(String[] args) {

		
		System.out.println("Enter the number");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		int arr[] = {1,2,3,45,7,8,96,54,14,56};
		
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]+arr[j]==num) {
					System.out.println("Pair is : " + arr[i] + "," + arr[j]);
				}
			}
		}
		
	}

}
