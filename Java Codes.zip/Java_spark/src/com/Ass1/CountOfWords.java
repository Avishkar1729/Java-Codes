package com.Ass1;

public class CountOfWords {

	public static void main(String[] args) {
			
		String str ="Hello I am avi";
		
		System.out.println(str);
				
		int n = str.length();
		int count = 0;
        char ch[]= new char[n];     

		
		for(int i=0;i<n;i++) {
            ch[i]= str.charAt(i);  
			if(ch[i]== ' ' ) {
				count++;
			}
		}
		
		System.out.println(count);
	}

}
