package com.Ass1;
// 	sum += Math.pow(rem, count);


import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {

		
		System.out.print("Enter the number : ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		int temp=num;
		int count = 0;
		int rem=0,sum=0;
		
		while(num>0) {
			count++;
			num = num/10;
		}
		
		num = temp;
		while(num>0) {
			rem = num %10;
			int x=1;
			for(int i=1;i<=count;i++) {
				x = x * rem;
			}
			sum = sum + x;
			num = num/10;
		}
				
		if(sum==temp) {
			System.out.println(temp + " is armstrong Number");
		}
		else {
			System.out.println(temp + " is not armstrong number");
		}
		
		
		
	}

}
