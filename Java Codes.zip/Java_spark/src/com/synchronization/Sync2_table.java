package com.synchronization;

public class Sync2_table {
	
	
	synchronized public static void printTable(int num) {
		
		System.out.println("Starting phase 1");
		System.out.println("Strating phase 2");
		

			for(int i=1;i<=10;i++) {
				System.out.println(i*num + " : " + Thread.currentThread().getName());
				
				try {
					Thread.sleep(1000);
				}
				
				catch(Exception e) {
					e.printStackTrace();
				}
				
			}
		
		
		System.out.println("Ending phase 1");
		System.out.println("Ending phase 2");
		

		
	}

}
