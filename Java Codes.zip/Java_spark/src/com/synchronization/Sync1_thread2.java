package com.synchronization;

public class Sync1_thread2 extends Thread {
	
	Sync1_table tobj;
	
	Sync1_thread2(Sync1_table obj) {
		tobj = obj;
	}
	
	public void run() {
		tobj.printTable(4);
	}

}
