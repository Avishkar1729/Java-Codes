package com.synchronization;

public class Sync3_customer {
	
	
	int balance = 1000;
	
	synchronized void withdraw(int amt) {
		
		if(balance < amt) {
			System.out.println("Your balance is low you can't withdraw.");
			
			try {
				wait();
			}
			
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		balance = balance - amt;
		System.out.println("Withdraw successful!");
		System.out.println("Your updated balance after withdraw : " + balance);
	}
	
	synchronized void deposite(int amt) {
		
		balance = balance + amt;
		System.out.println("Deposite successful!");
		System.out.println("Your updated balance after deposite : " + balance);
		notify();

		
	}


}
