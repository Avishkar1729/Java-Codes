package com.synchronization;

public class Sync2_thread1 extends Thread {
	
	Sync2_table tobj;
	
	Sync2_thread1(Sync2_table obj) {
		tobj = obj;
	}

	public void run() {
		tobj.printTable(8);
//		Sync2_table.printTable(8);
	}

}
