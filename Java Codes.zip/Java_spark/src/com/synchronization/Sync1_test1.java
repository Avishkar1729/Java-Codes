package com.synchronization;

public class Sync1_test1 {

	public static void main(String[] args) {

		Sync1_table obj = new Sync1_table();
		
		
		Sync1_thread1 st1 = new Sync1_thread1(obj);
		Sync1_thread2 st2 = new Sync1_thread2(obj);
		
		st1.setName("st1");
		st2.setName("st2");
		
		st1.start();
		st2.start();
 	}

}
