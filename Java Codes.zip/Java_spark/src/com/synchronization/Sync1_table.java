package com.synchronization;

public class Sync1_table {
	
	// synchronized method
	
//	synchronized void printTable(int num) {
//		
//		for(int i=1;i<=10;i++) {
//			System.out.println(i*num + " : " + Thread.currentThread().getName());
//			
//			try {
//				Thread.sleep(1000);
//			}
//			
//			catch(Exception e) {
//				e.printStackTrace();
//			}
//		}
	
	
	// synchronized block
	
	void printTable(int num) {
		
		System.out.println("Starting phase 1");
		System.out.println("Strating phase 2");
		
		synchronized(this) {
			for(int i=1;i<=10;i++) {
				System.out.println(i*num + " : " + Thread.currentThread().getName());
				
				try {
					Thread.sleep(1000);
				}
				
				catch(Exception e) {
					e.printStackTrace();
				}
				
			}
		}
		
		
		System.out.println("Ending phase 1");
		System.out.println("Ending phase 2");
		

		
	}

}
