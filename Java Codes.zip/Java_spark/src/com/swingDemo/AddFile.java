package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AddFile extends JFrame {
    JButton browseButton;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddFile frame = new AddFile();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddFile() {
        setTitle("File Chooser Example");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        browseButton = new JButton("Browse");
        //browseButton.addActionListener(this);
        
        JPanel panel = new JPanel();
        panel.add(browseButton);
        
        add(panel);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == browseButton) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                JOptionPane.showMessageDialog(this, "You selected: " + selectedFile.getAbsolutePath());
            }
        }
	}

}
