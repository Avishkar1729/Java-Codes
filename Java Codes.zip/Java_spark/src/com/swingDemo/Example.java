package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Example extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Example frame = new Example();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Example() {

        setTitle("Product Catalog");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        // Create a panel with GridLayout
        JPanel panel = new JPanel(new GridLayout(3, 1));

        // Sample product data
        String[] products = {"Product A", "Product B", "Product C","Product A", "Product B", "Product C"};
        double[] prices = {10.0, 20.0, 30.0, 40.0, 50.0, 60.0};

        // Add product items to the panel
        for (int i = 0; i < products.length; i++) {
            String productName = products[i];
            double productPrice = prices[i];

            JPanel productPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

            JLabel nameLabel = new JLabel(productName);
            JLabel priceLabel = new JLabel("$" + productPrice);
            JButton buyButton = new JButton("Buy Now");

            buyButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Here you can add your buy logic, for example, opening a new window, or showing a message
                    JOptionPane.showMessageDialog(null, "You bought " + productName + " for $" + productPrice);
                }
            });

            productPanel.add(nameLabel);
            productPanel.add(priceLabel);
            productPanel.add(buyButton);

            panel.add(productPanel);
        }

        add(panel);

        setVisible(true);

		
	}

}
