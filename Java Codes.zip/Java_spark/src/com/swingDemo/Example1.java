package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Example1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Example1 frame = new Example1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Example1() {
        setTitle("Product Catalog");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        // Create panel with GridLayout
        JPanel panel = new JPanel(new GridLayout(3,1));

        // Sample product data (replace with your actual data)
        String[] products = {"Product 1", "Product 2", "Product 3","Product 4","Product 5","Product 6"};
        String[] imagePaths = {"C:\\\\Users\\\\Info\\\\Documents\\\\sample.png", "C:\\\\Users\\\\Info\\\\Documents\\\\sample.png", "C:\\\\Users\\\\Info\\\\Documents\\\\sample.png","C:\\Users\\Info\\Documents\\sample.png","C:\\Users\\Info\\Documents\\sample.png","C:\\Users\\Info\\Documents\\sample.png"};
        double[] prices = {10.99, 20.49, 15.79, 12.3, 15.8,16.9};

        // Add products to the panel
        for (int i = 0; i < products.length; i++) {
            panel.add(createProductPanel(products[i], imagePaths[i], prices[i]));
        }

        // Add panel to the frame
        add(new JScrollPane(panel));

        setVisible(true);
    }

    private JPanel createProductPanel(String productName, String imagePath, double price) {
        JPanel productPanel = new JPanel(new BorderLayout());
        JLabel nameLabel = new JLabel(productName);
        JLabel priceLabel = new JLabel("$" + price);
        JButton buyButton = new JButton("Buy Now");

        // Load and scale image
        ImageIcon icon = new ImageIcon(imagePath);
        Image image = icon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        JLabel imageLabel = new JLabel(new ImageIcon(image));

        // Add components to the product panel
        productPanel.add(imageLabel, BorderLayout.WEST);
        JPanel infoPanel = new JPanel(new GridLayout(0, 1));
        infoPanel.add(nameLabel);
        infoPanel.add(priceLabel);
        productPanel.add(infoPanel, BorderLayout.CENTER);
        productPanel.add(buyButton, BorderLayout.SOUTH);

        // Action listener for the Buy Now button
        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show product details
                JOptionPane.showMessageDialog(null,"Product: " + productName + "\nPrice: $" + price);
            }
        });

        return productPanel;
	}

}
