package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextField;

public class SecondFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	JTextField fName;
	JTextField lName;
	JTextField age;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SecondFrame frame = new SecondFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SecondFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 472, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Form");
		lblNewLabel.setBackground(Color.ORANGE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(102, 47, 154, 48);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String st1 = fName.getText();
				String st2 = lName.getText();
				String st3 = age.getText();
				
				FirstFrame obj2 = new FirstFrame();
				obj2.setVisible(true);
				
				obj2.lbl1.setText(st1);
				obj2.lbl2.setText(st2);
				obj2.lbl3.setText(st3);

				
				dispose();
				
				
			}
		});
		btnNewButton.setBounds(136, 245, 85, 21);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("First Name :- ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1.setBounds(89, 114, 85, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Last Name :- ");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1_1.setBounds(89, 153, 85, 13);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Age :- ");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_1_1_1.setBounds(89, 193, 85, 13);
		contentPane.add(lblNewLabel_1_1_1);
		
		fName = new JTextField();
		fName.setColumns(20);
		fName.setBounds(184, 111, 96, 19);
		contentPane.add(fName);
		
		lName = new JTextField();
		lName.setColumns(20);
		lName.setBounds(184, 150, 96, 19);
		contentPane.add(lName);
		
		age = new JTextField();
		age.setColumns(20);
		age.setBounds(184, 190, 96, 19);
		contentPane.add(age);
	}
}
