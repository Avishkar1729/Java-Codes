package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.Box;
import javax.swing.JMenuBar;
import java.awt.Color;
import javax.swing.JCheckBox;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JToggleButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class Page1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Page1 frame = new Page1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Page1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 650);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 235, 215));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JCheckBox cb1 = new JCheckBox("Mango Juice");
		cb1.setHorizontalAlignment(SwingConstants.CENTER);
		cb1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb1.setBounds(52, 208, 116, 30);
		contentPane.add(cb1);
		
		JCheckBox cb2 = new JCheckBox("Lemon Juice");
		cb2.setHorizontalAlignment(SwingConstants.CENTER);
		cb2.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb2.setBounds(52, 253, 116, 30);
		contentPane.add(cb2);
		
		JCheckBox cb3 = new JCheckBox("Orange Juice");
		cb3.setHorizontalAlignment(SwingConstants.CENTER);
		cb3.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb3.setBounds(52, 298, 116, 30);
		contentPane.add(cb3);
		
		JCheckBox cb4 = new JCheckBox("Pineapple Juice");
		cb4.setHorizontalAlignment(SwingConstants.CENTER);
		cb4.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb4.setBounds(52, 343, 116, 30);
		contentPane.add(cb4);
		
		JCheckBox cb5 = new JCheckBox("Apple Juice");
		cb5.setHorizontalAlignment(SwingConstants.CENTER);
		cb5.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb5.setBounds(52, 388, 116, 30);
		contentPane.add(cb5);
		
		JCheckBox cb6 = new JCheckBox("Fruit Plate Mix");
		cb6.setHorizontalAlignment(SwingConstants.CENTER);
		cb6.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb6.setBounds(372, 298, 116, 30);
		contentPane.add(cb6);
		
		JCheckBox cb11 = new JCheckBox("Apple Plate");
		cb11.setHorizontalAlignment(SwingConstants.CENTER);
		cb11.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb11.setBounds(651, 388, 116, 30);
		contentPane.add(cb11);
		
		JCheckBox cb10 = new JCheckBox("Pineapple Plate");
		cb10.setHorizontalAlignment(SwingConstants.CENTER);
		cb10.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb10.setBounds(651, 343, 116, 30);
		contentPane.add(cb10);
		
		JCheckBox cb9 = new JCheckBox("Orange Plate");
		cb9.setHorizontalAlignment(SwingConstants.CENTER);
		cb9.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb9.setBounds(651, 298, 116, 30);
		contentPane.add(cb9);
		
		JCheckBox cb8 = new JCheckBox("Lemon Plate");
		cb8.setHorizontalAlignment(SwingConstants.CENTER);
		cb8.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb8.setBounds(651, 253, 116, 30);
		contentPane.add(cb8);
		
		JCheckBox cb7 = new JCheckBox("Mango plate");
		cb7.setHorizontalAlignment(SwingConstants.CENTER);
		cb7.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		cb7.setBounds(651, 208, 116, 30);
		contentPane.add(cb7);
		
		JToggleButton orderBtn = new JToggleButton("Order Now");
		orderBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			}
		});
		orderBtn.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		orderBtn.setBackground(new Color(233, 150, 122));
		orderBtn.setBounds(373, 499, 122, 45);
		contentPane.add(orderBtn);
	}
}
