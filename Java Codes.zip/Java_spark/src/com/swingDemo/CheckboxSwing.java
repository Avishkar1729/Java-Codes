package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class CheckboxSwing extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckboxSwing frame = new CheckboxSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CheckboxSwing() {
		
		JRadioButton radioBtn1;
		JRadioButton radioBtn2;
		JRadioButton radioBtn3;

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 747, 749);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Data Form");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(263, 34, 175, 42);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(120, 131, 133, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Email");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(120, 201, 133, 30);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Contact");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(120, 271, 133, 30);
		contentPane.add(lblNewLabel_1_2);
		
		textField = new JTextField();
		textField.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		textField.setBounds(334, 130, 275, 35);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		textField_1.setColumns(10);
		textField_1.setBounds(334, 200, 275, 35);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 14));
		textField_2.setColumns(10);
		textField_2.setBounds(334, 270, 275, 35);
		contentPane.add(textField_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Gender");
		lblNewLabel_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2_1.setBounds(120, 330, 133, 30);
		contentPane.add(lblNewLabel_1_2_1);
		
		radioBtn1 = new JRadioButton("Male");
		radioBtn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(radioBtn1.isSelected()) {
					//radioBtn2.setSelected(false);
				}
				
			}
		});
		radioBtn1.setBackground(SystemColor.activeCaption);
		radioBtn1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		radioBtn1.setBounds(335, 337, 59, 21);
		contentPane.add(radioBtn1);
		
		radioBtn2 = new JRadioButton("Female");
		radioBtn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(radioBtn2.isSelected()) {
					radioBtn1.setSelected(false);
					//radioBtn3.setSelected(false);
				}
			}
		});
		radioBtn2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		radioBtn2.setBackground(SystemColor.activeCaption);
		radioBtn2.setBounds(434, 336, 69, 21);
		contentPane.add(radioBtn2);
		
		radioBtn3 = new JRadioButton("Others");
		radioBtn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(radioBtn3.isSelected()) {
					radioBtn2.setSelected(false);
					radioBtn1.setSelected(false);
				}
			}
		});
		radioBtn3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		radioBtn3.setBackground(SystemColor.activeCaption);
		radioBtn3.setBounds(540, 336, 69, 21);
		contentPane.add(radioBtn3);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(radioBtn1);
		bg.add(radioBtn2);
		bg.add(radioBtn3);
		
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("Subjects");
		lblNewLabel_1_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2_1_1.setBounds(120, 386, 133, 30);
		contentPane.add(lblNewLabel_1_2_1_1);
		
		JCheckBox checkBox1 = new JCheckBox("Java");
		checkBox1.setSelected(true);
		checkBox1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkBox1.setBackground(SystemColor.activeCaption);
		checkBox1.setBounds(334, 393, 120, 21);
		contentPane.add(checkBox1);
		
		JCheckBox checkBox2 = new JCheckBox("C");
		checkBox2.setSelected(true);
		checkBox2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkBox2.setBackground(SystemColor.activeCaption);
		checkBox2.setBounds(489, 393, 120, 21);
		contentPane.add(checkBox2);
		
		JCheckBox checkBox3 = new JCheckBox("C++");
		checkBox3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkBox3.setBackground(SystemColor.activeCaption);
		checkBox3.setBounds(334, 433, 120, 21);
		contentPane.add(checkBox3);
		
		JCheckBox checkBox4 = new JCheckBox("Python");
		checkBox4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkBox4.setBackground(SystemColor.activeCaption);
		checkBox4.setBounds(489, 433, 120, 21);
		contentPane.add(checkBox4);
		
		JCheckBox checkBox5 = new JCheckBox("HTML");
		checkBox5.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkBox5.setBackground(SystemColor.activeCaption);
		checkBox5.setBounds(334, 475, 120, 21);
		contentPane.add(checkBox5);
		
		JCheckBox checkBox6 = new JCheckBox("Javascript");
		checkBox6.setFont(new Font("Tahoma", Font.PLAIN, 12));
		checkBox6.setBackground(SystemColor.activeCaption);
		checkBox6.setBounds(489, 475, 120, 21);
		contentPane.add(checkBox6);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBackground(Color.CYAN);
		btnSubmit.setForeground(Color.BLACK);
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String gender = null;
				 
				 if(radioBtn1.isSelected())
				 {
					 //gender = "Male";
					 gender = radioBtn1.getText();
				 }
				 else if(radioBtn2.isSelected())
				 {
					 gender = "Female";
				 }
				 else 
				 {
					 gender = "Other";
				 }
				 
				 System.out.println("gender : "+gender);
				 
				 
				 if(checkBox1.isSelected())
				 {
					 System.out.println(checkBox1.getText());
				 }
				 if(checkBox2.isSelected())
				 {
					 System.out.println(checkBox2.getText());
				 }
				 if(checkBox3.isSelected())
				 {
					 System.out.println(checkBox3.getText());
				 }
				 if(checkBox4.isSelected())
				 {
					 System.out.println(checkBox4.getText());
				 }
				 if(checkBox5.isSelected())
				 {
					 System.out.println(checkBox5.getText());
				 }
				 if(checkBox6.isSelected())
				 {
					 System.out.println(checkBox6.getText());
				 }
				 
				 
				
			}
		});
		btnSubmit.setBounds(263, 550, 150, 42);
		contentPane.add(btnSubmit);
	}
}
