package com.swingDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.*;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;

public class DBFunction {
	
	Connection con; // Connection interface that has capability to store reference of connection

	public void getConnection() {

		try {

			Class.forName("com.mysql.cj.jdbc.Driver"); // driver name/path

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/swingdb", "root", ""); // connection established
																								// and get reference

			System.out.println("Connection Established!!!");
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createDB() {

		try {
			// connection with mysql

			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "");

			System.out.println("Connection Established!!!");
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		// create database

		try {

			Statement st = con.createStatement();

			String query = "create database fruitbar";
			st.executeUpdate(query);
			System.out.println("Database create successfully");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void createTable() {

		try {
			// connection with database

			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fruitbar", "root", "");

			System.out.println("Connection Established!!!");
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		// create table

		try {

			Statement st = con.createStatement();

			String query = "create table userInfo(uname varchar(20), email varchar(20) primary key, mob varchar(20), addr varchar(20), pass varchar(20))";
			st.executeUpdate(query);
			System.out.println("Table create successfully");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readAllData() {

		try {
			
			getConnection();

			Statement st = con.createStatement();
			// Statement interface has method executeQuery()
			// Connection interface has method createStatement()

			ResultSet rs; // It has use to store elements

			String query = "select * from students";
			rs = st.executeQuery(query);

			while (rs.next()) {
				System.out.println("Name : " + rs.getString(1) + "\tRoll No : " + rs.getInt(2));
			}
			
			System.out.println("***************************************");


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	ResultSet readData(String email) {

		ResultSet rs = null;;

		
		try {
			
			getConnection();

			Statement st = con.createStatement();


			String query = "select * from empInfo where email = '"+email+"'";
			rs = st.executeQuery(query);

//			while (rs.next()) {
//				System.out.println("UserName : " + rs.getString(1) + "\nEmail : " + rs.getString(2));
//			}
			
			return rs;

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return rs;

	}

	public void insertData() {
		try {

			Statement st = con.createStatement();

			String query = "INSERT INTO students VALUES ('Mahi',4)";
			st.executeUpdate(query);
			System.out.println("Data insert successful");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insertData(String uname, String email, String mob, String addr, String pass) {
		
		int res  = 0;
		try {
			getConnection();
			String query = "INSERT INTO empInfo VALUES (?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(query);
			// PreparedStatement use for parameterized query

			ps.setString(1, uname);
			ps.setString(2, email);
			ps.setString(3, mob);
			ps.setString(4, addr);
			ps.setString(5, pass);


			res = ps.executeUpdate();

			System.out.println("Data insert successful");
			
			return res;
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return res;
	}
	
	public void insertImage() {
		try {

			Statement st = con.createStatement();

			String query = "INSERT INTO students VALUES('sample1',8,123456,LOAD_FILE('C:\\Users\\Info\\Documents\\sample.png'));";
			st.executeUpdate(query);
			System.out.println("Image insert successful");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public void delete() {
		try {
			Statement st = con.createStatement();

			String sql = "delete from students where rNo = 4";

			st.executeUpdate(sql);
			System.out.println("Deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(int roll) {
		try {
			Statement st = con.createStatement();

			String sql = "delete from students where rNo = " + roll;

			st.executeUpdate(sql);
			System.out.println("Deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(String name) {
		try {
			String sql = "delete from students where Name = ?";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, name); // 1 is for first ?

			ps.executeUpdate();
			System.out.println("Deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update() {
		try {
			Statement st = con.createStatement();

			String sql = "update students set Name = 'Axar Patel' where rNo = 2";

			st.executeUpdate(sql);

			System.out.println("Update successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateUser(int id, String name) {
		try {
			String sql = "update students set Name = ? where rNo = ?";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, name);
			ps.setInt(2, id);

			ps.executeUpdate();
			System.out.println("Update successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void alterTable() {
		try {
			Statement st = con.createStatement();

			String sql = "alter table students add image varchar(100)";

			st.executeUpdate(sql);

			System.out.println("Table update successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void fetchData() {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver"); // driver name/path

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/swingdb", "root", "");
			
	        // Create statement
	        Statement st = con.createStatement();

	        String sql = "SELECT * FROM empinfo";
	        
	        ResultSet rs = st.executeQuery(sql);

	        
	        // Get metadata
	        ResultSetMetaData rsmd = rs.getMetaData();
	        
	        
	        Example3 exObj = new Example3();

	        // Create columns in the table model
	        DefaultTableModel model = (DefaultTableModel) exObj.table.getModel();
	        
	        int columnCount = rsmd.getColumnCount();
	        String[] colName = new String [columnCount];

	        for (int i = 0; i < columnCount; i++) {
	        	colName[i] = rsmd.getColumnName(i+1);
	        	model.setColumnIdentifiers(colName);
	            //model.addColumn(metaData.getColumnName(i));
	        }
	//
//	        // Fetch rows and add them to the table model
	        String uname=null,email=null,mob=null,addr=null,pass=null;
	        while (rs.next()) {
	            uname = rs.getString(1);
	            email = rs.getString(2);
	            mob = rs.getString(3);
	            addr = rs.getString(4);
	            pass = rs.getString(5);
	            }
	        	String [] row = {uname,email,mob,addr,pass};
	        	System.out.println("uname"+uname);
	            model.addRow(row);
	        }
			
			catch(Exception ae) {
				ae.printStackTrace();
			}
		
	}

}
