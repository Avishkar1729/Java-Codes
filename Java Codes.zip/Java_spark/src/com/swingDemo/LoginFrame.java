package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextPane;

public class LoginFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUname;
	private JTextField txtEmail;
	private JPasswordField txtPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(35, 63, 129, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEmail.setBounds(35, 137, 129, 33);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPassword.setBounds(35, 209, 129, 33);
		contentPane.add(lblPassword);
		
		txtUname = new JTextField();
		txtUname.setFont(new Font("MS Reference Sans Serif", Font.PLAIN, 14));
		txtUname.setBounds(189, 64, 195, 33);
		contentPane.add(txtUname);
		txtUname.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("MS Reference Sans Serif", Font.PLAIN, 14));
		txtEmail.setColumns(10);
		txtEmail.setBounds(189, 138, 195, 33);
		contentPane.add(txtEmail);
		
		txtPass = new JPasswordField();
		txtPass.setFont(new Font("MS Reference Sans Serif", Font.PLAIN, 14));
		txtPass.setBounds(189, 213, 195, 33);
		contentPane.add(txtPass);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String uname = txtUname.getText();
				String email = txtEmail.getText();
				String pass = txtPass.getText();
				
				DBFunction dbf = new DBFunction();
				ResultSet rs = dbf.readData(email);
				
				String tempUser=null,tempPass=null;
				
				int flag = 0;
				
				try {
					while(rs.next()) {
						flag = 1;
						tempUser = rs.getString(1);
						tempPass = rs.getString(5);
					}
					
				}
				catch(Exception ex){
					ex.printStackTrace();
				}
				
//				System.out.println("temp User : " + tempUser);
//				System.out.println("temp Pass : " + tempPass);
				
				
				if(flag==1) {
					if(uname.equals(tempUser) && pass.equals(tempPass) ) {
						//System.out.println("Login Successful");
						JOptionPane.showMessageDialog(btnSubmit, "Login Successful");
					}
					
					else {
						//System.out.println("Login UnSuccessful");
						JOptionPane.showMessageDialog(btnSubmit, "Login UnSuccessful");
					}
				}
				else {
					//System.out.println("Please enter valid email");
					JOptionPane.showMessageDialog(btnSubmit, "Please enter valid email");
				}

				
				
			}
		});
		btnSubmit.setBackground(new Color(0, 255, 255));
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSubmit.setBounds(92, 300, 107, 39);
		contentPane.add(btnSubmit);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBackground(new Color(250, 128, 114));
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DBFrame dbf = new DBFrame();
				dbf.setVisible(true);
				dispose();
			}
		});
		btnRegister.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnRegister.setBounds(276, 300, 107, 39);
		contentPane.add(btnRegister);
	}
}
