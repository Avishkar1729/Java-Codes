package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Demo1Servlet extends HttpServlet{
	
	protected void service (HttpServletRequest req, HttpServletResponse resp) throws IOException,ServletException {
		
		String st1 = req.getParameter("email");
		String st2 = req.getParameter("pass");
		
		PrintWriter pw = resp.getWriter();
		
		//1.
		
//		pw.println("Email : " + st1);
//		pw.println("Password : " + st2);
		
		//2.RD
		
//		req.setAttribute("email", st1);
//		req.setAttribute("pass", st2);
//		
//		RequestDispatcher rd = req.getRequestDispatcher("dpd");
//		rd.forward(req, resp);
		
		
		// 3. using cookie
		
		Cookie ck1 = new Cookie("email", st1);
		Cookie ck2 = new Cookie("pass", st2);
		
		resp.addCookie(ck1);
		resp.addCookie(ck2);
		
		resp.sendRedirect("dpd");
		
		

		
		
		
	}

}
