package com.StringDemo;

import java.util.Scanner;

public class StrCon {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your firstname and lastname: \n");
		String name = sc.nextLine();
		
		System.out.println("Enter your middle name : ");
		String mName = sc.next();
		
		name = name.trim();
		
		name = name.replace(' '+"", mName);
		
		System.out.println(name);
		
		
	}

}
