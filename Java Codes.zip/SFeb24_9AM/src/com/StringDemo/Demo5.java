package com.StringDemo;

public class Demo5{

	public static void main(String[] args) {
		
		String s1 = "virat";
		String s2 = "virat";
		String s3 = new String("virat");
		
		
		System.out.println(s1 == s2);//true
		System.out.println(s1 == s3);//false
		System.out.println(s1.equals(s2));//true
		System.out.println(s1.equals(s3));//true

	}

}
