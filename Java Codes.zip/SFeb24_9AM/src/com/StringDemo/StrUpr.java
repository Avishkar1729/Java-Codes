package com.StringDemo;

import java.util.Arrays;
import java.util.Scanner;

public class StrUpr {
	
	Scanner sc = new Scanner(System.in);
	String name = null;
	StrUpr()
	{
		System.out.println("Enter your name : ");
		name = sc.next();
		System.out.println("Original Name : "+name);
	}
	
	void convert()
	{
		char arr[] = name.toCharArray();
		
		for(int i = 0; i < arr.length; i++)
		{
			if(Character.isUpperCase(arr[i]))
			{				
				arr[i] = Character.toLowerCase(arr[i]);
			}
			else
			{
				
				arr[i] = Character.toUpperCase(arr[i]);
			}
		}
		
		
		
		System.out.println(arr);
	}

	public static void main(String[] args) {
		
		StrUpr obj = new StrUpr();
		obj.convert();
	}

}
