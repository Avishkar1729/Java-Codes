package com.StringDemo;

public class Demo6 {

	public static void main(String[] args) {
		
		String s1 = "abg";
		String s2 = "abc";
		
		System.out.println(s1.compareTo(s2));
		

	}

}
