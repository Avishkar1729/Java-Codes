package com.StringDemo;

public class StringDemo {

	public static void main(String[] args) {
		/*
		String s1 = "Ram";
		System.out.println("s1 : "+s1);
		
		char ch[] = {'a','m','a','n'};
		String s2 = new String(ch);
		
		System.out.println("s2 : "+s2);
		
		String s3 = new String("Sita");
		System.out.println("s3 : "+s3);
		
		//charAt
		String str = "Ajay";
		char c = str.charAt(2);
		System.out.println("c : "+c);
	*/
		//String str = "Ajay"; 
		//System.out.println("len : "+str.length());
		
		/*
		String str = "Ajay abc varma ";
		
		String temp = str.substring(5);
		System.out.println("temp : "+temp);
		System.out.println("value : "+str.substring(8));
		
		System.out.println(str.substring(5, 8));
		*/
	/*
		String str = "virat kohli rcb";
		
		boolean temp = str.contains("RCB");
		System.out.println(temp);
		*/
		
		/*
		String str = "AjAy";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		*/
		
		
		//String str = "Ajay";
		//String temp = "Ajay";
		
		/*
		String str = new String("Ajay");
		String temp = new String("Ajay");
		
		System.out.println(str.equals(temp));
		
		if(str == temp)
		{
			System.out.println("inside if");
		}
		else
		{
			System.out.println("else");
		}
		
		*/
		
		/*
		String str = " ";
		System.out.println(str.isEmpty());
		*/
		/*
		String str = "Ajay";
		String temp = "ajay";
		
		System.out.println(str.equalsIgnoreCase(temp));
		*/
		
		/*
		String str = "Ajay";
		String temp = "sharma";
		System.out.println(str.concat("Kohli"));
		System.out.println(str.concat(temp));
		
		*/
		
		/*
		String str = "jam";
		System.out.println(str.replace('j', 'r'));
		*/
		/*
		String str = "my name is aman burghate";
		String arr[] = str.split("name");
		
		for(String temp : arr)
		{
			System.out.println(temp);
		}
		
		*/
		/*
		String str = "     my name is virat kohli  ";
		System.out.println("str : "+str+"\nstr len : "+str.length());
		String temp = str.trim();
		System.out.println("temp : "+temp+"\nstr len : "+temp.length());
		*/
		
		String str = "ajay sharma";
		System.out.println(str.indexOf("a"));
		
		
		
		
	}

}
