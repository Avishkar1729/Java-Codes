package com.StringDemo;

public final class Emp {
	
	final int age;
	final String name;
	
	
	Emp(int a, String nm)
	{
		age = a;
		name = nm;
	}
	
	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public static void main(String str[])
	{
		Emp obj = new Emp(18,"virat");
		
		System.out.println(obj.getAge());
		System.out.println(obj.getName());
	}

}
