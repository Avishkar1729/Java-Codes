package com.Arr;

import java.util.Scanner;

public class Pattern1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of rows : ");
		int row = sc.nextInt();
		
		System.out.println("Enter number of cols : ");
		int col = sc.nextInt();
		
		int arr[][] = new int[row][col];
		
		
		
		System.out.println("pattern : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				System.out.print("*\t");
			}
			System.out.println();
		}
		
		System.out.println("displaying right diagonal");
		
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i == j)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
			}
			System.out.println();
			
		}

		System.out.println("displaying left diagonal");
		
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i+j == row-1)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
				
			}	
			System.out.println();
		}
		
		
		
		
		System.out.println("displaying right tringle : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i >= j)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
			}
			System.out.println();
		}
		
		
		
		System.out.println("Displaying right tringle : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i <= j)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
			}	
			System.out.println();
		}
		
		
		System.out.println("Displaying upper left tringle : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i + j <= row-1)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
			}	
			System.out.println();
		}
		
		
		System.out.println("Displaying upper right tringle : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i + j >= row-1)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
			}	
			System.out.println();
		}
		
		
		System.out.println("Displaying hollow square elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i == 0 || i == row-1 || j == 0 || j == col-1)
				{
					System.out.print("*\t");
				}
				else
				{
					System.out.print(" \t");
				}
			}
			System.out.println();
		}
		
		
		System.out.println("Displaying diamond elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i % 2 == 0)
				{
					if(j % 2 != 0)
					{
						System.out.print("*\t");
					}
					else
					{
						System.out.print(" \t");
					}
				}
				else
				{
					if(j % 2 == 0)
					{
						System.out.print("*\t");
					}
					else
					{
						System.out.print(" \t");
					}
				}
				
			}
			System.out.println();
		}
	}

}

