package com.Arr;

public class TransposeDemo {
	
	    public static void main(String[] args) 
	    {
	        // Define the matrix
	        int[][] matrix = {
	            {1, 2},
	            {3, 4}
	        };

	        // Transpose the matrix
	        int rows = matrix.length;
	        int cols = matrix[1].length;
	       // int[][] transposeMatrix = new int[cols][rows];
	        
	        int transposeMatrix[][] = new int[cols][rows];
	        for (int i = 0; i < rows; i++) 
	        {
	            for (int j = 0; j < cols; j++) 
	            {
	                transposeMatrix[j][i] = matrix[i][j];
	            }
	        }

	        // Display the original matrix
	        System.out.println("Original Matrix:");
	        displayMatrix(matrix);

	        // Display the transpose matrix
	        System.out.println("Transpose Matrix:");
	        displayMatrix(transposeMatrix);
	    }

	    // Method to display the matrix
	    public static void displayMatrix(int[][] matrix)
	    {
	        for (int i = 0; i < matrix.length; i++)
	        {
	            for (int j = 0; j < matrix[0].length; j++) 
	            {
	                System.out.print(matrix[i][j] + " ");
	            }
	            
	            System.out.println();
	        }
	    }

}
