package com.Arr;

import java.util.Scanner;

public class Arr2DDemo2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of rows : ");
		int row = sc.nextInt();
		
		System.out.println("Enter number of cols : ");
		int col = sc.nextInt();
		
		int arr[][] = new int[row][col];
		
		System.out.println("Enter the array elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				System.out.print("Enter the value for arr["+i+"]["+j+"] : ");
				arr[i][j] = sc.nextInt();
			}
		}
		   
		System.out.println("Displaying array elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		
		/*
		int sum = 0;
		//System.out.println("Addition of all array elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				sum = sum + arr[i][j];
			}
			
		}
		
		System.out.println("Addition of all elements : "+sum);
		
		int drsum = 0;
		//System.out.println("Addition of right diagonal elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i == j)
				{
					drsum = drsum + arr[i][j];
				}
			}
			
		}

		System.out.println("Addition of right diagonal elements : "+drsum);
		
		
		int dlsum = 0;
		//System.out.println("Addition of left diagonal elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i+j == row-1)
				dlsum = dlsum + arr[i][j];
			}	
		}
		
		System.out.println("Addition of left diagonal elements : "+dlsum);
		
		
		int rtsum = 0;
		//System.out.println("Addition of right tringle elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i >= j)
				{
					rtsum = rtsum + arr[i][j];
				}
			}	
		}
		
		System.out.println("Addition of right tringle elements : "+rtsum);
		
		int ltsum = 0;
		//System.out.println("Addition of right tringle elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i <= j)
				{
					ltsum = ltsum + arr[i][j];
				}
			}	
		}
		
		System.out.println("Addition of left tringle elements : "+ltsum);
		
		
		int ultsum = 0;
		//System.out.println("Addition of upper left tringle elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i + j <= row-1)
				{
					ultsum = ultsum + arr[i][j];
				}
			}	
		}
		
		System.out.println("Addition of upper left tringle elements : "+ultsum);
		
		int urtsum = 0;
		//System.out.println("Addition of upper right tringle elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i + j >= row-1)
				{
					urtsum = urtsum + arr[i][j];
				}
			}	
		}
		
		System.out.println("Addition of upper right tringle elements : "+urtsum);
		
		
		int hssum = 0;
		//System.out.println("Addition of hollow square elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i == 0 || i == row-1 || j == 0 || j == col-1)
				{
					hssum = hssum + arr[i][j];
				}
			}	
		}
		
		System.out.println("Addition of hollow square elements : "+hssum);
		*/
		
		int diamond = 0;
		//System.out.println("Addition diamond elements : ");
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < col; j++)
			{
				if(i % 2 == 0)
				{
					if(j % 2 != 0)
					{
						diamond = diamond + arr[i][j];
					}
				}
				else
				{
					if(j % 2 == 0)
					{
						diamond = diamond + arr[i][j];
					}
				}
				
			}	
		}
		
		System.out.println("Addition of diamond elements : "+diamond);
		

	}

}
