package com.Arr;

import java.util.Scanner;

public class ArrDemo1 {
	
	
	static void sortArr(int arr[])
	{
		
		for(int i = 0; i < arr.length; i++)
		{
			for(int j = i + 1; j < arr.length; j++)
			{
				if(arr[i] > arr[j])
				{
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		
		System.out.println("\nAfter sorting ");
		display(arr);
		
	}
	
	static void display(int arr[])
	{
		System.out.println("Displaying array eleemnts : ");
		
		for(int temp : arr)
		{
			System.out.print(temp+"\t");
		}
	}
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		/*
		int arr[] = new int[5];
		arr[0] = 100;
		arr[1] = 200;
		arr[2] = 300;
		arr[3] = 400;
		arr[4] = 45;
		*/
		
		//int arr[] = {100,34,12,18,45,17,18};
		
		System.out.println("Enter the size of array : ");
		int size = sc.nextInt();
		
		int arr[] = new int[size];
		
		System.out.println("Enter the elements : ");
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = sc.nextInt();
			
		}
		  
		
		display(arr);
		sortArr(arr);
		
		
		/*
		for(int i = 0; i < arr.length; i++)
		{
			System.out.print(arr[i]+"\t");
		}*/
	}

}
