package com.demo2;

public interface A100 {
	
	int a = 10;   
	void draw();
	void msg();
	
	static void gun()
	{
		System.out.println("Inside gun method A100");
	}
	
	default void call()
	{
		virat();
	}
	
	private void virat()
	{
		System.out.println("Inside vk18");
	}
	
	
}
