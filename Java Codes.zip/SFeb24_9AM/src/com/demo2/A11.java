package com.demo2;

public interface A11 {
	
	void show();
	void rk();

}
