package com.demo2;

public class C1 extends B1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
