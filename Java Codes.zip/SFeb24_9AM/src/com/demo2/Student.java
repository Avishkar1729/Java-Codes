package com.demo2;

public class Student {
	
	private int rNo;
	private String name;
	private float mks;
	
	public void setrNo(int rNo)
	{
		this.rNo = rNo;
	}
	
	public void setname(String name)
	{
		this.name = name;
	}
	
	public void setmks(float mks)
	{
		this.mks = mks;
	}
	
	public int getrNo()
	{
		return rNo;
	}
	
	public String getname()
	{
		return name;
	}
	
	public float getmks()
	{
		return mks;
	}
	

}
