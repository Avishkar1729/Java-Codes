package com.demo2;

public interface B100 {
	
	void sun();
	
	void gun();

}
