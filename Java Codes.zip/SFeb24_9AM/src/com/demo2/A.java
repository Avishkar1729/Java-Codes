package com.demo2;

import com.DemoCodes.AccessModfireDemo;

public class A {

	public static void main(String[] args) {
		
		AccessModfireDemo obj = new AccessModfireDemo();

	}

}
