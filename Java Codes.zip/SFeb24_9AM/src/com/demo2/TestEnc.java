package com.demo2;

public class TestEnc {

	public static void main(String[] args) {
		
		Student st = new Student();
		
		st.setrNo(11);
		st.setname("Ramji");
		st.setmks(100);
		
		System.out.println("Roll number : "+st.getrNo());
		System.out.println("name : "+st.getname());
		System.out.println("mks : "+st.getmks());

	}

}
