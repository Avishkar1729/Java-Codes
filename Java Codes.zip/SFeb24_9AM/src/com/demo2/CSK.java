package com.demo2;

public interface CSK extends MI{
	
	void thala();

}
