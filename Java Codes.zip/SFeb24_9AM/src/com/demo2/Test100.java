package com.demo2;

public class Test100 implements A100,B100{
	
	public void draw()
	{
		System.out.println("Inside draw");
	}
	
	public void msg()
	{
		System.out.println("Inside message");
	}
	
	public void sun()
	{
		System.out.println("Inside sun");
	}
	
	public void gun()
	{
		System.out.println("gun");
	}
	
	public static void main(String[] args) {
		
		Test100 obj = new Test100();
		
		obj.draw();
		obj.msg();
		obj.sun();
		obj.gun();
		A100.gun();
		obj.call();
	
	}

}
