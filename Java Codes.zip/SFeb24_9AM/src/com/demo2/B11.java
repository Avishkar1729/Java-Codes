package com.demo2;

public interface B11 {
	
	void show();
	void vk();
}
