package com.demo2;

public class Test2 implements CSK{
	
	public void rohit()
	{
		System.out.println("hitman");
	}
	
	public void thala()
	{
		System.out.println("Thala for reason");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Test2 obj = new Test2();
		obj.rohit();
		obj.thala();
	}

}
