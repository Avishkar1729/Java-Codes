package com.demo2;

public class B1 {
	
	void vk()
	{
		System.out.println("VK18");
	}
	
	void show()
	{
		System.out.println("inside show of B1");
	}
}
