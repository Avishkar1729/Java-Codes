package com.demo2;

public interface Printable {
	
	int a = 10; // public static final int a = 10;
	void display();//public abstract void display();
	void print();

}
