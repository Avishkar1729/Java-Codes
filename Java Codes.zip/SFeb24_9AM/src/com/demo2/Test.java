package com.demo2;

public class Test implements Printable{
	
	public void display()
	{
		System.out.println("hello abhi");
	}
	
	public void print()
	{
		System.out.println("hello MAhis");
	}
	
	

	public static void main(String[] args) {
		
		Test obj = new Test();
		obj.display();
		obj.print();
		System.out.println("a : "+obj.a);
	}

}
