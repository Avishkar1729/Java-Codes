package com.demo2;

public interface MI {
	
	void rohit();

}
