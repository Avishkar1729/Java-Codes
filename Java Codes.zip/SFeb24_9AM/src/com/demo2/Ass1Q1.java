package com.demo2;

public class Ass1Q1 {
	
	
	void fun(int n, int t)
	{ 
		  
		if(n <= 10)
		{
			System.out.print(n*t+"\t");
			
			fun(++n,t);
		}
		
		
	}

	public static void main(String[] args) {
		
		Ass1Q1 obj = new Ass1Q1();
		int n = 1, t = 7;
		obj.fun(n,t);

	}

}
