package com.demo2;

public class Test11 implements A11,B11{
	
	public void show()
	{
		System.out.println("Inside show");
	}
	
	public void rk()
	{
		System.out.println("Inside rk");
	}
	
	public void vk()
	{
		System.out.println("Inside vk18");
	}

	public static void main(String[] args) {
		
		
		Test11 obj = new Test11();
		obj.show();
		obj.rk();
		obj.vk();
	}

}
