package com.demo2;

public class A1 {
	
	void show()
	{
		System.out.println("Inside show of A1");
	}
	
	void rk()
	{
		System.out.println("Jadeja");
	}
}
