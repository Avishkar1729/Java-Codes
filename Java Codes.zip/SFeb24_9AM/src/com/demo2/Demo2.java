package com.demo2;

public class Demo2 {

	public static void main(String[] args) {
		
		int arr[] = {11,45,7,100,20};
		
		int max = 0,smax = 0, tmax = 0;
		
		if((arr[0] >= arr[1]) && arr[0] >= arr[2])
		{
			max = arr[0];
			if(arr[1] >= arr[2])
			{
				smax = arr[1];
				tmax = arr[2];
			}
			else
			{
				smax = arr[2];
				tmax = arr[1];
			}
		}
		else if((arr[1] >= arr[0]) && arr[1] >= arr[2])
		{
			max = arr[1];
			if(arr[0] >= arr[2])
			{
				smax = arr[0];
				tmax = arr[2];
			}
			else
			{
				smax = arr[2];
				tmax = arr[0];
			}
			
		}
		else
		{
			max = arr[2];
			if(arr[0] >= arr[1])
			{
				smax = arr[0];
				tmax = arr[1];
			}
			else
			{
				smax = arr[1];
				tmax = arr[0];
			}
		}
		
		System.out.println("max : "+max);
		System.out.println("smax : "+smax);
		System.out.println("tmax : "+tmax);
		
		
		for(int i = 3; i < arr.length; i++)
		{
			if(arr[i] >= max)
			{
				tmax = smax;
				smax = max;
				max = arr[i];
			}
			else
			{
				if(arr[i] >= smax)
				{
					tmax = smax;
					smax = arr[i];
				}
				else
				{
					if(arr[i] >= tmax)
					{
						tmax = arr[i];
					}
				}
				
			}
		}
		
		System.out.println("max : "+max);
		System.out.println("smax : "+smax);
		System.out.println("tmax : "+tmax);

	}

}
