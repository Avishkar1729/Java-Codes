package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class FirstFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtfName;
	private JTextField txtlName;
	private JTextField txtAge;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstFrame frame = new FirstFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FirstFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setSize(600, 400);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl1 = new JLabel("Welcome to my project");
		lbl1.setForeground(new Color(255, 0, 128));
		lbl1.setBackground(new Color(255, 255, 128));
		lbl1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setBounds(67, 11, 269, 34);
		contentPane.add(lbl1);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBackground(new Color(255, 255, 0));
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int a = Integer.parseInt(txtAge.getText());
						
				if(a >= 18)
				{
					JOptionPane.showMessageDialog(btnSubmit, "You can vote!!!");
					
					String fnm = txtfName.getText();
					String lnm = txtlName.getText();
					String age = txtAge.getText();
					
					SecondFrame obj = new SecondFrame();
					obj.setVisible(true);
					
					obj.lbl2.setText(fnm);
					obj.lbl3.setText(lnm);
					obj.lbl4.setText(age);
					
					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(btnSubmit, "Underage!!!");
				}
				
				
				/*
				String fnm = txtfName.getText();
				String lnm = txtlName.getText();
				String age = txtAge.getText();
				
				SecondFrame obj = new SecondFrame();
				obj.setVisible(true);
				
				obj.lbl2.setText(fnm);
				obj.lbl3.setText(lnm);
				obj.lbl4.setText(age);
				
				dispose();
				*/
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSubmit.setBounds(67, 227, 89, 23);
		contentPane.add(btnSubmit);
		
		JLabel lblfName = new JLabel("First Name :");
		lblfName.setHorizontalAlignment(SwingConstants.CENTER);
		lblfName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblfName.setBounds(46, 72, 129, 28);
		contentPane.add(lblfName);
		
		txtfName = new JTextField();
		txtfName.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtfName.setBounds(197, 72, 194, 29);
		contentPane.add(txtfName);
		txtfName.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Last Name :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(46, 129, 129, 23);
		contentPane.add(lblNewLabel);
		
		txtlName = new JTextField();
		txtlName.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtlName.setBounds(197, 127, 194, 28);
		contentPane.add(txtlName);
		txtlName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Age : ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(67, 178, 108, 23);
		contentPane.add(lblNewLabel_1);
		
		txtAge = new JTextField();
		txtAge.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtAge.setBounds(197, 178, 194, 26);
		contentPane.add(txtAge);
		txtAge.setColumns(10);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtfName.setText("");
				txtlName.setText("");
				txtAge.setText("");
				
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnReset.setBackground(Color.YELLOW);
		btnReset.setBounds(247, 229, 89, 23);
		contentPane.add(btnReset);
	}
}
