package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUser;
	private JTextField txtEmail;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl1 = new JLabel("User Name : ");
		lbl1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setBounds(39, 68, 134, 32);
		contentPane.add(lbl1);
		
		JLabel lbl2 = new JLabel("Email :");
		lbl2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2.setBounds(39, 111, 134, 32);
		contentPane.add(lbl2);
		
		JLabel lblPassword = new JLabel("Password : ");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setBounds(39, 154, 134, 32);
		contentPane.add(lblPassword);
		
		JLabel lbl0 = new JLabel("Login Form");
		lbl0.setFont(new Font("Tahoma", Font.BOLD, 18));
		lbl0.setHorizontalAlignment(SwingConstants.CENTER);
		lbl0.setBounds(97, 11, 198, 32);
		contentPane.add(lbl0);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnLogin.setBounds(49, 218, 117, 32);
		contentPane.add(btnLogin);
		
		JButton btnReg = new JButton("Register");
		btnReg.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnReg.setBounds(249, 218, 108, 32);
		contentPane.add(btnReg);
		
		txtUser = new JTextField();
		txtUser.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtUser.setBounds(207, 68, 177, 32);
		contentPane.add(txtUser);
		txtUser.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtEmail.setColumns(10);
		txtEmail.setBounds(207, 111, 177, 32);
		contentPane.add(txtEmail);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(207, 156, 178, 32);
		contentPane.add(passwordField);
	}
}
