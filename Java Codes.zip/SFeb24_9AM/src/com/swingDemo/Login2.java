package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Login2 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField txtPass;
	private JTextField txtEmail;
	private JTextField txtUser;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login2 frame = new Login2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setBounds(100, 100, 1200, 880);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl0 = new JLabel("Login Form");
		lbl0.setForeground(new Color(0, 0, 0));
		lbl0.setBackground(new Color(255, 0, 128));
		lbl0.setHorizontalAlignment(SwingConstants.CENTER);
		lbl0.setFont(new Font("Tahoma", Font.BOLD, 32));
		lbl0.setBounds(500, 24, 250, 65);
		contentPane.add(lbl0);
		
		JLabel lblUser = new JLabel("User Name : ");
		lblUser.setForeground(new Color(0, 0, 0));
		lblUser.setHorizontalAlignment(SwingConstants.CENTER);
		lblUser.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblUser.setBounds(300, 182, 250, 40);
		contentPane.add(lblUser);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setForeground(new Color(0, 0, 0));
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblEmail.setBounds(300, 277, 250, 40);
		contentPane.add(lblEmail);
		
		JLabel lblPass = new JLabel("Password : ");
		lblPass.setForeground(new Color(0, 0, 0));
		lblPass.setHorizontalAlignment(SwingConstants.CENTER);
		lblPass.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblPass.setBounds(300, 366, 250, 40);
		contentPane.add(lblPass);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String user = txtUser.getText();
				String email = txtEmail.getText();
				String pass = txtPass.getText();
				

				System.out.println("text user : "+user);
				System.out.println("text email : "+email);
				System.out.println("text pass : "+pass);
				
				
				
				DbFunction dbobj = new DbFunction();
				ResultSet rs = dbobj.readData(email);
				
				int flag = 0;
				String tempUser = null, tempPass = null;
				try
				{
					
					while(rs.next())
					{
						flag = 1;
						tempUser = rs.getString(1);
						tempPass = rs.getString(5);
					}
				}
				catch(Exception ex)
				{
					System.out.println(ex);
				}
				
				System.out.println("temp user : "+tempUser);
				System.out.println("temp pass : "+tempPass);
				
				
				if(flag == 1)
				{
					if(user.equals(tempUser) && pass.equals(tempPass))
					{
						System.out.println("login success");
						JOptionPane.showMessageDialog(btnLogin, "Login Succesfull");
					}
					else
					{

						System.out.println("login Unsuccessfull");
						JOptionPane.showMessageDialog(btnLogin, "Login UnSuccesfull");
					}
				}
				else
				{
					System.out.println("Please enter valid email");
					JOptionPane.showMessageDialog(btnLogin, "Please enter valid email");
				}
				
			}
		});
		btnLogin.setForeground(new Color(0, 0, 0));
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnLogin.setBounds(300, 526, 250, 40);
		contentPane.add(btnLogin);
		
		JButton btnReg = new JButton("Register");
		btnReg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DbFrame obj = new DbFrame();
				obj.setVisible(true);
				dispose();
				
			}
		});
		btnReg.setForeground(new Color(0, 0, 0));
		btnReg.setFont(new Font("Tahoma", Font.BOLD, 24));
		btnReg.setBounds(700, 526, 250, 40);
		contentPane.add(btnReg);
		
		txtPass = new JPasswordField();
		txtPass.setFont(new Font("Tahoma", Font.BOLD, 26));
		txtPass.setBounds(700, 366, 250, 40);
		contentPane.add(txtPass);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.BOLD, 26));
		txtEmail.setColumns(10);
		txtEmail.setBounds(700, 277, 250, 40);
		contentPane.add(txtEmail);
		
		txtUser = new JTextField();
		txtUser.setFont(new Font("Tahoma", Font.BOLD, 26));
		txtUser.setColumns(10);
		txtUser.setBounds(700, 182, 250, 40);
		contentPane.add(txtUser);
		
		
		JLabel lblImg = new JLabel("");
		
		//lblImg.setIcon(new ImageIcon("C:\\Users\\Dell\\Downloads\\bk.jpg"));
		lblImg.setIcon(new ImageIcon("C:\\Users\\Dell\\Downloads\\oggy3.jpg"));
		lblImg.setBounds(230, 120, 1600, 500);
		
		//lblImg.setIcon(new ImageIcon("C:\\Users\\Dell\\Downloads\\vk.jpg"));
		//lblImg.setBounds(100, 100, 1200, 800);
		
		contentPane.add(lblImg);
	}

}
