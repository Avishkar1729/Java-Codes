package com.swingDemo;

import java.util.Scanner;

public class Test {
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		DbFunction obj = new DbFunction();
		//obj.getConnection();
		//obj.createDB();
		
		//obj.getConnection();
		//obj.createTable();
		
	}

}
