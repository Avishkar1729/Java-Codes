package com.exphandling;

public class Demo3 {
	
	static void cSk() throws NullPointerException, ArithmeticException, NullPointerException
	{
		System.out.println("Hello yello armry");
		
		try
		{
			System.out.println("inside 1st try block");
			
			try
			{
				System.out.println("inside 2st try block");
				
				try
				{
					System.out.println("inside 3st try block");
					String str = null;
					System.out.println(str.length());
					System.out.println( "hello try3");
				}
				catch (Exception ex) 
				{
					System.out.println("catch3");
					ex.printStackTrace();
				}
				finally
				{
					System.out.println("hiiiiiiiiiii finally 1");
				}
				
				
				int a = 10 / 0;
				System.out.println("hello try2");
				
			}
			catch(Exception ex)
			{
				System.out.println("catch2");
				ex.printStackTrace();
			}
			System.out.println("virat koli");
			
			int a = Integer.parseInt("Nisha");
			System.out.println("hello try1");
		}
		catch(Exception ex)
		{
			System.out.println("catch1");
			ex.printStackTrace();
		}
		
		System.out.println("hello jiji");
	}

	public static void main(String[] args) {
		
		cSk();
	}

}
