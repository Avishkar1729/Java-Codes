package com.exphandling;

import java.util.Scanner;

public class Demo1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Hello and welcome");
		
		int x = 10;
		System.out.println("a : "+x);
		
		System.out.println("Enter first number : ");
		int a = sc.nextInt();
		
		System.out.println("enter second number : ");
		int b = sc.nextInt();
		/*
		try
		{
			int div = a / b;
			System.out.println("div : "+div);
		}
		catch(ArithmeticException ae) 
		{
			System.out.println(ae);
		}
		
		
		System.out.println("Hello hii");
		
		try
		{
			String str = null;
			System.out.println(str.length());
					
		}
		catch (NullPointerException ne) {
			
			ne.printStackTrace();
		}
		*/
		/*
		try
		{
			String str = "Aman";
			int t = Integer.parseInt(str);
			System.out.println(t);
		}
		catch(NumberFormatException ex)
		{
			ex.printStackTrace();
		}
		*/
		
		
		
		System.out.println("chalo bye");
	
	}

}
