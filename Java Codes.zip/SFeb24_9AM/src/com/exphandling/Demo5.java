package com.exphandling;

public class Demo5 {
	
	void thala()
	{
		System.out.println("Thala for reason");
		try
		{
			throw new UserCskExp("5 IPL tropies");
		}
		catch(UserCskExp ex)
		{
			ex.printStackTrace();
			//System.out.println(ex);
			//System.out.println(ex.getMessage());
		}
	}

	public static void main(String[] args) {
		
		Demo5 obj = new Demo5();
		obj.thala();
		
	}

}