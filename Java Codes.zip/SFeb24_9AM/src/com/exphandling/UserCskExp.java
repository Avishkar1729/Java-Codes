package com.exphandling;

public class UserCskExp extends Exception{
	
	UserCskExp(String str)
	{
		super(str);
	}

}
