package com.exphandling;

public class Voter extends Exception{
	
	Voter(String str)
	{
		super(str);
	}
}
