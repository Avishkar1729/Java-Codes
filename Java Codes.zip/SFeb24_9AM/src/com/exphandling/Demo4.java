package com.exphandling;

import java.util.Scanner;

public class Demo4 {
	
	static Scanner sc;
	
	static void mI()
	{
		sc = new Scanner(System.in);
		
		
		System.out.println("Enter your age : ");
		int age = sc.nextInt();
		
		if(age <= 18)
		{
			System.out.println("hiii byeee");
			//throw new ArithmeticException("Access denied!!!!!!\nYou must be atleast 18 years old");
			/*
			try
			{
				throw new Voter("Access denied!!!!!!\nYou must be atleast 18 years old");
			}
			catch(Voter ex)
			{
				//System.out.println(ex);
				ex.printStackTrace();
			}*/
			
		}
		else
		{
			System.out.println("You are eligible to vote for modi sarkar");
		}
		
		
		
		try
		{
			throw new ArithmeticException("Access denied!!!!!!\nYou must be atleast 18 years old");
			
		}
		catch(Exception ex)
		{
			
		}
		
		finally {
			
		}
		
	}

	public static void main(String[] args) {
		
		mI();

	}

}
