package com.jdbcDemo;

import java.awt.Taskbar.State;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCOperation {
	 
	Connection con = null;
	
	public void getConnection()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ipl", "root","");
			
			System.out.println("connection established!!!!!!\n");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	void createDB()
	{
		
		try
		{
			Statement st = con.createStatement();
			
			String sql = "create database modiji";
			
			st.executeUpdate(sql);
			System.out.println("Database created succusfull!!!\n");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void createTable()
	{
		try
		{
			Statement st = con.createStatement();
			
			//String sql = "create table mp(mpId int(10) primary key, mpName varchar(20), mpSal varchar(10), mpRegion varchar(20))";
			String sql = "create table player(pId int(10) primary key, pName varchar(20), img longblob)";
			st.executeUpdate(sql);
			System.out.println("Table created succesfully!!!!\n");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	void readAllData()
	{	
		try
		{
			Statement st = con.createStatement();
			
			String query = "select * from team";
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next())
			{
				System.out.println("Team Id : "+rs.getInt(1)+"\tTeam Name : "+rs.getString(2)+"\tTeam Rank : "+rs.getInt(3)+"\tTeam Wins : "+rs.getInt(4));
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void readData(String name)
	{		
		try
		{
			Statement st = con.createStatement();
			
			String sql = "select * from team where tName = '"+name+"'";
			
			ResultSet rs = st.executeQuery(sql);
			
			int flag = 0;
			
			while(rs.next())
			{
				flag = 1;
				System.out.println("Team Id : "+rs.getInt(1)+"\tTeam Name : "+rs.getString(2)+"\tTeam Rank : "+rs.getInt(3)+"\tTeam Wins : "+rs.getInt(4));
			}
			
			if(flag == 0)
			{
				System.out.println("record not found");
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void insertData()
	{	
		try
		{
			Statement st = con.createStatement();
			
			String sql = "insert into mp values(1,'Amit Shah',150000,'Gandhinagar')";
			st.executeUpdate(sql);
			System.out.println("data inserted succesfull");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void insertDataUser(int id, String name, int rank, int win)
	{
		try
		{
			//String sql = "insert into team values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement("insert into team values(?,?,?,?)");
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, rank);
			ps.setInt(4, win);
			
			
			ps.executeUpdate();
			System.out.println("Data Inserted Succesfully");
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	void delete()
	{
		try
		{
			Statement st = con.createStatement();
			
			String sql = "delete from team where tId = 9";
			
			st.executeUpdate(sql);
			System.out.println("Record deleted succesfull!!!!\n");
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void deleteUser(String name)
	{
		try
		{
			/*
			Statement st = con.createStatement();
			
			String sql = "delete from team where tId = "+id;
			
			st.executeUpdate(sql);
			System.out.println("Record deleted succesfull!!!!\n");
			*/
			
			String sql = "delete from team where tName = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, name);
			
			ps.executeUpdate();
			
			System.out.println("Record deleted succesfully!!!\n");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	void updataData()
	{
		try
		{
			Statement st = con.createStatement();
			String sql = "update team set tName = 'MI' where tId = 1";
			
			st.executeUpdate(sql);
			
			System.out.println("Record updated succusfully!!!");			
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	void updataDataUser(int i, String nm)
	{
		try
		{
			String sql = "update team set tName = ?, tRank = ? where tId = ?";
			
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, nm);
			ps.setInt(2, i);
			
			ps.executeUpdate();
			
			System.out.println("Record updated succesfully!!!!");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	void updateTable()
	{
		
		String sql = "alter table team add tl int(10)";
		
		try
		{
			Statement st = con.createStatement();
			
			st.executeUpdate(sql);
			System.out.println("Table structure updated succefully!!!");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	
	void insertImg()
	{
		String Sql = "insert into player values(?,?,?)";
		
		try
		{
			PreparedStatement ps = con.prepareStatement(Sql);
			ps.setInt(1, 18);
			ps.setString(2, "Virat");
			
			FileInputStream i = new FileInputStream("C:\\Users\\Dell\\Downloads\\vk.jpg");
			ps.setBlob(3, i);
			
			ps.executeUpdate();
			
			System.out.println("Data inserted succesfull!!");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
