package com.jdbcDemo;

import java.sql.*;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		JDBCOperation obj = new JDBCOperation();
		
		obj.getConnection();
		
		//obj.readAllData();
		
		/*
		
		System.out.println("Enter the team name : ");
		String name = sc.next();
		
		obj.readData(name);
		 */
		
		/*
		obj.readAllData();
		System.out.println("********************");
		obj.insertData();
		System.out.println("***********************");
		obj.readAllData();
		*/
		/*
		System.out.println("Enter team id : ");
		int i = sc.nextInt();
		
		System.out.println("Enter team name : ");
		String nm = sc.next();
		
		System.out.println("Enter team rank : ");
		int r = sc.nextInt();
		
		System.out.println("Enter team wins : ");
		int w = sc.nextInt();
		
		
		obj.insertDataUser(i,nm,r,w);
		*/
		
		//obj.createDB();
		
		//obj.createTable();
		
		//obj.insertData();
		
		//obj.delete();
		
		/*
		System.out.println("Enter the team id which you want to delete : ");
		int id = sc.nextInt();
		
		obj.deleteUser(id);
		*/
		
		/*
		System.out.println("Enter team name which you want to delete : ");
		String name = sc.nextLine();
		
		obj.deleteUser(name);
		*/
		
		//obj.updataData();
		
		/*
		System.out.println("Enter team id : ");
		int id = sc.nextInt();
		
		
		System.out.println("Enter new team name : ");
		sc.nextLine();
		String name = sc.nextLine();
		
		obj.updataDataUser(id, name);
		*/
		
		//obj.updateTable();
		
		//obj.createTable();
		
		obj.insertImg();
	}

}
