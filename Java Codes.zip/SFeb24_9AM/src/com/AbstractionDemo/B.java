package com.AbstractionDemo;

public class B extends A{

	int b = 20;
	
	B()
	{
		super();
		System.out.println("Inside default B");
	}
	
	void xyz()
	{
		System.out.println("Inside xyz");
	}
	
	void display() 
	{
		System.out.println("Inside display");
	}
	
	
	
		
}
