package com.AbstractionDemo;

abstract public class Bank2 extends Bank1{
	
	Bank2(String a, String b, float c, String d)
	{
		super(a,b,c,d);
	}
	
	void show()
	{
		System.out.println("Inside show");
	}

}
