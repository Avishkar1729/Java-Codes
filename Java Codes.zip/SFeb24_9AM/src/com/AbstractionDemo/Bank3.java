package com.AbstractionDemo;

public class Bank3 extends Bank2{
	
	Bank3(String a, String b, float c, String d)
	{
		super(a,b,c,d);
	}
	
	void pranav()
	{
		System.out.println("Kay vishay, kahi nahi asach");
	}
}
