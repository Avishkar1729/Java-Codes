package com.AbstractionDemo;

public class Test {

	public static void main(String[] args) {
	
		Bank3 obj = new Bank3("123456789","Sushant",18000,"4518");
		
		obj.display();
		obj.show();
		obj.pranav();
		obj.thala();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*	
	B obj = new B();
	System.out.println("a : "+obj.a);
	System.out.println("b : "+obj.b);
	
	obj.show();
	obj.xyz();
	obj.display();
*/
	}

}
