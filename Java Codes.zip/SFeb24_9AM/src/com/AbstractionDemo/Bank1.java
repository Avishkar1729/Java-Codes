package com.AbstractionDemo;

abstract class Bank1 extends Bank{
	
	
	Bank1(String a, String b, float c, String d)
	{
		super(a,b,c,d);
	}
	
	void display() {
		
		System.out.println("Account number : "+accNo+"\nAccount name : "+accName+"\nAccount Balance : "+accBal+"\nAccount pin : "+accPin);
	}

}
