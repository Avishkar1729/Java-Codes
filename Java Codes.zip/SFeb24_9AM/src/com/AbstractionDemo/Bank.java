package com.AbstractionDemo;

abstract public class Bank {
	
	String accNo;
	String accName;
	float accBal;
	String accPin;
	
	
	Bank(String a, String b, float c, String d)
	{
		accNo = a;
		accName = b;
		accBal = c;
		accPin = d;
	}
	
	void thala()
	{
		System.out.println("Thala for reason");
	}
	
	abstract void display();
	abstract void show();
	abstract void pranav();
	

}
