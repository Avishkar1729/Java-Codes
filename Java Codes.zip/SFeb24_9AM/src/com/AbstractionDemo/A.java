package com.AbstractionDemo;

abstract public class A {
	
	int a = 10;
	
	A()
	{
		System.out.println("Inside Default constructor A");
	}
	
	void show()
	{
		System.out.println("Inside Show");
		
	}
	
	abstract void display();
	
	

}
