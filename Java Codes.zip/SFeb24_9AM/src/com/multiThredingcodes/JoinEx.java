package com.multiThredingcodes;

public class JoinEx extends Thread{

	public void run()
	{
		for(int i = 1; i <= 5; i++)
		{
			System.out.println("i : "+i+"\tname : "+currentThread().getName());
			
			if(i == 3 && currentThread().getName() == "ram")
			{
				try 
				{
					currentThread().join();
				} 
				catch (InterruptedException e) 
				{	
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void main(String[] args) {
		
		JoinEx t1 = new JoinEx();
		JoinEx t2 = new JoinEx();
		
		t1.setPriority(10);
		t1.setName("ram");
		t2.setName("sham");
		t1.start();
		t2.start();
		

	}

}
