package com.multiThredingcodes;

public class Table1Sync {
	
	
	synchronized void printTable(int t)
	{
		for(int i = 1; i <= 10; i++)
		{
			System.out.println(i*t+" : "+Thread.currentThread().getName());
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}

}
