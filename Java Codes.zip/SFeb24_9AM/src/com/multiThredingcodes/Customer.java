package com.multiThredingcodes;

public class Customer {
	
	int balance = 1000;
	
	synchronized void withdraw(int amt)
	{
		System.out.println("Going to withdraw!!!!");
		System.out.println("Account balance : "+balance);
		System.out.println("withdraw amount : "+amt);
		if(balance < amt)
		{
			System.out.println("insufficient balance!!! waiting to deposite because balance : "+balance+" is less than withdrawl amount that is : "+amt);
			
			try
			{
				wait();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		balance = balance - amt;
		System.out.println("withdraw succesfull");
		System.out.println("updated balance after withdrawl : "+balance);
		
	}
	
	synchronized void deposite(int amt)
	{
		System.out.println("Going to deposite!!!");
		System.out.println("Account balance : "+balance);
		System.out.println("deposite amount : "+amt);
		
		balance = balance + amt;
		System.out.println("Deposite Succesfulll!!!!");
		System.out.println("updated balance after deposite : "+balance);
		notify();
	}

}
