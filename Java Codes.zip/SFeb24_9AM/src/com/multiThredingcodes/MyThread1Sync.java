package com.multiThredingcodes;

public class MyThread1Sync extends Thread{
	
	Table1Sync tObj;
	
	MyThread1Sync(Table1Sync obj)
	{
		tObj = obj;
	}
	
	public void run()
	{
		tObj.printTable(7);
	}
}
