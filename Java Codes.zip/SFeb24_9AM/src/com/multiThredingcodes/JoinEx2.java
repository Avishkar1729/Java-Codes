package com.multiThredingcodes;

public class JoinEx2 extends Thread{

	public void run()
	{
		for(int i = 1; i <= 5; i++)
		{
			System.out.println("i : "+i+"\tName : "+currentThread().getName());
			try
			{
				sleep(3000);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		
		JoinEx2 t1 = new JoinEx2();
		JoinEx2 t2 = new JoinEx2();
		JoinEx2 t3 = new JoinEx2();
		
		t2.start();
		
		try
		{
			t2.join();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		t1.start();
		t3.start();

	}

}
