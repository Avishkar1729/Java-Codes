package com.multiThredingcodes;

public class Table3Sync {
	
	synchronized public static void printTable(int t)
	{
		for(int i = 1; i <= 5; i++)
		{
			System.out.println(i*t+" : "+Thread.currentThread().getName());
			try
			{
				Thread.sleep(2000);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

}
