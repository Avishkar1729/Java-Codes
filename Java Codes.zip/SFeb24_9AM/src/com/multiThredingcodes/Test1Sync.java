package com.multiThredingcodes;

public class Test1Sync {

	public static void main(String[] args) {
		
		Table1Sync obj1 = new Table1Sync();
		
		Table1Sync obj2 = new Table1Sync();
		
		MyThread1Sync m1 = new MyThread1Sync(obj1);
		MyThread2Sync m2 = new MyThread2Sync(obj2);
		
		MyThread1Sync m3 = new MyThread1Sync(obj2);
		MyThread2Sync m4 = new MyThread2Sync(obj2);
		
		
		m1.setName("m1");
		m2.setName("m2");
		m3.setName("m3");
		m4.setName("m4");
		
		m1.start();
		m2.start();
		m3.start();
		m4.start();

	}

}
