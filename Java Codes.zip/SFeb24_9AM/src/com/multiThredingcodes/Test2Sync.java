package com.multiThredingcodes;

public class Test2Sync {

	public static void main(String[] args) {
		
		Table2Sycn t = new Table2Sycn();
		
		MyThread11Sync m1 = new MyThread11Sync(t);
		MyThread12Sycn m2 = new MyThread12Sycn(t);
		
		m1.start();
		m2.start();

	}

}
