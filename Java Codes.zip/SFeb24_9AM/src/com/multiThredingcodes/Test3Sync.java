package com.multiThredingcodes;

public class Test3Sync {

	public static void main(String[] args) {
		
		Table3Sync obj1 = new Table3Sync();
		Table3Sync obj2 = new Table3Sync();
		Table3Sync obj3 = new Table3Sync();
		
		
		MyThread101Sync t1 = new MyThread101Sync(obj1);
		MyThread102Sync t2 = new MyThread102Sync(obj2);
		MyThread103Sync t3 = new MyThread103Sync(obj3);
		
		t1.setName("t1");
		t2.setName("t2");
		t3.setName("t3");
		
		t1.start();
		t2.start();
		t3.start();
		

	}

}
