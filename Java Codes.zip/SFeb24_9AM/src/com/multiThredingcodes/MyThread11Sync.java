package com.multiThredingcodes;

public class MyThread11Sync extends Thread {
	
	Table2Sycn tObj;
	
	MyThread11Sync(Table2Sycn obj)
	{
		tObj = obj;
	}
	
	public void run()
	{
		tObj.printTable(6);
	}

}
