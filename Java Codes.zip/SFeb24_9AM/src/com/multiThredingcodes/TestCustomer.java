package com.multiThredingcodes;

public class TestCustomer extends Thread {
	
	public static void main(String[] args) {
		
		Customer cobj = new Customer();
		
		FirstCustomer t1 = new FirstCustomer(cobj);
		t1.start();
		
		SecondCoustomer t2 = new SecondCoustomer(cobj);
		t2.start();
		
		
		
		/*
		Customer obj = new Customer();
		  
		new Thread()
		{
			public void run()
			{
				obj.withdraw(1500);
			}
		}.start();
		
		
		new Thread()
		{
			public void run()
			{
				obj.deposite(1000);
			}
		}.start();
*/
	}

}
