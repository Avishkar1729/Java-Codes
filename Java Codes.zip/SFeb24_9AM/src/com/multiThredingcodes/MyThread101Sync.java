package com.multiThredingcodes;

public class MyThread101Sync extends Thread{

	Table3Sync tobj;
	
	MyThread101Sync(Table3Sync obj)
	{
		tobj = obj;
	}
	
	
	public void run()
	{
		tobj.printTable(5);
	}
}
