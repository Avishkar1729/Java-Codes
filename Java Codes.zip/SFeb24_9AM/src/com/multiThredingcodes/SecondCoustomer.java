package com.multiThredingcodes;

public class SecondCoustomer extends Thread{

	Customer cobj;
	
	SecondCoustomer(Customer c)
	{
		cobj = c;
	}
	
	public void run()
	{
		cobj.deposite(1200);
	}
	
}
