package com.multiThredingcodes;

public class FirstCustomer extends Thread {
	
	Customer cobj;
	
	FirstCustomer(Customer cobj)
	{
		this.cobj = cobj;
	}
	
	public void run()
	{
		cobj.withdraw(1500);
	}

}
