package com.multiThredingcodes;

public class MyThread12Sycn extends Thread{

	Table2Sycn tObj;
	
	MyThread12Sycn(Table2Sycn obj)
	{
		tObj = obj;
	}
	
	public void run()
	{
		tObj.printTable(3);
	}
	
}
