package com.multiThredingcodes;

public class DemoPriority extends Thread{
	
	public void run()
	{
		System.out.println("Inside run method : "+currentThread().getName());
	}
	

	public static void main(String[] args) {
	
		DemoPriority t1 = new DemoPriority();
		DemoPriority t2 = new DemoPriority();
		DemoPriority t3 = new DemoPriority();
		DemoPriority t4= new DemoPriority();
		
		t2.setPriority(MAX_PRIORITY);
		t1.setPriority(MIN_PRIORITY);
		t3.setPriority(7);
		
		t1.setName("Nisha");
		t2.setName("Aditya");
		t3.setName("Javal");
		t4.setName("Avishkar");
		
		System.out.println("Priority of t1 : "+t1.getPriority());
		System.out.println("Priority of t2 : "+t2.getPriority());
		System.out.println("Priority of t3 : "+t3.getPriority());
		System.out.println("Priority of t4 : "+t4.getPriority());
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
