package com.multiThredingcodes;

public class Table2Sycn {
	
	void printTable(int t)
	{
		System.out.println("Hiii devendra "+Thread.currentThread().getName());
		System.out.println("hello aman "+Thread.currentThread().getName());
		
		synchronized (this) {
			
			for(int i = 1; i <= 5; i++)
			{
				System.out.println(i*t+" : "+Thread.currentThread().getName());
				try
				{
					Thread.sleep(2000);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		}
		
		
		System.out.println("Byeeeee devendra "+Thread.currentThread().getName());
		System.out.println("Bye aman "+Thread.currentThread().getName());
		
	}

}
