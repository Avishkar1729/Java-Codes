package com.multiThredingcodes;

public class MyThread103Sync extends Thread{
	
	Table3Sync tobj;
	
	MyThread103Sync(Table3Sync obj)
	{ 
		tobj = obj;
		
	}
	
	public void run()
	{
		tobj.printTable(9);
	}
}
