package com.multiThredingcodes;

public class Demo2 implements Runnable{

	public void run()
	{
		for(int i = 1; i <= 5; i++)
		{
			System.out.println("i : "+i+"\tName : "+Thread.currentThread().getName());
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
				System.out.println(e);
			}
		}
	}
	
	public static void main(String[] args) {
		
		Demo2 s1 = new Demo2();
		Demo2 s2 = new Demo2();
		Demo2 s3 = new Demo2();
		
		Thread t1 = new Thread(s1);
		Thread t2 = new Thread(s2);
		Thread t3 = new Thread(s3);
		
		
		t1.start();
		t2.start();
		t3.start();
		
		//obj.run();
		
	}

}
