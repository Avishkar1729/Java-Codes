package com.multiThredingcodes;

public class Demo1 extends Thread{
	
	public void run()
	{
		for(int i = 1; i <= 5; i++)
		{
			System.out.println("i : "+i+"\tName : "+currentThread().getName());
			try
			{
				sleep(3000);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		
		Demo1 obj0 = new Demo1();
		Demo1 obj1 = new Demo1();
		Demo1 obj2 = new Demo1();
		Demo1 obj3 = new Demo1();
		
		obj0.start();
		obj1.start();
		obj2.start();
		obj3.start();

	}

}
