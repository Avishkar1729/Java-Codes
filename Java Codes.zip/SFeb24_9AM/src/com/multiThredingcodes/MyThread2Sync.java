package com.multiThredingcodes;

public class MyThread2Sync extends Thread{
	
	Table1Sync tObj;
	
	MyThread2Sync(Table1Sync obj)
	{
		tObj = obj;
	}
	
	public void run()
	{
		tObj.printTable(4);
	}
}
