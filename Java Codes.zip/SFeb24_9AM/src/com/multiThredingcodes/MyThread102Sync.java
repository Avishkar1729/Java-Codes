package com.multiThredingcodes;

public class MyThread102Sync extends Thread{
	
	Table3Sync tobj;
	
	MyThread102Sync(Table3Sync obj)
	{
		tobj = obj;
	}
	
	
	public void run()
	{
		tobj.printTable(3);
	}
}
