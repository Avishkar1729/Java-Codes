package com.testcode;

import java.util.Scanner;

public class ArmstrongNumber {
	
	
	
	static void findArmstrongNo(int n)
	{
		int temp = n;
		//int aman = n;
		int cnt = 0;
		while(n != 0)
		{
			cnt++;
			n = n / 10;
		}
		
		n = temp;
		System.out.println("cnt : "+cnt);
		
		int sum = 0;
		while(n != 0)
		{
			int digit = n % 10;
			
			int x = 1;
			
			for(int i = 1; i <= cnt; i++)
			{
				x = x*digit;
			}
			
			sum = sum + x;
			n = n/10;
		}
		
		
		if(temp == sum)
		{
			System.out.println(temp+" is armstrong number");
		}
		else
		{

			System.out.println(temp+" is not armstring number");
		}
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number : ");
		int n = sc.nextInt();
		
		ArmstrongNumber.findArmstrongNo(n);

	}

}
