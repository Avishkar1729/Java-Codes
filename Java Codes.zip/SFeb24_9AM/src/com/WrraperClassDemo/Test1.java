package com.WrraperClassDemo;

public class Test1 {

	public static void main(String[] args) {
		
		int a = 10;
		System.out.println("a : "+a);
		
		Integer x = Integer.valueOf(a);
		System.out.println("x : "+x);
		
		Integer y = a;
		System.out.println("y : "+y);
		

	}

}
