package com.WrraperClassDemo;

public class Test2 {

	public static void main(String[] args) {
		
		Integer a = new Integer(10);
		System.out.println("a : "+a);
		
		int x = a.intValue();
		System.out.println("x : "+x);
		
		int y = a;
		System.out.println("y : "+y);
		
	}

}
