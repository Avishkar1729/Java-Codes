package com.DemoCodes;

public class AccessModfireDemo {
	
	private int a = 10;
	public int b = 20;
	protected int c = 30;
	int d = 40;
}
