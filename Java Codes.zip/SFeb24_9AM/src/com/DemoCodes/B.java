package com.DemoCodes;

public class B {
	
	B()
	{
		System.out.println("Inside Default constructor of B");
	}
	
	static
	{
		System.out.println("Inside static block");
	}
	
	
	void fun()
	{
		System.out.println("Inside fun method");
	}
	

}
