package com.DemoCodes;

import java.util.*;

public class InputDemo {
	
	int eId;
	String eName;
	String lName;
	float eSal;
	
	Scanner sc = new Scanner(System.in);
	
	void insertData()
	{	
		System.out.println("Enter employee name : ");
		eName = sc.nextLine();
		
		System.out.println("Enter the employee Id : ");
		eId = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter employee last name : ");
		lName = sc.nextLine();
		
	}
	
	void showData()
	{
		System.out.print("Employee Id : "+eId);
		System.out.print("\tEmployee Name : "+eName);
		System.out.print("\tEmployee last name : "+lName+"\n");
	}

	public static void main(String[] args) {
		
		System.out.println("Hello and welcome back");
		
		InputDemo obj = new InputDemo();
		obj.insertData();
		obj.showData();
		
		
	}

}
