/*
  package com.DemoCodes;
 

public class FinalDemo2 extends FinalDemo {
	
	void display()
	{
		System.out.println("Inside display child");
		
	}
	
	/*
	void addition(int a, int b)
	{
		super.addition(15,7);
		System.out.println("Inside addition of finaldemo2");
	}
	*/
/*

	public static void main(String[] args) {
		
		FinalDemo2 obj = new FinalDemo2();
		obj.addition(10, 20);
		obj.display();
		obj.show();
		
	}

}

*/
