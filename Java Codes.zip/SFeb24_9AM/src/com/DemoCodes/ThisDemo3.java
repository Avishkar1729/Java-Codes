package com.DemoCodes;

public class ThisDemo3 {
	ThisDemo3()
	{
		this(150,250);
		System.out.println("Inside default constructor");
	}
	
	ThisDemo3(int a, int b)
	{
		System.out.println("Inside parameterised constructor int int");
		System.out.println("a : "+a);
		System.out.println("b : "+b);
	}
	
	ThisDemo3(String str, float x, int y)
	{
		this();
		System.out.println("Inside parameterised constructor string float int");
		System.out.println("Str : "+str);
		System.out.println("x : "+x);
		System.out.println("y : "+y);
	}
	
	
	

	public static void main(String[] args) {
		
		//ThisDemo3 obj = new ThisDemo3();
		//ThisDemo3 obj2 = new ThisDemo3(10,56);
		ThisDemo3 obj3 = new ThisDemo3("Ramji",11.5f,75);

	}

}
