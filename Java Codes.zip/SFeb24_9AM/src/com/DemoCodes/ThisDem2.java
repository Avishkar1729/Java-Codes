package com.DemoCodes;

public class ThisDem2 {
	
	int eId;
	String eName;
	float eSal;
	
	ThisDem2()
	{
		System.out.println("Inside default constructor");
	}
	
	ThisDem2(int eId, String eName, float eSal)
	{
		System.out.println("Inside parameterised constructor");
		
		this.eId = eId;
		this.eName = eName;
		this.eSal = eSal;
	}
	
	void display()
	{
		System.out.print("eId : "+eId);
		System.out.print("\teName : "+eName);
		System.out.print("\teSal : "+eSal);
		System.out.println();
	}

	public static void main(String[] args) {
		
		ThisDem2 obj = new ThisDem2();
		obj.display();
		
		ThisDem2 obj2 = new ThisDem2(101,"Krish",75000);
		obj2.display();

	}

}
