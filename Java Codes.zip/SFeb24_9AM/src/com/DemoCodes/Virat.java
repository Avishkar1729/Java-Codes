package com.DemoCodes;

public class Virat {
	
	int a;
	int b;
	
	Virat()
	{
		System.out.println("Inside default constructor");
	}
	
	Virat(int x, int y)
	{
		System.out.println("Inside parameterised constructor");
		a = x;
		b = y;
	}
	
	void show()
	{
		System.out.println("a : "+a);
		System.out.println("b : "+b);
		System.out.println("Thala for reason");
	}

}
