package com.DemoCodes;

public class Student {

	int rNo;
	String name;
	float mks;
	String addr;
	
	Student()
	{
		System.out.println("Inside default constuctor");
	}
	
	Student(int p,String q,float r, String s)
	{
		rNo = p;
		name = q;
		mks = r;
		addr = s;
	}
	
	void display()
	{
		System.out.println("Roll number : "+rNo);
		System.out.println("Name : "+name);
		System.out.println("Marks : "+mks);
		System.out.println("Address : "+addr);
	}

}
