package com.DemoCodes;

public class Emp {
	
	Emp()
	{
		System.out.println("Inisde default constuctor");
	}
	
	void show()
	{
		System.out.println("Inside show");
	}
	
	void fun()
	{
		System.out.println("Inside fun");
	}
	
	static
	{
		System.out.println("Inside static block");
	}

	public static void main(String[] args) {
		
		System.out.println("Hello and welcome");
		
		Emp obj = new Emp();
		obj.show();
		obj.fun();
		

	}

}
