package com.DemoCodes;

public class Thala extends AccessModfireDemo{
	
	int x = b;
	//int y = a;
	int z = c;
	int p = d;

	public static void main(String[] args) {
		

	}

}
