package com.DemoCodes;

import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your full name : ");
		String fName = sc.nextLine();
		
		System.out.println("Enter your age : ");
		int age = sc.nextInt();
		
		System.out.println("Enter your marks : ");
		float mks = sc.nextFloat();
		/*
		System.out.println("Enter your name : ");
		String name = sc.next();
		*/
		
		
		System.out.println("Age : "+age);
		System.out.println("Your marks is : "+mks);
		//System.out.println("Name : "+name);
		System.out.println("Full name : "+fName);

	}

}
