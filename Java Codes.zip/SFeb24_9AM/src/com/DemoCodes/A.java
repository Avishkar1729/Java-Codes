package com.DemoCodes;

public class A {
	
	A()
	{
		System.out.println("Default constructor of A");
	}
	
	void gun()
	{
		System.out.println("Inside gun");
	}

	public static void main(String[] args) {
		
		System.out.println("Welcome");
		
		A obj = new A();
		obj.gun();
		
		B bobj = new B();
		bobj.fun();
	}

}
