package com.DemoCodes;

public final class FinalDemo {
	
	final int a = 10;
	
	final void addition(int a, int b)
	{
		System.out.println("Addition method of parent");
		int c = a+b;
		System.out.println("Addition : "+c);
		
	}
	
	void show()
	{
		
		System.out.println("RoHitMan sharma parent");
	}
}
