package com.DemoCodes;

import java.util.Scanner;

public class PrimeDemo {

	void primeFun(int num)
	{
		int cnt = 0;
		
		for(int i = 2; i <=  num/2; i++)
		{
			if(num % i == 0)
			{
				System.out.println("i : "+i);
				cnt++;
				break;
			}
		}
		
		System.out.println("Cnt : "+cnt);
		if(cnt == 0)
		{
			System.out.println(num+" is a prime number");
			
		}
		else
		{

			System.out.println(num+" is not a prime number");
		}
	}
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter any number : ");
		int n = sc.nextInt();
		
		PrimeDemo obj = new PrimeDemo();
		obj.primeFun(n);
	}

}
