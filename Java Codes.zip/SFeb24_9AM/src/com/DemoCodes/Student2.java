package com.DemoCodes;

public class Student2 {
	
	int rNo;
	String name;
	float mks;
	static String clgName = "FC";
	
	Student2(int r, String nm, float m)
	{
		rNo = r;
		name = nm;
		mks = m;
	}
	
	static void insert()
	{
		clgName = "SP";
	}
	
	void display()
	{
		System.out.println("Roll number : "+rNo+"\tName : "+name+"\tMarks : "+mks+"\tCollege Name :"+clgName);
	}

}
