package com.DemoCodes;

public class FirstDemo {

	public static void main(String nishant[]) {
		
		System.out.print("Hello and welcome....  ");
		
	}

}
