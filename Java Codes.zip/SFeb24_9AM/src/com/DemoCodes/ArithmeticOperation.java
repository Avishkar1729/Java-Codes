package com.DemoCodes;

public class ArithmeticOperation {
	
	void display()
	{
		System.out.println("Hii virat");
	}

	public static void main(String[] args) {
		/*
		System.out.println("Hello and welcome");
		int sum = 0;
		for(int i = 1; i <= 10; i++)
		{
			sum = sum + i;
		}
		System.out.println("Addition : "+sum);	
		
		ArithmeticOperation obj = new ArithmeticOperation();
		obj.display();	
		*/
		
		//Virat vobj = new Virat();
		Virat vobj2 = new Virat(100,777);
		//System.out.println("Value of a : "+vobj.a);
		//System.out.println("Value of b : "+vobj.b);
		//System.out.println("Name : "+vobj.name);
		vobj2.show();
	}

}
