package com.DemoCodes;

public class ThisDemo {
	
	int a;
	String str;
	
	ThisDemo(int x, String temp)
	{
		this.a = x;
		this.str = temp;
	}
	
	void display()
	{
		System.out.println("a : "+a+"\tstr : "+str);
	}

	public static void main(String[] args) {
		
		ThisDemo obj = new ThisDemo(11,"Krish");
		ThisDemo obj2 = new ThisDemo(21,"radha");
		ThisDemo obj3 = new ThisDemo(11,"jay");
		
		obj.display();
		obj2.display();
		obj3.display();
		
	}

}
