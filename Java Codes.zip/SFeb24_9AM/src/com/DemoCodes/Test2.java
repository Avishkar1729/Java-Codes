package com.DemoCodes;

public class Test2 {

	public static void main(String[] args) {
		
		
		//Student2.insert();
		
		Student2 temp = new Student2(11,"Ram",76);
		Student2 obj = new Student2(21,"Sita",89);
		Student2 obj2 = new Student2(15,"jay",62);
		
		temp.display();
		//Student2.insert();
		obj.insert();
		obj.display();
		
		obj2.display();
	}

}
