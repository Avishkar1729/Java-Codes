package com.DemoCodes;

public class Test {

	public static void main(String[] args) {
		
		
		Student sobj = new Student();
		sobj.display();
		
		System.out.println("**************************************");
		
		Student sobj2 = new Student(11,"Ramji",89,"Pune");
		sobj2.display();
	

	}

}
