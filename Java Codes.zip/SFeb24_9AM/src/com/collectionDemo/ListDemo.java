package com.collectionDemo;

import java.util.ArrayList;

public class ListDemo {

	public static void main(String[] args) {
		
		ArrayList<String> a1 = new ArrayList<String>();
		a1.add("Nishant");
		a1.add("Nisha");
		a1.add("Virat");
		a1.add("swarupa");
		a1.add("Dev");
		
		/*
		System.out.println("List 1 : "+a1);
		
		System.out.println("\nDisplaying arraylist elements by using foereach loop : ");
		for(String temp : a1)
		{
			System.out.println(temp);
		}
		*/
		
		ArrayList<String> a2 = new ArrayList<String>();
		a2.add("shital");
		a2.add("Don");
		a2.add("Bhagyashri");
		
		ArrayList<String> a3 = new ArrayList<String>();
		a3.add("Nisha");
		a3.add("Dev");
		a3.add("Don");
		
		//System.out.println("\n list 2 : "+a2);
		
		a1.addAll(a2);
		System.out.println("new List : "+a1);
		
		//System.out.println(a1.remove(2));
		//System.out.println(a1);
		
		//a1.removeAll(a2);
		//System.out.println(a1);
		
		//System.out.println("size : "+a1.size());
		
		//a1.clear();
		//System.out.println("List : "+a1);
		
		//System.out.println(a1.contains("Sandesh"));
		//System.out.println(a1.containsAll(a3));
		
		//a3.clear();
		//System.out.println(a3.isEmpty());
		
		/*
		Object arr[] = a2.toArray();
		
		for(int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}
		*/
		
		//String x[] = new String[];
		
		String brr[] = a2.toArray(new String[0]);
		for(int i = 0; i < brr.length; i++)
		{
			System.out.println(brr[i]);
		}
		
		//System.out.println(a2.hashCode());
		
		//System.out.println(a2.equals(a3));
		
	}

}
