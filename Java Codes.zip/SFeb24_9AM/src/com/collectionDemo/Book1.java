package com.collectionDemo;

public class Book1{
	
	int bId;
	String bName, bAuthor, bPublisher;
	int bQuantity;
	
	public Book1(int id, String name, String author, String publisher, int quantity)
	{
		bId = id;
		bName = name;
		bAuthor = author;
		bPublisher = publisher;
		bQuantity = quantity;
		
	}
}
