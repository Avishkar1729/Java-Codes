package com.collectionDemo;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		
		Book1 b1 = new Book1(101, "C language  ", "Shital", "Dharma", 45);
		Book1 b2 = new Book1(202, "CPP language", "Nisha", "SRK",100);
		Book1 b3 = new Book1(007, "Java language", "Vishal", "SK", 45);
		Book1 b4 = new Book1(401, "PHP language", "Aditya", "Aman", 20);
		
		LinkedList<Book1> list = new LinkedList<Book1>();
			
		list.add(b1);
		list.add(b2);
		list.add(b3);
		list.add(b4);
		
		System.out.println("Displaying BOOK Information : ");
		
		for(Book1 temp : list)
		{
			System.out.println("Book Id : "+temp.bId+"\tBook Name : "+temp.bName+"\tBook Author : "+temp.bAuthor+"\tBook Publisher : "+temp.bPublisher+"\tBook Quantity : "+temp.bQuantity);
		}
	}

}
