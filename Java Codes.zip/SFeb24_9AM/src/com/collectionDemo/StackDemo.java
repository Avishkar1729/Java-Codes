package com.collectionDemo;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		
		Stack<Integer> list = new Stack<Integer>();
		
		list.push(10);
		list.push(20);
		list.push(30);
		list.push(40);
		list.push(50);
		
		/*
		for(Integer temp : list)
		{
			System.out.println(temp);
		}
		*/
		
		System.out.println(list);
		System.out.println("poped : "+list.pop());
		System.out.println(list);
		System.out.println("Peek element : "+list.peek());
		System.out.println(list);
		System.out.println("Location : "+list.search(40));

	}

}
