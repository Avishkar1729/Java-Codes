package com.collectionDemo;

import java.util.Iterator;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		
		Vector<String> list = new Vector<String>();
		
		list.add("Gita");
		list.add("Sita");
		list.add("Ram");
		list.add("Sham");
		list.add("Shiv");
		
		
		System.out.println("Displaying vector elements : ");
		Iterator it = list.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}
