package com.collectionDemo;

import java.util.ArrayDeque;

public class ArrayDequeDemo2 {

	public static void main(String[] args) {
		
		ArrayDeque<Integer> list = new ArrayDeque<Integer>();
		list.add(11);
		list.add(21);
		list.add(51);
		list.add(101);
		list.add(111);
		
		System.out.println(list);
		
		for(Integer temp : list)
		{
			System.out.println(temp);
		}
		
		System.out.println("peek fisrt : "+list.peekFirst());
		System.out.println("peek last : "+list.peekLast());
		
		list.offerFirst(500);
		System.out.println("list : "+list);
		
		list.offerLast(700);
		System.out.println("list : "+list);
		
		
	}

}
