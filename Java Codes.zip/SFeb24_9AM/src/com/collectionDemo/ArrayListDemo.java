package com.collectionDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {

	public static void main(String[] args) {
	
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("Don");
		list.add("Chota don");
		list.add("Chota Bhim");
		list.add("Ben ten");
		list.add("oggy");
		
		System.out.println("Displaying arraylist elemnts : ");
		Iterator it = list.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
	}

}
