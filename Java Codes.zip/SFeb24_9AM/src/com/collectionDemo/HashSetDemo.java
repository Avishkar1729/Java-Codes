package com.collectionDemo;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		
		HashSet<String> s1 = new HashSet<String>();
		s1.add("shital");
		s1.add("vishal");
		s1.add("aman");
		s1.add("nishant");
		s1.add("adi");
		
		System.out.println(s1);
		
		Iterator it = s1.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}

	}

}
