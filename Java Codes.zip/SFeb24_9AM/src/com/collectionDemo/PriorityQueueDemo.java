package com.collectionDemo;

import java.util.Comparator;
import java.util.PriorityQueue;

public class PriorityQueueDemo {

	public static void main(String[] args) {
		
		PriorityQueue<String> p = new PriorityQueue<String>(Comparator.reverseOrder());
		
		p.add("A");
		p.add("B");
		p.add("G");
		p.add("D");
		
		System.out.println(p);
		System.out.println("Head : "+p.element());
		System.out.println("Head : "+p.peek());
		
		System.out.println(p);
		
		System.out.println("remove : "+p.remove());
		System.out.println(p);
		
		System.out.println("add : "+p.add("A"));
		System.out.println(p);
		
		System.out.println("poll : "+p.poll());
		System.out.println(p);
		
		
		
		
	}

}
