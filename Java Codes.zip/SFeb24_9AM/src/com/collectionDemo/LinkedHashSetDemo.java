package com.collectionDemo;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		
		LinkedHashSet<String> list = new LinkedHashSet<String>();
		
		list.add("om");
		list.add("jay");
		list.add("om");
		list.add("hari");
		list.add("ram");
		list.add("sai");
		list.add(null);
		
		Iterator it = list.iterator();
		
		while(it.hasNext())
		{
			System.out.print(it.next()+", ");
		}
		
		System.out.println();
		System.out.println(list.remove("jay"));
		System.out.println(list);
		
		System.out.println(list.remove("avi"));
		
		
		
		
	}

}
