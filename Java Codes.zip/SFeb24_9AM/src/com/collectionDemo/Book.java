package com.collectionDemo;

public class Book extends Library{
	
	int bId;
	String bName, bAuthor, bPublisher;
	int bQuantity;
	
	public Book(int id, String name, String author, String publisher, int quantity, int lid, String lName)
	{
		super(lid,lName);
		bId = id;
		bName = name;
		bAuthor = author;
		bPublisher = publisher;
		bQuantity = quantity;
		
	}

	public String toString() {
		
		return super.toString()+"\tbook id : "+bId+"\tbook name : "+bName+"\tbook author : "+bAuthor+"\tbook publisher : "+bPublisher+"\tbook quantity : "+bQuantity;
		
	}
	
	

}
