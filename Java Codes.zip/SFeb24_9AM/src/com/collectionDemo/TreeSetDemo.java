package com.collectionDemo;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		
		
		TreeSet<Integer> list = new TreeSet<Integer>();
		
		list.add(10);
		list.add(5);
		list.add(100);
		list.add(56);
		list.add(10);
		list.add(8);
		list.add(1);
		
		System.out.println(list);
		
		
		TreeSet<String> lt = new TreeSet<String>();
		
		lt.add("Sandesh");
		lt.add("AVishkar");
		lt.add("Nishant");
		lt.add("Swarupa");
		lt.add("Aditya");
		lt.add("avishkar");
		lt.add("Vishal");
		
		System.out.println(lt);
		
		
	}

}
