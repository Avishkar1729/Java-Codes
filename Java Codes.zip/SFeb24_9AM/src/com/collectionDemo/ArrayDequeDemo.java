package com.collectionDemo;

import java.util.ArrayDeque;

public class ArrayDequeDemo {

	public static void main(String[] args) {
		
		Book b1 = new Book(101, "java", "vishal", "spark", 25,1001,"Nalanda");
		Book b2 = new Book(102, "cpp", "jawal", "spark", 10, 1002,"FC");
		Book b3 = new Book(106, "C", "Swarupa", "Vk", 30,1002,"SP");
		Book b4 = new Book(109, "Jungle BOOK", "Sandesh", "ABC", 100,1004,"PQR");
		
		ArrayDeque<Book> list = new ArrayDeque<Book>();
		list.add(b1);
		list.add(b2);
		list.add(b3);
		list.add(b4);
		
		System.out.println("Displaying book : \n");
		
		for(Book temp : list)
		{
			System.out.println(temp);
		}
		
		
		/*
		for(Book temp : list)
		{
			System.out.println("book id : "+temp.bId+"\tbook name : "+temp.bName+"\tbook author : "+temp.bAuthor+"\tbook publisher : "+temp.bPublisher+"\tbook quantity : "+temp.bQuantity);
		}
	*/
	}

}
