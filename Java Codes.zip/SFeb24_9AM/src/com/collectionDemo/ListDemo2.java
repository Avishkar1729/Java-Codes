package com.collectionDemo;

import java.util.ArrayList;
import java.util.List;

public class ListDemo2 {

	public static void main(String[] args) {
		
		List<Integer> l1 = new ArrayList<Integer>();
		
		l1.add(10);
		l1.add(20);
		l1.add(50);
		l1.add(7);
		
		System.out.println(l1);
		
		/*
		System.out.println(l1.get(2));
		System.out.println(l1);
		*/
		
		/*
		l1.set(1, 200);
		System.out.println(l1);
		*/
		
		//System.out.println(l1.indexOf(7));
		
		l1.sort(null);
		System.out.println(l1);
		
	}

}
