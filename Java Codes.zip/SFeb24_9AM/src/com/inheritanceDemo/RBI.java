package com.inheritanceDemo;

import java.util.Scanner;

public class RBI {
	
	Scanner sc = new Scanner(System.in);
	
	long accNo;
	String name;
	float iRate;
	String aadhar;
	String ifsc;
	String addr;
	
	public RBI() {
		System.out.println("Inside default constructor of RBI");
	}
	
	void insert(int acode, int icode)
	{
		int flag;
		do
		{
			flag = 0;
			System.out.println("Enter account number : ");
			accNo = sc.nextLong();
			String str = accNo+"";
			if(str.length() == acode)
			{
				flag = 1;
			}
			else
			{
				System.out.println("Pls eneter "+acode+" digit account number!!!");
			}
		}while(flag != 1);
		
		System.out.println("\n************************************\n");
		System.out.println("Enter account holder name : ");
		name = sc.next();
		
		System.out.println("\n************************************\n");
		do
		{
			flag = 0;
			System.out.println("Enter aadhar number : ");
			aadhar = sc.next();
			
			if(aadhar.length() == 12)
			{
				flag = 1;
			}
			else
			{
				System.out.println("Pls eneter 12 digit aadhar number!!!");
			}
		}while(flag != 1);
		
		System.out.println("\n************************************\n");
		
		
		do
		{
			flag = 0;
			System.out.println("Enter IFSC code : ");
			ifsc = sc.next();
			
			if(ifsc.length() == icode)
			{
				flag = 1;
			}
			else
			{
				System.out.println("Pls eneter "+icode+" digit IFSC code!!!");
			}
		}while(flag != 1);
		
		System.out.println("\n************************************\n");
		
		System.out.println("Enter your address : ");
		addr = sc.next();
		
		System.out.println("\n********Thank you for adding your Information********\n");
	
	}
	
	void display(float iRate)
	{
		System.out.println("Account number : "+accNo);
		System.out.println("Account name : "+name);
		System.out.println("Interest rate : "+iRate);
		System.out.println("Aadhar Number : "+aadhar);
		System.out.println("IFSC code : "+ifsc);
		System.out.println("Address : "+addr);
		System.out.println("*********************Thank You!!! VISIT AGAIAN*******************");
	}

}
