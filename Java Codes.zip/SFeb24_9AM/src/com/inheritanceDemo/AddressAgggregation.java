package com.inheritanceDemo;

public class AddressAgggregation {
	
	String city;
	String state;
	String country;
	
	public AddressAgggregation(String city, String state, String country) 
	{
		this.city = city;
		this.state = state;
		this.country = country;
	}

}
