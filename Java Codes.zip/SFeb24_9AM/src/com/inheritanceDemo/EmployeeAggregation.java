package com.inheritanceDemo;

public class EmployeeAggregation {
	
	int id;
	String name;
	float sal;
	AddressAgggregation addr;
	
	EmployeeAggregation(int id, String name, float sal, AddressAgggregation addr)
	{
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.addr = addr;
	}
	
	void display()
	{
		System.out.println("Employee id : "+id);
		System.out.println("Employee name : "+name);
		System.out.println("Employee salary : "+sal);
		System.out.println("Employee city : "+addr.city);
		System.out.println("Employee state : "+addr.state);
		System.out.println("Employee country : "+addr.country);
	}

	public static void main(String[] args) {
		
		AddressAgggregation aobj = new AddressAgggregation("pune","MH","Bharat");
		AddressAgggregation aobj2 = new AddressAgggregation("mumbai","MH","Bharat");
		AddressAgggregation aobj3 = new AddressAgggregation("chennai","TN","Bharat");
		
		EmployeeAggregation obj = new EmployeeAggregation(101,"Ram",45000,aobj);
		obj.display();
		System.out.println("*************************");
		
		EmployeeAggregation obj2= new EmployeeAggregation(102,"sita",36000,aobj2);
		obj2.display();
		System.out.println("*************************");
		
		EmployeeAggregation obj3 = new EmployeeAggregation(103,"gita",96000,aobj3);
		obj3.display();
		System.out.println("*************************");
	}

}
