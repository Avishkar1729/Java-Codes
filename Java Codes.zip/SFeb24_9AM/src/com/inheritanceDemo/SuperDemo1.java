package com.inheritanceDemo;

public class SuperDemo1 {
	
	String color = "Pink";
	int a = 1000;
	
	SuperDemo1()
	{
		System.out.println("inside default constructor of parent");
	}
	
	SuperDemo1(int a)
	{
		this();
		System.out.println("inside para constructor of parent "+this.a);
	}
	
	void insert()
	{
		System.out.println("Inside parent insert");
	}
	
	void display()
	{
		System.out.println("Inside display parent*****");
	}

}
