package com.inheritanceDemo;

public class B extends A{
	/*
	B()
	{
		super();
	}
	*/
	
	void armstrongNumber()
	{
		int temp = add;
		int rem = 0, sum = 0;
		
		while(add != 0)
		{
			rem = add % 10;
			sum = sum + (rem*rem*rem);
			add = add / 10;
		}
		
		if(sum == temp)
		{
			System.out.println("is armstrong number");
		}
		else
		{
			System.out.println("is not armstrong number");
		}
		
		
	}
	
	void multiplication()
	{
		int mult = n * m;
		System.out.println("Mult : "+mult);
	}

	public static void main(String[] args) {
		
		B obj = new B();
		obj.addition();
		
		obj.armstrongNumber();
		obj.multiplication();  

	}

}
