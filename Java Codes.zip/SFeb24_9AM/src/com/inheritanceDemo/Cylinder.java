package com.inheritanceDemo;

public class Cylinder extends Shape{
	
	float h;
	float area;
	
	Cylinder()
	{
		System.out.println("Inside default constructor of cylinder !!!");
		System.out.println("Enter the height : ");
		h = sc.nextFloat();
		
	}
	
	void areaOfCylinder()
	{
		area = 2 * pi * r * h;
		System.out.println("Area of cylinder : "+area);
	}

}
