package com.inheritanceDemo;

public class Circle extends Cylinder{
	
	float area;
	Circle()
	{
		System.out.println("Inside default constructor of circle");
	}
	
	void areaOfCircle()
	{
		area = pi * r * r;
		
		System.out.println("Area od circle : "+area);
	}
	
	
	
}
