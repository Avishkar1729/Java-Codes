package com.inheritanceDemo;

public class ICICI extends RBI{
	
	ICICI()
	{
		super();
		System.out.println("Welcome to ICICI");
		int acode = 12;
		int icode = 6;
		insert(acode,icode);
	}
	
	void show()
	{
		iRate = 8f;
		System.out.println("************ICICI Account Details : *************");
		display(iRate);
	}
}
