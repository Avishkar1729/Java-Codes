package com.inheritanceDemo;

import java.util.Scanner;

public class A {
	
	Scanner sc = new Scanner(System.in);
	int n,m;
	int add;
	
	A()
	{
		System.out.println("Enter first number : ");
		n = sc.nextInt();
		
		System.out.println("Enter Second number : ");
		m = sc.nextInt();
	}
	
	void addition()
	{
		add = n + m;
		System.out.println("Addition : "+add);
	}

}
