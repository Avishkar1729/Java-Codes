package com.inheritanceDemo;

public class SBI extends RBI{
	
	SBI()
	{
		super();
		System.out.println("Welcome to SBI");
		int acode = 11;
		int icode = 8;
		insert(acode,icode);
	}
	
	void show()
	{
		iRate = 7f;
		System.out.println("************SBI Account Details : *************");
		display(iRate);
	}
	
}
