package com.inheritanceDemo;

public class TestBank {

	public static void main(String[] args) {
  
		SBI sobj = new SBI();
		ICICI iobj = new ICICI();
		HDFC hobj = new HDFC();
		
		sobj.show();
		iobj.show();
		hobj.show();
		

	}

}
