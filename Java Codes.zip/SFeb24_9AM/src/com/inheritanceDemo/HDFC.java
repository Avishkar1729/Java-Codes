package com.inheritanceDemo;

public class HDFC extends RBI{
	
	HDFC()
	{
		super();
		System.out.println("Welcome to HDFC");
		int acode = 14;
		int icode = 11;
		insert(acode,icode);
	}
	
	void show()
	{
		iRate = 8f;
		System.out.println("************HDFC Account Details : *************");
		display(iRate);
	}
}
