package com.inheritanceDemo;

public class Test {

	public static void main(String[] args) {
		
		Circle obj = new Circle();
		obj.areaOfCircle();
		obj.areaOfCylinder();
	}

}
