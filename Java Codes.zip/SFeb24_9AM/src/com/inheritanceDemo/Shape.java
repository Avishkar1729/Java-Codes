package com.inheritanceDemo;

import java.util.Scanner;

public class Shape {
	
	Scanner sc = new Scanner(System.in);
	
	final float pi = 3.14f;
	float r;
	
	Shape()
	{
		System.out.println("Default construcor of shape");
		System.out.println("Enter the radius : ");
		r = sc.nextFloat();
	}

}
