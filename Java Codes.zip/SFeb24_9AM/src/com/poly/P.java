package com.poly;

import java.util.Scanner;

public class P {
	
	Scanner sc = new Scanner(System.in);
	int a = 0, b = 0;
	P()
	{
		System.out.println("Inside parent constructor");
		System.out.println("Enter first number :");
		a = sc.nextInt();
		System.out.println("Enter second number :");
		b = sc.nextInt();
	}

	void addition()
	{
		System.out.println("Inside parent class addition");
		int add = a + b;
		System.out.println("Addition of two number : "+add);
	}
	
	void show()
	{
		System.out.println("inside show");
	}
}
