package com.poly;

public class Test {

	public static void main(String[] args) {
		
		
		Q obj = new Q();
		obj.fun();
		obj.show();
		obj.addition();
		
		
		
		/*
		AdditonPoly obj = new AdditonPoly();
		obj.addition();
		obj.addition(10, 20);
		obj.addition(12, 15);
	*/
	}

}
