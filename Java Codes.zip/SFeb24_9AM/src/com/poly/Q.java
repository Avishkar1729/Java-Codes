package com.poly;

import java.util.Scanner;

public class Q extends P{
	
	int a = 0, b = 0;
	
	Q()
	{
		super();
		System.out.println("Inside child constructor");
		System.out.println("Enter first number :");
		a = sc.nextInt();
		System.out.println("Enter second number :");
		b = sc.nextInt();
	}

	void addition()
	{
		System.out.println("Inside child class addition");
		int add = a + b;
		System.out.println("Addition of two number : "+add);
		
		
	}
	
	void fun()
	{
		System.out.println("Inside fun");
		super.addition();
	}

}
