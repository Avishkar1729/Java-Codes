package com.poly;

public class Virat {
	
	void display()
	{
		System.out.println("Inside display");
	}
	
	public static void gun()
	{
		System.out.println("Inside gun");
	}
	
	public void main() {
		
		System.out.println("Inside main");
	}
	
	static private void main(int a, int b) {
		
		System.out.println("Inside main with two int parameter");
	}
	
	public static void main(String args) {
		
		System.out.println("Inside main wiht string para");
	}

	public static void main(String[] ajay) {
	
		System.out.println("Inside main with string ajay");
		Virat obj = new Virat();
		obj.display();
		Virat.gun();
		obj.gun();
		
		Virat.main("rohit");
		obj.main(10, 20);
		Virat.main(100, 220);
		
	}
	
	public static void main(String args, int a) {
		
		System.out.println("Inside main args and a");
	}
	
	public static void main(String str, String str2) {
		
		System.out.println("Inside main str and str2");
	}

}
