package com.poly;

public class AdditonPoly {
	
	AdditonPoly()
	{
		System.out.println("Inside default constructor");
	}
	
	AdditonPoly(int a)
	{
		System.out.println("Inside para constructor");
	}
	
	AdditonPoly(float x)
	{
		System.out.println("Inside para constructor");
	}
	
	void addition(int a, int b)
	{
		int add = a + b;
		System.out.println("Addition of two number : "+add);
	}
	
	void addition(int a, int b, int c)
	{
		int add = a + b + c;
		System.out.println("Addition of three number : "+add);
	}
	
	void addition(double x, double y)
	{
		double add = x + y;
		System.out.println("addition of two double numbers : "+add);
	}
	
	void addition()
	{
		System.out.println("Inside addition !!!");
	}


}
