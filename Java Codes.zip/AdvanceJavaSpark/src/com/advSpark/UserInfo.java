package com.advSpark;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserInfo extends HttpServlet {

	
    String deptName=null;
    String hodName=null;
    public void init(ServletConfig config) throws ServletException {
    	deptName = config.getInitParameter("dept");
    	hodName = config.getInitParameter("hod");
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 ServletContext sc = request.getServletContext();
		 
		 String clgName = sc.getInitParameter("clg");
		 String prince = sc.getInitParameter("principle");
		 
		 System.out.println("Inside User Info");
		 
		 System.out.println("college name : "+ clgName);
		 System.out.println("Principle Name : " + prince);
		 
		 System.out.println("Inside User Info");
		 
		 System.out.println("Dept name : "+ deptName);
		 System.out.println("HOD Name : " + hodName);
		 
		 response.sendRedirect("cd");
		 
		 
		 
		 
		 
		 
//		 out.println("<br><br><b>ServletConfig Parameters</b>");
//		 out.println("<br><b> Name is : " + name + "</b>");
//		 out.println("<br><b> Age is : " + age + "</b>");
//		 
//		 sc.setAttribute("capital", "Delhi");
//		 
//		 String email=sc.getInitParameter("emaill");
//		 String country=sc.getInitParameter("country1");
//		 String cname=sc.getInitParameter("cname1");
//		 out.println("<br><br><b>ServletContext Parameters</b>");out.println("<br><b>Email is:-"+email+"</b>");
//		 out.print("<br><b>Country nam is: " + country+"</b>");
//		 out.print("<br><b>Company name is:-" + cname+"</b>");

	
	}



}
