package com.advSpark;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Spark1_Servlet extends HttpServlet {

	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter pw= resp.getWriter();
		
		String age = req.getParameter("age");
		String country = req.getParameter("country");
		
		pw.println("Age : " + age);
		pw.println("Country : " + country);
	}

	
}
