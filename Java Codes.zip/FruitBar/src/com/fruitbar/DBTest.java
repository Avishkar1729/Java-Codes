package com.fruitbar;

public class DBTest {

	public static void main(String[] args) {

		DBfruitbar obj = new DBfruitbar();
		
//		obj.createDB();
		
//		obj.createTable();
		
		
		
	}

}
