package com.Ass2;

import java.util.Scanner;

public class replace_space_to_char {

	public static void main(String[] args) {

		System.out.println("Enter the string");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		System.out.println(str);
		
		System.out.print("Enter the character to replace this space : ");
		char ch = sc.next().charAt(0);
		
		str = str.replace(' ', ch);
		
//		int n = str.length();
//		char chh;
//		
//		for(int i=0;i<n;i++) {
//			if(str.charAt(i) == ' ') {
//				System.out.print("Enter the character to replace this space : ");
//				chh = sc.next().charAt(0);
//		        str = str.replace(' ', chh);   
//			}	
//		}
		
		System.out.println(str);
	}

}
