package com.swingDemo;

import java.awt.EventQueue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.*;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Example3 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Example3 frame = new Example3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Example3() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 798, 597);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Display data");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				DBFunction dbf = new DBFunction();
				//dbf.fetchData();
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver"); // driver name/path

					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/swingdb", "root", "");
					
			        // Create statement
			        Statement st = con.createStatement();

			        String sql = "SELECT * FROM empinfo";
			        
			        ResultSet rs = st.executeQuery(sql);

			        
			        // Get metadata
			        ResultSetMetaData rsmd = rs.getMetaData();
			        
			
			        // Create columns in the table model
			        DefaultTableModel model = (DefaultTableModel) table.getModel();
			        
			        int columnCount = rsmd.getColumnCount();
			        String[] colName = new String [columnCount];

			        for (int i = 0; i < columnCount; i++) {
			        	colName[i] = rsmd.getColumnName(i+1);
			        	model.setColumnIdentifiers(colName);
			            //model.addColumn(metaData.getColumnName(i));
			        }
			
			        // Fetch rows and add them to the table model
			        String uname=null,email=null,mob=null,addr=null,pass=null;
			        while (rs.next()) {
			            uname = rs.getString(1);
			            email = rs.getString(2);
			            mob = rs.getString(3);
			            addr = rs.getString(4);
			            pass = rs.getString(5);
			            }
			        	String [] row = {uname,email,mob,addr,pass};
			        	//System.out.println("uname"+uname);
			            model.addRow(row);
			        }
					
					catch(Exception ae) {
						ae.printStackTrace();
					}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(70, 118, 138, 36);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(275, 99, 371, 402);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}
}
