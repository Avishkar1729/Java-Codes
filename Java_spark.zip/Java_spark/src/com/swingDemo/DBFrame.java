package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DBFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUname;
	private JTextField txtEmail;
	private JTextField txtMob;
	private JTextField txtAddr;
	private JPasswordField txtPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DBFrame frame = new DBFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DBFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 390);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl1 = new JLabel("User Name");
		lbl1.setBackground(Color.CYAN);
		lbl1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setBounds(35, 39, 89, 27);
		contentPane.add(lbl1);
		
		JLabel lbl2 = new JLabel("Email");
		lbl2.setBackground(Color.CYAN);
		lbl2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2.setBounds(35, 88, 89, 27);
		contentPane.add(lbl2);
		
		JLabel lbl3 = new JLabel("Mobile No.");
		lbl3.setBackground(Color.CYAN);
		lbl3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl3.setHorizontalAlignment(SwingConstants.CENTER);
		lbl3.setBounds(35, 138, 89, 27);
		contentPane.add(lbl3);
		
		JLabel lbl4 = new JLabel("Address");
		lbl4.setBackground(Color.CYAN);
		lbl4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl4.setHorizontalAlignment(SwingConstants.CENTER);
		lbl4.setBounds(35, 187, 89, 27);
		contentPane.add(lbl4);
		
		JLabel lbl5 = new JLabel("Password");
		lbl5.setBackground(Color.CYAN);
		lbl5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl5.setHorizontalAlignment(SwingConstants.CENTER);
		lbl5.setBounds(35, 234, 89, 27);
		contentPane.add(lbl5);
		
		txtUname = new JTextField();
		txtUname.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		txtUname.setBounds(193, 39, 201, 27);
		contentPane.add(txtUname);
		txtUname.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		txtEmail.setColumns(10);
		txtEmail.setBounds(193, 90, 201, 27);
		contentPane.add(txtEmail);
		
		txtMob = new JTextField();
		txtMob.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		txtMob.setColumns(10);
		txtMob.setBounds(193, 138, 201, 27);
		contentPane.add(txtMob);
		
		txtAddr = new JTextField();
		txtAddr.setFont(new Font("Microsoft Sans Serif", Font.PLAIN, 12));
		txtAddr.setColumns(10);
		txtAddr.setBounds(193, 187, 201, 27);
		contentPane.add(txtAddr);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String uname = txtUname.getText();
				String email = txtEmail.getText();
				String mob = txtMob.getText();
				String addr = txtAddr.getText();
				String pass = txtPass.getText();
				
//				System.out.println(uname);
//				System.out.println(email);
//				System.out.println(mob);
//				System.out.println(addr);
//				System.out.println(pass);
				
				DBFunction obj = new DBFunction();
				
				int res = obj.insertData(uname,email,mob,addr,pass );
				
				
				if(res==1) {
					JOptionPane.showMessageDialog(btnSubmit, "Registration Successful!!!");
				}
				else {
					JOptionPane.showMessageDialog(btnSubmit, "Registration Unuccessful!!!");
				}
				


				
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnSubmit.setBackground(Color.CYAN);
		btnSubmit.setBounds(85, 305, 112, 38);
		contentPane.add(btnSubmit);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LoginFrame lf = new LoginFrame();
				lf.setVisible(true);
				dispose();
				
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnLogin.setBackground(new Color(255, 160, 122));
		btnLogin.setBounds(270, 305, 112, 38);
		contentPane.add(btnLogin);
		
		txtPass = new JPasswordField();
		txtPass.setFont(new Font("MS Reference Sans Serif", Font.PLAIN, 12));
		txtPass.setBounds(193, 236, 201, 27);
		contentPane.add(txtPass);
	}
}
