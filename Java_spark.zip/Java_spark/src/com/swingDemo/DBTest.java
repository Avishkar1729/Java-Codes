package com.swingDemo;

public class DBTest {

	public static void main(String[] args) {

		
		DBFunction obj = new DBFunction();
		
//		obj.createDB();
		
//		obj.createTable();
		
		
		
	}

}
