package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class FirstFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtWelcomToFirst;
	JTextField lbl1;
	JTextField lbl2;
	JTextField lbl3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstFrame frame = new FirstFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FirstFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 553, 431);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtWelcomToFirst = new JTextField();
		txtWelcomToFirst.setEditable(false);
		txtWelcomToFirst.setHorizontalAlignment(SwingConstants.CENTER);
		txtWelcomToFirst.setForeground(Color.BLACK);
		txtWelcomToFirst.setText("Welcome to Display");
		txtWelcomToFirst.setBackground(SystemColor.activeCaption);
		txtWelcomToFirst.setBounds(189, 62, 140, 19);
		contentPane.add(txtWelcomToFirst);
		txtWelcomToFirst.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				SecondFrame obj1 = new SecondFrame();
				obj1.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setBackground(SystemColor.activeCaption);
		btnNewButton.setBounds(202, 315, 108, 42);
		contentPane.add(btnNewButton);
		
		lbl1 = new JTextField();
		lbl1.setBackground(Color.ORANGE);
		lbl1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lbl1.setBounds(189, 135, 140, 31);
		contentPane.add(lbl1);
		lbl1.setColumns(10);
		
		lbl2 = new JTextField();
		lbl2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lbl2.setColumns(10);
		lbl2.setBounds(189, 187, 140, 31);
		contentPane.add(lbl2);
		
		lbl3 = new JTextField();
		lbl3.setBackground(Color.GREEN);
		lbl3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lbl3.setColumns(10);
		lbl3.setBounds(189, 239, 140, 31);
		contentPane.add(lbl3);
	}
}
