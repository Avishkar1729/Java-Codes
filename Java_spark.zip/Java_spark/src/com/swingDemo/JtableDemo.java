package com.swingDemo;

import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;

public class JtableDemo extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JtableDemo frame = new JtableDemo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JtableDemo() {
		JFrame frame = new JFrame("JTable Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Sample data
        Object[][] data = {
                {"John", 25, "Male"},
                {"Anna", 30, "Female"},
                {"Mike", 35, "Male"},
                {"Emily", 28, "Female"}
        };

        // Column names
        String[] columns = {"Name", "Age", "Gender"};

        // Create a table model
        DefaultTableModel model = new DefaultTableModel(data, columns);

        // Create a JTable with the model
        JTable table = new JTable(model);
        table.setBackground(Color.CYAN);

        // Optionally, set some properties of the table
        table.setFillsViewportHeight(true); // Make the table fill the entire viewport
        table.getColumnModel().getColumn(1).setMaxWidth(50); // Set maximum width for column 1

        // Add the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the scroll pane to the frame
        frame.getContentPane().add(scrollPane);

        // Set frame size and visibility
        frame.setSize(400, 300);
        frame.setVisible(true);
	}

}
