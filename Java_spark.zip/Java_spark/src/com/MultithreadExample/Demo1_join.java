package com.MultithreadExample;

public class Demo1_join extends Thread {

	public void run() {
		for (int i = 1; i <= 5; i++) {
			System.out.println("i : " + i + "\t Name : " + currentThread().getName());
			
			if(i==3) {
				try {
					currentThread().join();
				}
				
				catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) {

		Demo1_join obj0 = new Demo1_join();
		Demo1_join obj1 = new Demo1_join();
//		Demo1_join obj2 = new Demo1_join();
//		Demo1_join obj3 = new Demo1_join();

		obj0.setPriority(MAX_PRIORITY);
		
		obj0.start();
		obj1.start();
//		obj2.start();
//		obj3.start();



	}

}
