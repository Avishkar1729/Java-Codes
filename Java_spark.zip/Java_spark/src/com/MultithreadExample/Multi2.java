
package com.MultithreadExample;

public class Multi2 extends Thread {

	public void run() {
		for (int i = 1; i <= 5; i++) {
			System.out.println("i : " + i + "\t Name : " + currentThread().getName());

			try {
//			Thread.sleep(2000);
				sleep(1000);
			}

			catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {

		Multi2 obj0 = new Multi2();
		Multi2 obj1 = new Multi2();
		Multi2 obj2 = new Multi2();
		Multi2 obj3 = new Multi2();

		obj0.start();
		obj1.start();
		obj2.start();
		obj3.start();

//		obj0.run();
//		obj1.run();
//		obj2.run();
//		obj3.run();

	}

}
