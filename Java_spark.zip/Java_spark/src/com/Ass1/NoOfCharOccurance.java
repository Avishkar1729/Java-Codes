package com.Ass1;

public class NoOfCharOccurance {
	
	void check (char ch,int i,int n,String str,int count) {
		
		if(i<n && str.toLowerCase().charAt(i) == ch) {
			count ++;
			i++;
			check(ch,i,n,str,count);
		}
		else if(i<n) {
			i++;
			check(ch,i,n,str,count);
		}
		else {
			System.out.println(count);
		}
	}
	

	public static void main(String[] args) {

		String str ="Hello I am avi";
		
		System.out.println(str);
		
		char ch = 'i';
		int i = 0;
		int n = str.length() ;
		int count = 0;
		
		NoOfCharOccurance obj = new NoOfCharOccurance();
		
		obj.check(ch,i,n,str,count);
		
		
	}

}
