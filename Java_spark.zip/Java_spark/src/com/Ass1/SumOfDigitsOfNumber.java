package com.Ass1;

import java.util.Scanner;

public class SumOfDigitsOfNumber {

	public static void main(String[] args) {

//		int num = 524;
		
		System.out.println("Enter the number");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		int sum = 0;
		int rem =0;
		
		while(num>0) {
			rem = num % 10;
			sum = sum + rem;
			num = num/10;
		}
		
		System.out.println("Sum is : " + sum);		
	}

}
