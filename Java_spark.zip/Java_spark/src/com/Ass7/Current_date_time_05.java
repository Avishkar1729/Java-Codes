package com.Ass7;
import java.text.SimpleDateFormat;  
import java.util.Date;  

public class Current_date_time_05 {

	public static void main(String[] args) {

		System.out.println("*****Simple date and time *****");
	    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date();  
	    System.out.println(formatter.format(date));  
	    
	    
	    System.out.println("***** Local Date *****");
        System.out.println(java.time.LocalDate.now());   
        
        
        System.out.println("***** java util date *****");
        java.util.Date date1 = new java.util.Date();    
        System.out.println(date1); 

		
	}

}
