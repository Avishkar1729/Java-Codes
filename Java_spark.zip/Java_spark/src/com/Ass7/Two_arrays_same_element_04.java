package com.Ass7;

public class Two_arrays_same_element_04 {

	public static void main(String[] args) {

		int arr1[] = { 1, 2, 2, 2, 5 };
		int arr2[] = { 5, 1, 2, 2, 2 };

		int n = arr1.length;
		int m = arr2.length;

		int temp = 0;
		boolean bool = true;

		if (n == m) {

			for (int i = 0; i < n; i++) {
				for (int j = i + 1; j < n; j++) {
					if (arr1[i] > arr1[j]) {
						temp = arr1[i];
						arr1[i] = arr1[j];
						arr1[j] = temp;
					}
				}	
			}

			for (int i = 0; i < m; i++) {
				for (int j = i + 1; j < m; j++) {
					if (arr2[i] > arr2[j]) {
						temp = arr2[i];
						arr2[i] = arr2[j];
						arr2[j] = temp;
					}
				}
			}
			
			for(int i=0;i<n;i++) {
				if(arr1[i] != arr2[i]) {
					bool = false;
				}
			}

		}
		
		else {
			bool = false;
		}
		
		
		if(bool==false ) {
			System.out.println("This two arrays are not same");
		}
		
		else {
			System.out.println("This two arrays are same");

		}

//		for(int i=0;i<n;i++) {
//		System.out.println(arr1[i] + "\t");
//	}

	}

}
