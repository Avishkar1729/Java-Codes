package com.Ass7;

public abstract class Animals_03 {

	abstract void cats();
	
	abstract void dogs();
	
	
}
