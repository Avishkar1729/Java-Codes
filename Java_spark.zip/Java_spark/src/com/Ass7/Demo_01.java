package com.Ass7;

public class Demo_01 {

	public static void main(String[] args) {

		Child1_01 c1 = new Child1_01();
		c1.message();
		
		Child2_01 c2 = new Child2_01();
		c2.message();
		
		
	}

}
