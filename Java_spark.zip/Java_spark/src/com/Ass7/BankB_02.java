package com.Ass7;

public class BankB_02 extends Bank_02 {
	
	int balance = 150;
	
	void getBalance() {
		System.out.println("Balance : " + balance);
	}

}
