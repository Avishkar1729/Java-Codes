package com.ClassTest;

public class OOPs_Test {

	public static void main(String[] args) {

		// single inheritance

		OOPs_02 obj1 = new OOPs_02();

		obj1.method1();
		obj1.method2();

		System.out.println("***************************");

		// multilevel inheritance

		OOPs_03 obj2 = new OOPs_03();

		obj2.method1();
		obj2.method2();
		obj2.method3();

		System.out.println("***************************");
		
		// Encapsulation 
		
		OOPs_encapsulation obj3 = new OOPs_encapsulation();

		obj3.setData(15);
		System.out.println(obj3.getData());
		
		System.out.println("***************************");
		

		// Polymorphism
		
		OOPs_poly2 obj4 = new OOPs_poly2();
		obj4.test();
		
		OOPs_poly3 obj5 = new OOPs_poly3();
		obj5.test();
		
		System.out.println("***************************");
		
		// Abstraction
		
		OOPs_abst2 obj6 = new OOPs_abst2();
		obj6.m1();
		obj6.m2();

	}

}
