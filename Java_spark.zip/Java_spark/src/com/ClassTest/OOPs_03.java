package com.ClassTest;

public class OOPs_03 extends OOPs_02 {

	void method3() {
		System.out.println("I am method 3");
	}
	
}
