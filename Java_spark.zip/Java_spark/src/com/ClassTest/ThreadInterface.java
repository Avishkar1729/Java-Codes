package com.ClassTest;

public class ThreadInterface implements Runnable   {
	
	public void run() {
		System.out.println("Inside run" + " " + Thread.currentThread().getName());
	}

	public static void main(String[] args) {


				ThreadInterface obj1 = new ThreadInterface();
				ThreadInterface obj2 = new ThreadInterface();

								
				Thread t1 = new Thread(obj1);
				Thread t2 = new Thread(obj1);
				Thread t3 = new Thread(obj2);
				Thread t4 = new Thread(obj2);

				
				t1.start();
				t2.start();
				t3.start();
				t4.start();

				


	}

}
