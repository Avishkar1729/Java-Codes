package com.ClassTest;

public class Exception_01 extends Exception {
	
	
	Exception_01(String str) {
		super(str);
	}
	

}
