package com.ClassTest;

public interface OOPs_poly1 {

	
	void test();
	
}
