package com.ClassTest;

import java.util.ArrayList;

import java.util.Iterator;

public class ArrayList_01 {

	public static void main(String[] args) {

		ArrayList<Integer> arr = new ArrayList();
		
		arr.add(10);
		arr.add(15);
		arr.add(5);
		arr.add(95);
		arr.add(42);
		
		Iterator it = arr.iterator();
		
		while(it.hasNext()) {
			System.out.print(it.next() + " ");
		}
		
		System.out.println();
		
		arr.sort(null);
		System.out.println(arr);
		
		
		
		
	}

}
