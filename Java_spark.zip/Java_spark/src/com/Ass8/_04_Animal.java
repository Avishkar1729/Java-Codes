package com.Ass8;

public abstract class _04_Animal {
	
	abstract void eat();
	abstract void sleep();

}
