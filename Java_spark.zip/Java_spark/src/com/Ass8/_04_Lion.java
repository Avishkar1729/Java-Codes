package com.Ass8;

public class _04_Lion extends _04_Animal {
	
	void eat() {
		System.out.println("Lion eat");
	}
	
	void sleep() {
		System.out.println("Lion Sleep");
	}

}
