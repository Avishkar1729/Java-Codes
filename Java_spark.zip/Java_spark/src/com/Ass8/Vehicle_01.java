package com.Ass8;

public abstract class Vehicle_01 {

	abstract void start();
	abstract void stop();
	
}
