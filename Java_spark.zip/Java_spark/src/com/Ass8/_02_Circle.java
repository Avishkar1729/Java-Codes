package com.Ass8;

abstract public class _02_Circle extends _02_Shape {
	
	int r =5;
	
	public void calculateArea() {
		System.out.println("Area of circle is : " + pi*r*r);
	}

}
