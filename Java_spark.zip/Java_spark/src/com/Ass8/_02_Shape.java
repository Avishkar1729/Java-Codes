package com.Ass8;

public abstract class _02_Shape {
	
	float pi = 3.14f;
	
	abstract void calculateArea();
	abstract void calculatePerimeter();
	

}
