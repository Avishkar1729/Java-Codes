package com.Ass8;

public class _04_Tiger extends _04_Animal {
	
	void eat() {
		System.out.println("Tiger eat");
	}
	
	void sleep() {
		System.out.println("Tiger Sleep");
	}

}
