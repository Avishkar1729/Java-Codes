package com.Ass8;

public class Vehicle_02 extends Vehicle_01 {

	void start() {
		System.out.println("Starting the vehicle");
	}
	
	void stop() {
		System.out.println("You applying break");
	}
	
	public static void main(String[] args) {

		Vehicle_02 obj = new Vehicle_02();
		
		obj.start();
		obj.stop();
		
	}

}
