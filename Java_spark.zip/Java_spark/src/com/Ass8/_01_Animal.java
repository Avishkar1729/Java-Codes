package com.Ass8;

public abstract class _01_Animal {
	
	abstract void sound();

}
