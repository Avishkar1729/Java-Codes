package com.Ass8;

public class _02_Test {

	public static void main(String[] args) {

		_02_Triangle tr = new _02_Triangle();
		
		tr.calculateArea();
		tr.calculatePerimeter();
		
		
	}

}
