package com.DSA;

public class Node {
	
	int data;
	Node next;
	
	Node(int data) {
		this.data = data;
	}

	
	public static void traverse(Node head) {
		Node cur = head;
		
		while(cur != null) {
			System.out.print("\t"+cur.data);

		}
	}
	
	static void insert (int data, Node head, int pos) {
		Node toAdd = new Node(data);
		
		if(pos==0) {
			toAdd.next = head;
			head = toAdd;
		}
		
		Node prev = head;
		
		for(int i=0;i<pos-1;i++) {
			prev = prev.next;
		}
		
		toAdd.next = prev.next;
		prev.next = toAdd;
		
	}
	
	static void delete(Node head, int pos) {
		if(pos==0) {
			head = head.next;
		}
		
		Node prev = head;
		
		for(int i=0;i<pos-1;i++) {
			prev = prev.next;
		}
		
		prev.next = prev.next.next;
	
	}
	
	
	
	public static void main(String[] args) {
		Node n1 = new Node(10);
		Node n2 = new Node(77);
		Node n3 = new Node(45);

		
		Node head = n1;
		head.next = n2;
		n2.next = n3;
		n3.next = null;
		
		System.out.println("List : ");
		traverse(head);
		
		insert(30,head,2);
		System.out.println("\nAfter Insertion : ");
		traverse(head);
		
		delete(head, 1);
		System.out.println("\nAfter deletion : ");
		traverse(head);

		
		
		
		
	}

}
