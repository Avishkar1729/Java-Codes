package com.DSA;

public class Linked_List{


	public static void main(String[] args) {

		

				
	}

}
