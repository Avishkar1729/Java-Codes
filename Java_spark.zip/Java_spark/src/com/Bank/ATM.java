package com.Bank;

public class ATM extends BOB {
	
	void balanceEnquiry() {
		System.out.println("Account Balance : " + cAccBalance);
	}
	
	void deposite() {
		System.out.println("Placed amount you deposite : ");
		int amoDeposite = sc.nextInt();
		cAccBalance += amoDeposite;
	}
	
	void withdraw() {
		System.out.println("Enter amount you withdraw : ");
		int amoWithdraw = sc.nextInt();
		cAccBalance -= amoWithdraw;
	}
	
	void changePin() {
		System.out.println("Enter Mobile No : ");
		String mobNo = sc.next();
		if(mobNo.equals(cMobileNo)) {
			System.out.println("Enter new Pin : ");
			cPin = sc.nextInt();
		}
		else {
			System.out.println("Mobile not match");
		}
	}

	
}
