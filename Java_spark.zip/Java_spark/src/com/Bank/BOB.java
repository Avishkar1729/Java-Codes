package com.Bank;
import java.util.Scanner;
import java.util.Random;

public class BOB {
	
	Scanner sc = new Scanner(System.in);
	Random ran = new Random();
	
	int cId;
	String cName;
	String cAccNo;
	String cAddress;
	String cAadhar;
	String cMobileNo;
	
	float cAccBalance = 0f;
	int cPin;
	
	BOB() {
		
		System.out.println("Customer ID Generated");
		cId = ran.nextInt(100);
		
		System.out.println("Enter your Name : ");
		cName = sc.nextLine();
		
		System.out.println("Enter your Address : ");
		cAddress = sc.nextLine();
		
		System.out.println("Enter your Aadhar No. : ");
		cAadhar = sc.nextLine();
		
		System.out.println("Enter your Mobile No. : ");
		cMobileNo = sc.nextLine();
		
		System.out.println("Account number generated: ");
		int random2 = ran.nextInt(1111111111);
		cAccNo = String.valueOf(random2);
		
		System.out.println("Your Account Number : " + cAccNo);
		System.out.println("Your Customer Id : " + cId);

		
	}
	
//	void createAccount() {
//		
//		System.out.println("Customer ID Generated");
//		cId = ran.nextInt(100);
//		
//		System.out.println("Enter your Name : ");
//		cName = sc.nextLine();
//		
//		System.out.println("Enter your Address : ");
//		cAddress = sc.nextLine();
//		
//		System.out.println("Enter your Aadhar No. : ");
//		cAadhar = sc.nextLine();
//		
//		
//		System.out.println("Account number generated: ");
//		int random2 = ran.nextInt(1111111111);
//		cAccNo = String.valueOf(random2);
//		
//		System.out.println("Your Account Number : " + cAccNo);
//		System.out.println("Your Customer Id : " + cId);
//
//		
//	}
	
	void display() {
		
		System.out.println("Customer Id : " + cId);
		System.out.println("Customer Name : " + cName);
		System.out.println("Customer Account No : " + cAccNo);
		System.out.println("Customer Address : " + cAddress);
		System.out.println("Customer Aadhar : " + cAadhar);

	}
	
	

}
