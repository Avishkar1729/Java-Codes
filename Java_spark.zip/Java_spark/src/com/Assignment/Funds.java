package com.Assignment;

public class Funds extends Exception {
	
	Funds(String str) {
		super(str);
	}
	
}
