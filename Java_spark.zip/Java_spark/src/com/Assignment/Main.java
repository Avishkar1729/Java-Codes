package com.Assignment;

import java.util.*;
import java.io.*;


public class Main {
    public static Map<String, Integer> processData(ArrayList<String> inputData) {
        Map<String, Integer> highestPaidEmployees = new HashMap<>();
        Map<String, Integer> departmentSalaries = new HashMap<>();
        Map<String, Integer> departmentEmployeeIDs = new HashMap<>();
        
        for (String line : inputData) {
            String[] fields = line.split(", ");
            int employeeID = Integer.parseInt(fields[0]);
            String name = fields[1];
            String department = fields[2];
            int salary = Integer.parseInt(fields[3]);
            
            if (departmentSalaries.containsKey(department)) {
                int totalSalary = departmentSalaries.get(department) + salary;
                departmentSalaries.put(department, totalSalary);
            } else {
                departmentSalaries.put(department, salary);
                departmentEmployeeIDs.put(department, employeeID);
            }
            
            if (salary > departmentSalaries.get(department)) {
                departmentSalaries.put(department, salary);
                departmentEmployeeIDs.put(department, employeeID);
            }
        }
        
        for (Map.Entry<String, Integer> entry : departmentEmployeeIDs.entrySet()) {
            highestPaidEmployees.put(entry.getKey(), entry.getValue());
        }
        
        return highestPaidEmployees;
    }

    public static void main (String[] args) {
        ArrayList<String> inputData = new ArrayList<String>();
        String line;
        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
            while(in.hasNextLine())
                inputData.add(in.nextLine());
            Map<String,Integer> retVal = processData(inputData);
            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
            for(Map.Entry<String,Integer> e: retVal.entrySet())
                output.println(e.getKey() + ": " + e.getValue());
            output.close();
        } catch (IOException e) {
            System.out.println("IO error in input.txt or output.txt");
        }
    }
}

