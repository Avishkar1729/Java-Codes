package com.Assignment;
import java.util.Scanner;

public class BankMain {

	Scanner sc = new Scanner(System.in);

	float bal = 5000;
	
	void balance() {
		System.out.println("Balance Amount : " + bal);
	}
	
	void withdraw() {
		System.out.println("Enter withdraw amount : ");
		float withAmo = sc.nextFloat();
		try {
			if(withAmo>bal) {
				throw new Funds("Insufficient Funds Exception");
			}
			else {
				bal = bal - withAmo;
				System.out.println("Successful Withdraw");
			}
		}
		catch (Funds ex){
			ex.printStackTrace();
		}
	}
	
	public static void main(String[] args) {

		
		BankMain obj = new BankMain();
		
		obj.balance();
		obj.withdraw();
		obj.balance();
	}

}
