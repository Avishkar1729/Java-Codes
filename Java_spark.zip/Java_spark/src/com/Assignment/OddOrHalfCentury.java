package com.Assignment;
import java.util.ArrayList;
import java.util.Scanner;

public class OddOrHalfCentury {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();
        
        // Read input until a negative number is encountered
        
        int number =0;
        do {
            number = scanner.nextInt();
            if (number < 0) {
                break;
            }
            numbers.add(number);
        }while(number>0);
        
        // Convert ArrayList to array
        int[] array = new int[numbers.size()];
        for (int i = 0; i < numbers.size(); i++) {
            array[i] = numbers.get(i);
        }
        
        // Process the array
        processArray(array);
        
        // Print the modified array
        for (int num : array) {
            System.out.println(num);
        }
        
        scanner.close();
    }
    
    public static void processArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] > 50) {
                if (array[i] % 2 != 0) {
                    array[i] = -3;
                } else {
                    array[i] = -2;
                }
            } else if (array[i] % 2 != 0) {
                array[i] = -1;
            }
        }
    }
}