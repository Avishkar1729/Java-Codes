package com.Assignment;

import java.util.Scanner;

public class Password_validate {

	public static void main(String[] args) {

		// Rohan@@52

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the password : ");
		String pass = sc.next();
		
		boolean upper=false,lower=false,digit=false,special=false;
		char ch;
		
		if(pass.length() >= 8) {
			
			for(int i=0;i<pass.length();i++) {
				
				ch = pass.charAt(i);
				
				
				
				if(Character.isUpperCase(ch)) {
					upper = true;
				}
				
				else if(Character.isLowerCase(ch)) {
					lower = true;
				}
				
				else if(Character.isDigit(ch)) {
					digit = true;
				}
				
				else if (!Character.isDigit(ch) && !Character.isLetter(ch) && !Character.isWhitespace(ch)) {
		                special=true;
		            }
				
				
			}
		}
		

		
		if(upper==true && lower==true && digit==true && special==true ) {
			System.out.println("Your password match criteria.");
		}
		
		else {
			System.out.println("Your password not match criteria.");
		}
		
		
	}
  
}
