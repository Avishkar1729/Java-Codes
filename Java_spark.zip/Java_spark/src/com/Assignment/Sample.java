package com.Assignment;

import java.util.*;

public class Sample {
    
	public static void main(String[] args) {
//	    Scanner sc = new Scanner(System.in);
//
//	    
//	    System.out.println("Enter Id");
//	    int id  = sc.nextInt();
//	    
//	    System.out.println("Enter name");
//	    sc.nextLine();
//	    String name = sc.nextLine();
	    
//	    System.out.println(name);
	    
//	    String arr[][] = {{"1","2","3"},{"4","5","6"},{"7","8","9"}};
//	    
//	    String pos = "1";
	    
//	    for (int i=0;i<3;i++) {
//	    	for(int j=0;j<3;j++) {
//	    		if(arr[i][j].equals(pos)) {
//	    			System.out.println("Hello");
//	    			break;
//	    		}
//	    	}
//	    }
		
//		int[][] marks = new int[3][3];
//
//		marks = new int[][] {{1,2,3},{4,5,6},{7,8,9}};
		


		
	}

}
