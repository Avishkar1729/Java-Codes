package com.Assignment;

import java.util.Scanner;

public class String_reverse {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a string :");
		String str = sc.nextLine();
		
//		int n = str.length();
//		
//		for(int i=0;i<=n/2+1;i++) {
//			
//			char temp1 = str.charAt(i);
////			System.out.println(temp1);
//			
////			str = str.replace(str.charAt(i), str.charAt(n-1));
////			str = str.replace(str.charAt(n-1), temp1);
//
//
//			
//			char temp2 = str.charAt(n-1);
////			System.out.println(temp2);
//			str = str.replace(str.charAt(n-1), temp1);
//			str = str.replace(str.charAt(i),temp2);
//
//			n--;
//
//			
//		}
//		
//		System.out.println(str);
		
		
		
		
		
		
		
		
		String reversedStr = "";
		
		for (int i = 0; i < str.length(); i++) {
			  reversedStr = str.charAt(i) + reversedStr;
			}

			System.out.println("Reversed string: "+ reversedStr);
		
		
			
			
		
//		int n = str.length();
//		
//		char [] arr = str.toCharArray();
//		
//		char temp;
//		
//		for (int i=0;i<n/2+1;i++) {
//			temp = arr[i];
//			arr[i] = arr[n-1];
//			arr[n-1] = temp;
//			n--;
//		}
//		
//		System.out.println();
//		
//		for (int i=0;i<arr.length;i++) {
//			System.out.print(arr[i]);
//		}
	}

}
