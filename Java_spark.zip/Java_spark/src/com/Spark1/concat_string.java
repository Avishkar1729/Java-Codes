package com.Spark1;

import java.util.Scanner;

public class concat_string {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the first name and last name");
		String name = sc.nextLine();
		
		System.out.println("Enter the middle name");
		String mName = sc.nextLine();
		
//		String str1 = "     Avi S     ";
//		String str2 = "A";
		
		name = name.trim();
		name = name.replaceAll(" ", " " + mName + " ");
		
//		for(int i=0;i<name.length();i++) {
//			if(name.charAt(i) == " ") {
//				name = name.replaceAll(" ", " " + mName + " ");
//				break;
//			}
//		}
		
		System.out.println(name);
		
	}

}
