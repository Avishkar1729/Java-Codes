package com.Spark1;

public class Final_method2 extends Final_method{
	
//	void display() {
//		System.out.println("Hello I am in method 2");
//	}
	
	// cannot override the final method

}
