package com.Spark1;

public class Exception_02  {
	
	static void met() throws NegativeArraySizeException {
		
		try {
			int arr[] = new int[-4];
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			System.out.println("Hello");
		}
		
	}

	public static void main(String[] args) {

		met();
		
	}

}
