package com.Spark1;

public class Exception_03 {

	static void rCB()
	{
		System.out.println("Inside RCB");
		
		try
		{
			int arr[] = {10,20,30,40};
			
			for(int i = 0; i <= arr.length; i++)
			{
				System.out.print(arr[i]+"\t");
			}
			
			System.out.println();
			System.out.println("Hello");
			System.out.println("pedhya");
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
		}
		
		finally
		{
			System.out.println("Inside finally");
		}
	}

	public static void main(String[] args) {
		
		rCB();

	}

}