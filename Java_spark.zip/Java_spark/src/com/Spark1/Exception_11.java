package com.Spark1;

public class Exception_11 {

	public static void main(String[] args) {

		int a =16;
		try {
			int div = a/0;
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
