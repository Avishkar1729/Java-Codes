package com.Spark1;

public class Final_method {
		
	final void display() {
		System.out.println("Hello I am in final method 1");

	}

	
}
