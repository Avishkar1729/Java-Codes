package com.jdbc;

import java.sql.*;

public class JDBC_operation {

	Connection con; // Connection interface that has capability to store reference of connection

	public void getConnection() {

		try {

			Class.forName("com.mysql.cj.jdbc.Driver"); // driver name/path

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Data", "root", ""); // connection established
																								// and get reference

			System.out.println("Connection Established!!!");
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createDB() {

		try {
			// connection with mysql

			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "");

			System.out.println("Connection Established!!!");
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		// create database

		try {

			Statement st = con.createStatement();

			String query = "create database Worldcup";
			st.executeUpdate(query);
			System.out.println("Database create successfully");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void createTable() {

		try {
			// connection with database

			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/worldcup", "root", "");

			System.out.println("Connection Established!!!");
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		// create table

		try {

			Statement st = con.createStatement();

			String query = "create table teams(id int(10) primary key, name varchar(20), rank int(10), win int(10))";
			st.executeUpdate(query);
			System.out.println("Table create successfully");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readAllData() {

		try {

			Statement st = con.createStatement();
			// Statement interface has method executeQuery()
			// Connection interface has method createStatement()

			ResultSet rs; // It has use to store elements

			String query = "select * from students";
			rs = st.executeQuery(query);

			while (rs.next()) {
				System.out.println("Name : " + rs.getString(1) + "\tRoll No : " + rs.getInt(2));
			}
			
			System.out.println("***************************************");


		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void readData(int roll) {

		try {

			Statement st = con.createStatement();

			ResultSet rs;

			String query = "select * from students where rNo = " + roll;
			rs = st.executeQuery(query);

			while (rs.next()) {
				System.out.println("Name : " + rs.getString(1) + "\tRoll No : " + rs.getInt(2));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void insertData() {
		try {

			Statement st = con.createStatement();

			String query = "INSERT INTO students VALUES ('Mahi',4)";
			st.executeUpdate(query);
			System.out.println("Data insert successful");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertData(String name, int roll) {
		try {

			String query = "INSERT INTO students VALUES (?,?)";

			PreparedStatement ps = con.prepareStatement(query);
			// PreparedStatement use for parameterized query

			ps.setString(1, name);
			ps.setInt(2, roll);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void insertImage() {
		try {

			Statement st = con.createStatement();

			String query = "INSERT INTO students VALUES('sample1',8,123456,LOAD_FILE('C:\\Users\\Info\\Documents\\sample.png'));";
			st.executeUpdate(query);
			System.out.println("Image insert successful");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public void delete() {
		try {
			Statement st = con.createStatement();

			String sql = "delete from students where rNo = 4";

			st.executeUpdate(sql);
			System.out.println("Deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(int roll) {
		try {
			Statement st = con.createStatement();

			String sql = "delete from students where rNo = " + roll;

			st.executeUpdate(sql);
			System.out.println("Deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteUser(String name) {
		try {
			String sql = "delete from students where Name = ?";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, name); // 1 is for first ?

			ps.executeUpdate();
			System.out.println("Deleted successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update() {
		try {
			Statement st = con.createStatement();

			String sql = "update students set Name = 'Axar Patel' where rNo = 2";

			st.executeUpdate(sql);

			System.out.println("Update successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateUser(int id, String name) {
		try {
			String sql = "update students set Name = ? where rNo = ?";

			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, name);
			ps.setInt(2, id);

			ps.executeUpdate();
			System.out.println("Update successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void alterTable() {
		try {
			Statement st = con.createStatement();

			String sql = "alter table students add image varchar(100)";

			st.executeUpdate(sql);

			System.out.println("Table update successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
