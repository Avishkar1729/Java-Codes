package com.Ass3;
import java.util.Scanner;

public class power_of_number {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number");
		int num = sc.nextInt();
		
		System.out.println("Enter the power");
		int pow = sc.nextInt();
		
		int mul = 1;
		
		 for(int i=1;i<=pow;i++) {
			 mul = mul * num;
		 }
		 
		 System.out.println("Power is : " + mul);
		
	}

}
