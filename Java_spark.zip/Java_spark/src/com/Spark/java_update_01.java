package com.Spark;

public interface java_update_01 {
	
	void fun1();
	
	default void fun2() {
		System.out.println("default method fun2");
	}
	
	static void fun3() {
		System.out.println("static method fun3 in first interface");
	}
	
	private void fun4() {
		System.out.println("private method fun4");
	}
	
	default void call() {
		System.out.println("access of private method fun4");
		fun4();
	}

}
