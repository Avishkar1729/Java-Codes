package com.Spark;


// chaining of constructors : call another constructor from one constructor
public class this_keyword1 {
	
	
	this_keyword1() {
		this(25, 85);
		System.out.println("Inside Default Constructor");
	}
	
	this_keyword1(int a, int b) {
		this(101,"Avi",54000.0f);
		System.out.println("Inside parameterized constructor int int");
		System.out.println("a : " + a);
		System.out.println("b : " + b);
	}
	
	this_keyword1(int eId, String eName, float eSal) {
		System.out.println("Inside Parameterised Constructor int string float");
		System.out.println("eId : " + eId);
		System.out.println("eName : " + eName);
		System.out.println("eSal : " + eSal);
		
	}
	

	
	public static void main(String[] args) {
		
		this_keyword1 tk2 = new this_keyword1();
		
		
		
	}

}
