package com.Spark;

public class ArithmeticOperation_2 {
	
	void display() {
		System.out.println("I am method/function");
	}

	public static void main(String[] args) {
		
		int sum=0;
		for(int i=1;i<=10;i++) {
			sum += i;
		}

		System.out.println("Sum is : " + sum);
		
		ArithmeticOperation_2 obj = new ArithmeticOperation_2();
		obj.display();
		
//		ArithmeticOperation.display();
		
//		Demo dobj = new Demo();
		Demo_2 dobj2 = new Demo_2(100,200);
//		System.out.println("Value of a : " + dobj.a);
//		System.out.println("Value of b : " + dobj.b);
//		System.out.println("Name : " + dobj.name);
		
//		dobj.show();
		dobj2.show();

		
	}

}
