package com.Spark;

public class Bank5 {

	public static void main(String[] args) {

		Bank4 obj = new Bank4("1234567890","Avi",25200f,"1234");
		
		obj.display();
		obj.show();
		obj.rohit();
		obj.thala();
		
		
	}

}
