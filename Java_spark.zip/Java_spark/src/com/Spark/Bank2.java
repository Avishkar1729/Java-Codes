package com.Spark;

abstract public class Bank2 extends Bank1 {

	Bank2 (String a, String b, float c, String d) {
		super(a,b,c,d);
	}
	
	void display() {
		System.out.println("Acc No : " + accNo);
		System.out.println("Acc Name : " + accName);
		System.out.println("Acc Balance : " + accBal);
		System.out.println("Acc Pin : " + accPin);

	}
	
}
