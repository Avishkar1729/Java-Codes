package com.Spark;

public class Bank4 extends Bank3 {

	Bank4 (String a, String b, float c, String d) {
		super(a,b,c,d);
	}
	
	void thala() {
		System.out.println("I am thala");
	}
	
}
