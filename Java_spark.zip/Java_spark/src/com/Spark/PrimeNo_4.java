package com.Spark;

public class PrimeNo_4 {
	
	public static void main(String[] args) {
		int num = 11;
//		int count = 0;
		boolean bool = false;
		
		for(int i=2;i<=num/2;i++) {        //i<num
//			count += 1;

			if(num%i==0) {
				bool=true;
				break;
			}
		}
		
//		System.out.println(count);
		
		if(bool==true || num==1 || num==0) {
			System.out.println("Number is not prime");
		}
		else {
			System.out.println("No is prime");
		}
		
	}
}
