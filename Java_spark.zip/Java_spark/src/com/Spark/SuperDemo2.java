package com.Spark;

public class SuperDemo2 extends SuperDemo1 {
	
	String color = "Blue";
	int b = 20;
	
	SuperDemo2()
	{
		super(20);
		System.out.println("inside default constructor of child");
	}
	
	void rohit()
	{
		System.out.println("six hitting machin");
		super.display();
	}

	
	void display()
	{
		System.out.println("color : "+color);
		System.out.println("color : "+super.color);
		System.out.println("a : "+a);
		System.out.println("b : "+b);	
	}
	

	public static void main(String[] args) {
		
		SuperDemo2 obj = new SuperDemo2();
		obj.display();
		obj.rohit();
		obj.insert();
	
	}

}