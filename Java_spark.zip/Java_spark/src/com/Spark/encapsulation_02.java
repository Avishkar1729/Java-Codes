package com.Spark;

public class encapsulation_02 {

	public static void main(String[] args) {

		encapsulation_01 obj = new encapsulation_01();
		
		obj.setRollNo(1);
		obj.setName("Avi");
		obj.setMarks(80f);
		
		System.out.println("Roll No = " + obj.getRollNo());
		System.out.println("Name = " + obj.getName());
		System.out.println("Marks = " + obj.getMarks());
		
		
	}

}
