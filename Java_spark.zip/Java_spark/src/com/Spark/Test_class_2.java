package com.Spark;

public class Test_class_2 implements Test_interface_1 {
	
	public void display() {
		System.out.println("I am in display");
	}
	
	public void show() {
		System.out.println("I am in show");
	}

	public static void main(String[] args) {
		
		Test_class_2 obj = new Test_class_2();
		obj.display();
		obj.show();
		System.out.println(obj.a);
		
	}

}
