package com.Spark;

public class multilevel_inheritance_02 {

}
