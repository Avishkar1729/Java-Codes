package com.Spark;

public interface Test_a11 {

	void display();
	void rk();
}
