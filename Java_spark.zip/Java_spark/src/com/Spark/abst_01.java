package com.Spark;

 abstract public class abst_01 {

	int a = 10;
	
	abst_01() {
		System.out.println("Inside default constructor abst_01");
	}

	void show() {
		System.out.println("Inside show");
	}
	
	abstract void display();
	
}
