package com.Spark;

public class encapsulation_01 {
	
	private int rollNo;
	private String name;
	private float marks;
	
	//setter methods
	
	public void setRollNo(int rno) {
		this.rollNo = rno;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setMarks(float marks) {
		this.marks = marks;
	}
	
	
	// getter methods
	
	public int getRollNo() {
		return rollNo;
	}
	
	public String getName() {
		return name;
	}
	
	public float getMarks() {
		return marks;
	}
	

}
