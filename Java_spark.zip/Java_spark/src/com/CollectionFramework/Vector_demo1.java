package com.CollectionFramework;

import java.util.Vector;
import java.util.Iterator;

public class Vector_demo1 {

	public static void main(String[] args) {

		Vector<String> list = new Vector<String>();
		
		list.add("Don");
		list.add("Chota don");
		list.add("chota bhim");
		list.add("ben ten");
		
		System.out.println("Displaying array list elements : ");
		Iterator it = list.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
	}

}
