package com.CollectionFramework;

import java.util.LinkedList;

public class Linked_list_demo1 {
	
	public static void main(String[] args) {
		
		Book_LL1 b1 = new Book_LL1(101,"C language","Rohit","Dharma",45);
		Book_LL1 b2 = new Book_LL1(202,"CPP language","Virat","SRK", 30);
		
		LinkedList<Book_LL1> list = new LinkedList();
		
		list.add(b1);
		list.add(b2);
		
		System.out.println("Displaying list : ");
		
		for(Book_LL1 temp : list) {
			System.out.println("Book ID : " + temp.bId +"\tBook Name : " + temp.bName  +"\tBook Author : " + temp.bAuthor  +"\tBook Publisher : " + temp.bPublisher +"\tBook Quantity : " + temp.bQuantity);
		}
		
		
	}

}
