package com.CollectionFramework;

public class Library{

	int lId;
	String lName;
	
	Library(int lId, String lName)
	{
		this.lId = lId;
		this.lName = lName;
	}


	public String toString() {
		return "Library id :" + lId + "\tLibrary name : " + lName;
	}
}
