package com.CollectionFramework;

import java.util.LinkedHashSet;
import java.util.Iterator;

public class Linked_hashSet1 {

	public static void main(String[] args) {

		LinkedHashSet<String> lhs = new LinkedHashSet();
	
		lhs.add("om");
		lhs.add("sham");
		lhs.add("om");
		lhs.add("hari");
		lhs.add("ram");
		
		Iterator it = lhs.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
			
		}
		
		System.out.println();
		System.out.println(lhs.remove("hari"));
		System.out.println(lhs);
		System.out.println(lhs.remove("avi"));
		
		
	}

}
