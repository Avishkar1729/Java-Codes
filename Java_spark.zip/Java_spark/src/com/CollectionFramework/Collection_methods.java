package com.CollectionFramework;

import java.util.ArrayList;

public class Collection_methods {
	
	public static void main(String [] args) {
		
		ArrayList<String> a1 = new ArrayList<String>();
		
		a1.add("Avi");
		a1.add("Rohit");
		a1.add("Virat");
		a1.add("Dhoni");
		
		System.out.println(a1);
		
		for(String temp : a1) {
			System.out.println(temp);
		}
		
	}

}
