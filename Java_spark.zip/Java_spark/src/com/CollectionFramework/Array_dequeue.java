package com.CollectionFramework;

import java.util.ArrayDeque;

public class Array_dequeue {

	public static void main(String[] args) {


		Book_Dequeue b1 = new Book_Dequeue(101, "java", "vishal", "spark", 25,1001,"Nalanda");
		Book_Dequeue b2 = new Book_Dequeue(102, "cpp", "jawal", "spark", 10, 1002,"FC");
		Book_Dequeue b3 = new Book_Dequeue(106, "C", "Swarupa", "Vk", 30,1002,"SP");
		Book_Dequeue b4 = new Book_Dequeue(109, "Jungle BOOK", "Sandesh", "ABC", 100,1004,"PQR");
		
		ArrayDeque<Book_Dequeue> list = new ArrayDeque<Book_Dequeue>();
		list.add(b1);
		list.add(b2);
		list.add(b3);
		list.add(b4);
		
		System.out.println("Displaying book : \n");
		
		for(Book_Dequeue temp : list)
		{
			System.out.println(temp);
		}
		
		
		/*
		for(Book temp : list)
		{
			System.out.println("book id : "+temp.bId+"\tbook name : "+temp.bName+"\tbook author : "+temp.bAuthor+"\tbook publisher : "+temp.bPublisher+"\tbook quantity : "+temp.bQuantity);
		}
	*/
		
	}

}
