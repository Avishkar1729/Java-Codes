package com.synchronization;

public class Sync2_test2 {

	public static void main(String[] args) {

		Sync2_table obj1 = new Sync2_table();
		Sync2_table obj2 = new Sync2_table();

		
		
		Sync2_thread1 st1 = new Sync2_thread1(obj1);
		Sync2_thread2 st2 = new Sync2_thread2(obj1);
		
		Sync2_thread1 st3 = new Sync2_thread1(obj2);
		Sync2_thread2 st4 = new Sync2_thread2(obj2);
		
		
//		Sync2_thread1 st1 = new Sync2_thread1();	 
//		Sync2_thread2 st2 = new Sync2_thread2();
//		
//		Sync2_thread1 st3 = new Sync2_thread1();
//		Sync2_thread2 st4 = new Sync2_thread2();
		
		
		
		st1.setName("st1");
		st2.setName("st2");
		st3.setName("st3");
		st4.setName("st4");
		
		st1.start();
		st2.start();
		st3.start();
		st4.start();
 	}

}
