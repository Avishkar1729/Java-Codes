package com.synchronization;

public class Sync3_thread1 extends Thread {

	Sync3_customer cobj;
	
	Sync3_thread1(Sync3_customer obj) {
		cobj = obj;
	}
	
	public void run() {
		cobj.withdraw(1500);
	}
}
