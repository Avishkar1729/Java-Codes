package com.synchronization;

public class Sync3_thread2 extends Thread {

	
	Sync3_customer cobj;
	
	Sync3_thread2(Sync3_customer obj) {
		cobj = obj;
	}
	
	public void run() {
		cobj.deposite(1000);
	}
	
}
