package com.synchronization;

public class Sync3_test3 {

	public static void main(String[] args) {


		Sync3_customer obj = new Sync3_customer();
				
		Sync3_thread1 t1 = new Sync3_thread1(obj);
		t1.start();
		
		Sync3_thread2 t2 = new Sync3_thread2(obj);
		t2.start();
		
		
		
//		new Thread() {
//			public void run() {
//				obj.withdraw(1500);
//			}
//		}.start();
//		
//		new Thread() {
//			public void run() {
//				obj.deposite(2000);
//			}
//		}.start();
		
	}

}
