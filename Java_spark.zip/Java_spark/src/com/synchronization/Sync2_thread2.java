package com.synchronization;

public class Sync2_thread2 extends Thread {
	
	Sync2_table tobj;
	
	Sync2_thread2(Sync2_table obj) {
		tobj = obj;
	}
	
	public void run() {
		tobj.printTable(4);
//		Sync2_table.printTable(4);
	}

}
