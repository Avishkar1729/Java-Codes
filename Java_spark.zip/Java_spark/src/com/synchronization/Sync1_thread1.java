package com.synchronization;

public class Sync1_thread1 extends Thread {
	
	Sync1_table tobj;
	
	Sync1_thread1(Sync1_table obj) {
		tobj = obj;
	}
	
	public void run() {
		tobj.printTable(8);
	}

}
